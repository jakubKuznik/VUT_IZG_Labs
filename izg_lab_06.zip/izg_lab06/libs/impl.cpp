#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include<libs/stb_image/stb_image.h>
#include<libs/stb_image/stb_image_write.h>
