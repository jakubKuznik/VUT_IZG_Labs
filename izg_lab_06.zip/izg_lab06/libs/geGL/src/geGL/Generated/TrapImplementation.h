void m_glMultiDrawArraysIndirectBindlessCountNV_trap(GLenum,const void*,GLsizei,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirectBindlessCountNV");return (void)0;}
void m_glTextureParameterfv_trap(GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterfv");return (void)0;}
void m_glGetListParameterivSGIX_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetListParameterivSGIX");return (void)0;}
void m_glProgramUniform1i64ARB_trap(GLuint,GLint,GLint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1i64ARB");return (void)0;}
void m_glVertexArrayElementBuffer_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayElementBuffer");return (void)0;}
void m_glHintPGI_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glHintPGI");return (void)0;}
void m_glStencilMaskSeparate_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilMaskSeparate");return (void)0;}
void m_glGetFramebufferAttachmentParameterivEXT_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFramebufferAttachmentParameterivEXT");return (void)0;}
void m_glTextureStorage3DMultisample_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage3DMultisample");return (void)0;}
void m_glGetIntegerIndexedvEXT_trap(GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetIntegerIndexedvEXT");return (void)0;}
void m_glCopyTexImage1D_trap(GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTexImage1D");return (void)0;}
void m_glVertexAttrib4usv_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4usv");return (void)0;}
void m_glTexRenderbufferNV_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexRenderbufferNV");return (void)0;}
void m_glVertexAttrib3hvNV_trap(GLuint,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3hvNV");return (void)0;}
void m_glProgramUniform4ui64ARB_trap(GLuint,GLint,GLuint64,GLuint64,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ui64ARB");return (void)0;}
void m_glInstrumentsBufferSGIX_trap(GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glInstrumentsBufferSGIX");return (void)0;}
void m_glIndexi_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glIndexi");return (void)0;}
void m_glMultiTexCoord2sARB_trap(GLenum,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2sARB");return (void)0;}
void m_glProgramEnvParameter4fARB_trap(GLenum,GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameter4fARB");return (void)0;}
void m_glCompressedTexSubImage3D_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage3D");return (void)0;}
void m_glEvalCoord2d_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2d");return (void)0;}
void m_glEvalCoord2f_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2f");return (void)0;}
void m_glIndexd_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glIndexd");return (void)0;}
void m_glSecondaryColor3hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3hvNV");return (void)0;}
void m_glIndexf_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glIndexf");return (void)0;}
void m_glFrustumxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glFrustumxOES");return (void)0;}
void m_glTextureStorage3DEXT_trap(GLuint,GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage3DEXT");return (void)0;}
void m_glDrawCommandsStatesNV_trap(GLuint,const GLintptr*,const GLsizei*,const GLuint*,const GLuint*,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawCommandsStatesNV");return (void)0;}
void m_glUniform4uiEXT_trap(GLint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform4uiEXT");return (void)0;}
void m_glProgramUniform3ui64ARB_trap(GLuint,GLint,GLuint64,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ui64ARB");return (void)0;}
void m_glIndexs_trap(GLshort)const{this->m_printMissingFunctionErrorAndExit("glIndexs");return (void)0;}
void m_glVertexArrayBindVertexBufferEXT_trap(GLuint,GLuint,GLuint,GLintptr,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayBindVertexBufferEXT");return (void)0;}
void m_glConvolutionParameteriEXT_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameteriEXT");return (void)0;}
void m_glColor4ubVertex2fSUN_trap(GLubyte,GLubyte,GLubyte,GLubyte,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor4ubVertex2fSUN");return (void)0;}
void m_glProgramUniform1ivEXT_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ivEXT");return (void)0;}
void m_glGetnMapfv_trap(GLenum,GLenum,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapfv");return (void)0;}
void m_glTransformFeedbackBufferRange_trap(GLuint,GLuint,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackBufferRange");return (void)0;}
void m_glPathGlyphsNV_trap(GLuint,GLenum,const void*,GLbitfield,GLsizei,GLenum,const void*,GLenum,GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathGlyphsNV");return (void)0;}
void m_glSecondaryColor3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3fv");return (void)0;}
void m_glGetCombinerInputParameterivNV_trap(GLenum,GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetCombinerInputParameterivNV");return (void)0;}
void m_glEndPerfMonitorAMD_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEndPerfMonitorAMD");return (void)0;}
void m_glPointParameterfvARB_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfvARB");return (void)0;}
void m_glVertex2xOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glVertex2xOES");return (void)0;}
void m_glDrawElementsInstancedBaseInstance_trap(GLenum,GLsizei,GLenum,const void*,GLsizei,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstancedBaseInstance");return (void)0;}
void m_glMultTransposeMatrixdARB_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultTransposeMatrixdARB");return (void)0;}
void m_glVertexAttribL4dEXT_trap(GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4dEXT");return (void)0;}
void m_glVertex4iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertex4iv");return (void)0;}
void m_glCoverStrokePathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCoverStrokePathInstancedNV");return (void)0;}
void m_glDeformSGIX_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glDeformSGIX");return (void)0;}
void m_glUniform2ui64NV_trap(GLint,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform2ui64NV");return (void)0;}
void m_glCopyPathNV_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glCopyPathNV");return (void)0;}
void m_glVertexAttribP4ui_trap(GLuint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP4ui");return (void)0;}
void m_glVertexAttribL2d_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2d");return (void)0;}
void m_glGetMultisamplefv_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultisamplefv");return (void)0;}
void m_glCompressedMultiTexSubImage3DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexSubImage3DEXT");return (void)0;}
GLvdpauSurfaceNV m_glVDPAURegisterOutputSurfaceNV_trap(const void*,GLenum,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVDPAURegisterOutputSurfaceNV");return (GLvdpauSurfaceNV)0;}
void m_glMinSampleShading_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMinSampleShading");return (void)0;}
void m_glProgramUniform4fEXT_trap(GLuint,GLint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4fEXT");return (void)0;}
void m_glCoverStrokePathNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCoverStrokePathNV");return (void)0;}
void m_glTextureImage2DMultisampleNV_trap(GLuint,GLenum,GLsizei,GLint,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureImage2DMultisampleNV");return (void)0;}
void m_glVertex3bOES_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glVertex3bOES");return (void)0;}
void m_glImportMemoryWin32HandleEXT_trap(GLuint,GLuint64,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glImportMemoryWin32HandleEXT");return (void)0;}
void m_glTessellationFactorAMD_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTessellationFactorAMD");return (void)0;}
void m_glDebugMessageControl_trap(GLenum,GLenum,GLenum,GLsizei,const GLuint*,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageControl");return (void)0;}
GLboolean m_glIsObjectBufferATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsObjectBufferATI");return (GLboolean)0;}
void m_glPopAttrib_trap()const{this->m_printMissingFunctionErrorAndExit("glPopAttrib");return (void)0;}
void m_glProgramUniform4iEXT_trap(GLuint,GLint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4iEXT");return (void)0;}
void m_glVertexAttrib4ubNV_trap(GLuint,GLubyte,GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4ubNV");return (void)0;}
void m_glColorMaterial_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glColorMaterial");return (void)0;}
void m_glVertexAttrib2svARB_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2svARB");return (void)0;}
void m_glMinSampleShadingARB_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMinSampleShadingARB");return (void)0;}
void m_glColor3b_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glColor3b");return (void)0;}
void m_glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fNormal3fVertex3fSUN");return (void)0;}
void m_glColor3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor3f");return (void)0;}
void m_glVDPAUGetSurfaceivNV_trap(GLvdpauSurfaceNV,GLenum,GLsizei,GLsizei*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glVDPAUGetSurfaceivNV");return (void)0;}
void m_glColor3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glColor3d");return (void)0;}
void m_glGetnMapiv_trap(GLenum,GLenum,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapiv");return (void)0;}
void m_glColor3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glColor3i");return (void)0;}
void m_glGetInternalformatSampleivNV_trap(GLenum,GLenum,GLsizei,GLenum,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetInternalformatSampleivNV");return (void)0;}
void m_glVertexAttrib4ubv_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4ubv");return (void)0;}
void m_glColor3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glColor3s");return (void)0;}
void m_glVertexAttribs4hvNV_trap(GLuint,GLsizei,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs4hvNV");return (void)0;}
void m_glVertexAttrib4NubvARB_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NubvARB");return (void)0;}
void m_glMultiTexCoord3hvNV_trap(GLenum,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3hvNV");return (void)0;}
void m_glMatrixPushEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glMatrixPushEXT");return (void)0;}
void m_glProgramUniform2fEXT_trap(GLuint,GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2fEXT");return (void)0;}
void m_glGetVertexArrayIndexediv_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayIndexediv");return (void)0;}
void m_glBlitFramebuffer_trap(GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLbitfield,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlitFramebuffer");return (void)0;}
void m_glMultiTexCoordP2ui_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP2ui");return (void)0;}
void m_glColorPointerListIBM_trap(GLint,GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glColorPointerListIBM");return (void)0;}
void m_glVertexAttribL4d_trap(GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4d");return (void)0;}
void m_glGetFragmentMaterialfvSGIX_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFragmentMaterialfvSGIX");return (void)0;}
void m_glVertex2iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertex2iv");return (void)0;}
void m_glGetTexEnvxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetTexEnvxvOES");return (void)0;}
void m_glUniformMatrix3dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3dv");return (void)0;}
void m_glGetVertexAttribLdvEXT_trap(GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribLdvEXT");return (void)0;}
void m_glTexCoordP3uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP3uiv");return (void)0;}
void m_glDeformationMap3dSGIX_trap(GLenum,GLdouble,GLdouble,GLint,GLint,GLdouble,GLdouble,GLint,GLint,GLdouble,GLdouble,GLint,GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glDeformationMap3dSGIX");return (void)0;}
void m_glResumeTransformFeedback_trap()const{this->m_printMissingFunctionErrorAndExit("glResumeTransformFeedback");return (void)0;}
void m_glInsertEventMarkerEXT_trap(GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glInsertEventMarkerEXT");return (void)0;}
void m_glTessellationModeAMD_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glTessellationModeAMD");return (void)0;}
void m_glDrawCommandsAddressNV_trap(GLenum,const GLuint64*,const GLsizei*,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawCommandsAddressNV");return (void)0;}
void m_glFogi_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFogi");return (void)0;}
void m_glGetTexParameterxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterxvOES");return (void)0;}
void m_glVertexPointer_trap(GLint,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glVertexPointer");return (void)0;}
void m_glGetPerfMonitorCounterDataAMD_trap(GLuint,GLenum,GLsizei,GLuint*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorCounterDataAMD");return (void)0;}
void m_glFogf_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFogf");return (void)0;}
void m_glMultiTexCoord1d_trap(GLenum,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1d");return (void)0;}
void m_glMultiTexCoord1f_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1f");return (void)0;}
void m_glGetMultiTexParameterivEXT_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexParameterivEXT");return (void)0;}
void m_glProgramUniformMatrix3x4fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x4fvEXT");return (void)0;}
void m_glVertexAttribI2i_trap(GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2i");return (void)0;}
void m_glMultiTexCoord1i_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1i");return (void)0;}
void m_glDeleteSemaphoresEXT_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteSemaphoresEXT");return (void)0;}
void m_glLoadProgramNV_trap(GLenum,GLuint,GLsizei,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glLoadProgramNV");return (void)0;}
void m_glWriteMaskEXT_trap(GLuint,GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glWriteMaskEXT");return (void)0;}
GLenum m_glGetGraphicsResetStatus_trap()const{this->m_printMissingFunctionErrorAndExit("glGetGraphicsResetStatus");return (GLenum)0;}
void m_glVertexAttrib1fv_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1fv");return (void)0;}
void m_glMultiTexCoord1s_trap(GLenum,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1s");return (void)0;}
void m_glImageTransformParameterfvHP_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glImageTransformParameterfvHP");return (void)0;}
void m_glFramebufferTexture2D_trap(GLenum,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture2D");return (void)0;}
void m_glGetFragmentLightfvSGIX_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFragmentLightfvSGIX");return (void)0;}
void m_glListParameterfSGIX_trap(GLuint,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glListParameterfSGIX");return (void)0;}
void m_glTexCoord3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3sv");return (void)0;}
void m_glNamedFramebufferRenderbufferEXT_trap(GLuint,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferRenderbufferEXT");return (void)0;}
void m_glFragmentLightModelfSGIX_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightModelfSGIX");return (void)0;}
void m_glIndexPointerEXT_trap(GLenum,GLsizei,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glIndexPointerEXT");return (void)0;}
void m_glBlendEquationSeparateATI_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparateATI");return (void)0;}
void m_glVertexArrayAttribIFormat_trap(GLuint,GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayAttribIFormat");return (void)0;}
void m_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fSUN");return (void)0;}
void m_glReplacementCodeubvSUN_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeubvSUN");return (void)0;}
void m_glGenFramebuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenFramebuffers");return (void)0;}
void m_glPixelMapx_trap(GLenum,GLint,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glPixelMapx");return (void)0;}
void m_glTexSubImage3DEXT_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage3DEXT");return (void)0;}
void m_glGetAttachedShaders_trap(GLuint,GLsizei,GLsizei*,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetAttachedShaders");return (void)0;}
void m_glGetPixelTexGenParameterfvSGIS_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelTexGenParameterfvSGIS");return (void)0;}
void m_glReplacementCodeuiNormal3fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiNormal3fVertex3fSUN");return (void)0;}
GLuint m_glGetDebugMessageLogAMD_trap(GLuint,GLsizei,GLenum*,GLuint*,GLuint*,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetDebugMessageLogAMD");return (GLuint)0;}
void m_glVertexStream4sATI_trap(GLenum,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4sATI");return (void)0;}
void m_glVertexAttribs4dvNV_trap(GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs4dvNV");return (void)0;}
void m_glGetnMapdvARB_trap(GLenum,GLenum,GLsizei,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapdvARB");return (void)0;}
void m_glOrthofOES_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glOrthofOES");return (void)0;}
void m_glViewportArrayv_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glViewportArrayv");return (void)0;}
void m_glDrawElementArrayATI_trap(GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawElementArrayATI");return (void)0;}
void m_glBufferStorageMemEXT_trap(GLenum,GLsizeiptr,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glBufferStorageMemEXT");return (void)0;}
void m_glGetPathColorGenfvNV_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathColorGenfvNV");return (void)0;}
void m_glWindowPos3iMESA_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3iMESA");return (void)0;}
void m_glMultiTexCoord2s_trap(GLenum,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2s");return (void)0;}
void m_glVertex3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertex3dv");return (void)0;}
void m_glVertexAttribI3uivEXT_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3uivEXT");return (void)0;}
void m_glUniform3ui64ARB_trap(GLint,GLuint64,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniform3ui64ARB");return (void)0;}
void m_glVertexAttrib2fvNV_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2fvNV");return (void)0;}
void m_glGetNamedBufferSubDataEXT_trap(GLuint,GLintptr,GLsizeiptr,void*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferSubDataEXT");return (void)0;}
void m_glConvolutionFilter2D_trap(GLenum,GLenum,GLsizei,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionFilter2D");return (void)0;}
void m_glMemoryBarrierByRegion_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMemoryBarrierByRegion");return (void)0;}
void m_glVertexArrayBindingDivisor_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayBindingDivisor");return (void)0;}
void m_glMatrixRotatedEXT_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMatrixRotatedEXT");return (void)0;}
void m_glTexCoord2sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2sv");return (void)0;}
GLboolean m_glIsProgramNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsProgramNV");return (GLboolean)0;}
void m_glUniform2dv_trap(GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniform2dv");return (void)0;}
void m_glGetPixelMapuiv_trap(GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelMapuiv");return (void)0;}
void m_glDepthBoundsEXT_trap(GLclampd,GLclampd)const{this->m_printMissingFunctionErrorAndExit("glDepthBoundsEXT");return (void)0;}
void m_glVertexAttrib4hvNV_trap(GLuint,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4hvNV");return (void)0;}
void m_glMultiTexParameteriEXT_trap(GLenum,GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameteriEXT");return (void)0;}
void m_glGetPointerv_trap(GLenum,GLvoid**)const{this->m_printMissingFunctionErrorAndExit("glGetPointerv");return (void)0;}
void m_glPathCommandsNV_trap(GLuint,GLsizei,const GLubyte*,GLsizei,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glPathCommandsNV");return (void)0;}
void m_glGetListParameterfvSGIX_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetListParameterfvSGIX");return (void)0;}
void m_glGetUniformuiv_trap(GLuint,GLint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformuiv");return (void)0;}
void m_glDebugMessageInsertAMD_trap(GLenum,GLenum,GLuint,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageInsertAMD");return (void)0;}
void m_glFrustum_trap(GLdouble,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glFrustum");return (void)0;}
void m_glVertexAttribL1ui64vNV_trap(GLuint,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1ui64vNV");return (void)0;}
void m_glClearColorxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glClearColorxOES");return (void)0;}
void m_glProgramUniformMatrix3fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3fv");return (void)0;}
void m_glSampleMaskIndexedNV_trap(GLuint,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glSampleMaskIndexedNV");return (void)0;}
void m_glCompileShaderIncludeARB_trap(GLuint,GLsizei,const GLchar*const*,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glCompileShaderIncludeARB");return (void)0;}
void m_glGetArrayObjectfvATI_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetArrayObjectfvATI");return (void)0;}
void m_glVertexStream4svATI_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4svATI");return (void)0;}
void m_glMultiTexCoord4iARB_trap(GLenum,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4iARB");return (void)0;}
void m_glVariantfvEXT_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVariantfvEXT");return (void)0;}
void m_glMatrixLoadfEXT_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoadfEXT");return (void)0;}
void m_glLoadIdentityDeformationMapSGIX_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glLoadIdentityDeformationMapSGIX");return (void)0;}
void m_glGetRenderbufferParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetRenderbufferParameteriv");return (void)0;}
void m_glProgramUniform3fEXT_trap(GLuint,GLint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3fEXT");return (void)0;}
void m_glNamedRenderbufferStorage_trap(GLuint,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNamedRenderbufferStorage");return (void)0;}
void m_glBindFragDataLocation_trap(GLuint,GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glBindFragDataLocation");return (void)0;}
void m_glPolygonOffsetClamp_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPolygonOffsetClamp");return (void)0;}
void m_glFogCoordPointerListIBM_trap(GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glFogCoordPointerListIBM");return (void)0;}
GLsync m_glFenceSync_trap(GLenum,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glFenceSync");return (GLsync)0;}
void m_glGetVertexAttribIivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribIivEXT");return (void)0;}
void m_glFramebufferDrawBuffersEXT_trap(GLuint,GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glFramebufferDrawBuffersEXT");return (void)0;}
void m_glVertexAttribs4fvNV_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs4fvNV");return (void)0;}
void m_glPauseTransformFeedbackNV_trap()const{this->m_printMissingFunctionErrorAndExit("glPauseTransformFeedbackNV");return (void)0;}
void m_glGetQueryObjecti64vEXT_trap(GLuint,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjecti64vEXT");return (void)0;}
void m_glVDPAUSurfaceAccessNV_trap(GLvdpauSurfaceNV,GLenum)const{this->m_printMissingFunctionErrorAndExit("glVDPAUSurfaceAccessNV");return (void)0;}
void m_glValidateProgramPipeline_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glValidateProgramPipeline");return (void)0;}
void m_glTexPageCommitmentARB_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexPageCommitmentARB");return (void)0;}
void m_glWindowPos3dvARB_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3dvARB");return (void)0;}
void m_glStencilStrokePathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLint,GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glStencilStrokePathInstancedNV");return (void)0;}
void m_glFogfv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFogfv");return (void)0;}
void m_glGenQueriesARB_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenQueriesARB");return (void)0;}
void m_glProgramUniform2i64NV_trap(GLuint,GLint,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2i64NV");return (void)0;}
void m_glVertexP4ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexP4ui");return (void)0;}
void m_glVertexStream1ivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1ivATI");return (void)0;}
void m_glProgramEnvParameterI4iNV_trap(GLenum,GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameterI4iNV");return (void)0;}
void m_glGenVertexArraysAPPLE_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenVertexArraysAPPLE");return (void)0;}
void m_glDrawTransformFeedbackInstanced_trap(GLenum,GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawTransformFeedbackInstanced");return (void)0;}
void m_glStencilThenCoverStrokePathNV_trap(GLuint,GLint,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStencilThenCoverStrokePathNV");return (void)0;}
void m_glDeleteVertexArraysAPPLE_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteVertexArraysAPPLE");return (void)0;}
void m_glGetNamedBufferParameterui64vNV_trap(GLuint,GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferParameterui64vNV");return (void)0;}
GLbitfield m_glQueryMatrixxOES_trap(GLfixed*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glQueryMatrixxOES");return (GLbitfield)0;}
void m_glSecondaryColor3usv_trap(const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3usv");return (void)0;}
void m_glTranslatexOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTranslatexOES");return (void)0;}
void m_glDrawTransformFeedback_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawTransformFeedback");return (void)0;}
void m_glTexCoord2fColor4fNormal3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor4fNormal3fVertex3fvSUN");return (void)0;}
GLvdpauSurfaceNV m_glVDPAURegisterVideoSurfaceNV_trap(const void*,GLenum,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVDPAURegisterVideoSurfaceNV");return (GLvdpauSurfaceNV)0;}
void m_glGetTexParameterIuiv_trap(GLenum,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterIuiv");return (void)0;}
void m_glBindBufferBaseNV_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindBufferBaseNV");return (void)0;}
void m_glIndexPointer_trap(GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glIndexPointer");return (void)0;}
void m_glGenQueryResourceTagNV_trap(GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGenQueryResourceTagNV");return (void)0;}
void m_glVertexAttrib4Nbv_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nbv");return (void)0;}
void m_glListParameteriSGIX_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glListParameteriSGIX");return (void)0;}
void m_glBlendColorxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glBlendColorxOES");return (void)0;}
void m_glUniformui64vNV_trap(GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniformui64vNV");return (void)0;}
GLboolean m_glIsSync_trap(GLsync)const{this->m_printMissingFunctionErrorAndExit("glIsSync");return (GLboolean)0;}
void m_glGetTextureParameterivEXT_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterivEXT");return (void)0;}
void m_glFogCoordhvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glFogCoordhvNV");return (void)0;}
void m_glFramebufferTextureLayerEXT_trap(GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureLayerEXT");return (void)0;}
void m_glGetObjectPtrLabel_trap(const void*,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectPtrLabel");return (void)0;}
void m_glTextureParameteri_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glTextureParameteri");return (void)0;}
void m_glMultiTexCoord1fARB_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1fARB");return (void)0;}
void m_glUniformMatrix2x3dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2x3dv");return (void)0;}
void m_glFramebufferDrawBufferEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFramebufferDrawBufferEXT");return (void)0;}
void m_glCopyColorSubTable_trap(GLenum,GLsizei,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyColorSubTable");return (void)0;}
void m_glGetNamedFramebufferParameterfvAMD_trap(GLuint,GLenum,GLuint,GLuint,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedFramebufferParameterfvAMD");return (void)0;}
void m_glVertexAttribL3d_trap(GLuint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3d");return (void)0;}
void m_glFragmentMaterialfvSGIX_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFragmentMaterialfvSGIX");return (void)0;}
void m_glMatrixLoadTranspose3x3fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoadTranspose3x3fNV");return (void)0;}
void m_glDeleteNamesAMD_trap(GLenum,GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteNamesAMD");return (void)0;}
void m_glDrawRangeElementsEXT_trap(GLenum,GLuint,GLuint,GLsizei,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glDrawRangeElementsEXT");return (void)0;}
void m_glOrtho_trap(GLdouble,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glOrtho");return (void)0;}
void m_glProgramUniform1dvEXT_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1dvEXT");return (void)0;}
void m_glColor4xOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glColor4xOES");return (void)0;}
void m_glTexImage4DSGIS_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexImage4DSGIS");return (void)0;}
void m_glProgramUniform1ui_trap(GLuint,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ui");return (void)0;}
void m_glDeleteBuffersARB_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteBuffersARB");return (void)0;}
GLboolean m_glUnmapBufferARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glUnmapBufferARB");return (GLboolean)0;}
void m_glCopyTexImage2D_trap(GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTexImage2D");return (void)0;}
void m_glMaterialxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMaterialxOES");return (void)0;}
void m_glProgramUniformMatrix2x4fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x4fvEXT");return (void)0;}
GLboolean m_glTestObjectAPPLE_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTestObjectAPPLE");return (GLboolean)0;}
void m_glRenderbufferStorageEXT_trap(GLenum,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glRenderbufferStorageEXT");return (void)0;}
void m_glVertexAttribL1ui64ARB_trap(GLuint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1ui64ARB");return (void)0;}
void m_glEndFragmentShaderATI_trap()const{this->m_printMissingFunctionErrorAndExit("glEndFragmentShaderATI");return (void)0;}
void m_glPathParameterivNV_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glPathParameterivNV");return (void)0;}
void m_glUniform4uiv_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform4uiv");return (void)0;}
void m_glFrameZoomSGIX_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glFrameZoomSGIX");return (void)0;}
void m_glSecondaryColor3fEXT_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3fEXT");return (void)0;}
void m_glLGPUInterlockNVX_trap()const{this->m_printMissingFunctionErrorAndExit("glLGPUInterlockNVX");return (void)0;}
void m_glVertexAttribL1dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1dv");return (void)0;}
void m_glNormalStream3svATI_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3svATI");return (void)0;}
void m_glPathStencilFuncNV_trap(GLenum,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glPathStencilFuncNV");return (void)0;}
void m_glSetInvariantEXT_trap(GLuint,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glSetInvariantEXT");return (void)0;}
void m_glGetTexBumpParameterivATI_trap(GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexBumpParameterivATI");return (void)0;}
void m_glBlendEquationSeparateEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparateEXT");return (void)0;}
void m_glEndOcclusionQueryNV_trap()const{this->m_printMissingFunctionErrorAndExit("glEndOcclusionQueryNV");return (void)0;}
void m_glScissorArrayv_trap(GLuint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glScissorArrayv");return (void)0;}
void m_glCallList_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glCallList");return (void)0;}
void* m_glMapTexture2DINTEL_trap(GLuint,GLint,GLbitfield,GLint*,GLenum*)const{this->m_printMissingFunctionErrorAndExit("glMapTexture2DINTEL");return (void*)0;}
GLVULKANPROCNV m_glGetVkProcAddrNV_trap(const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetVkProcAddrNV");return (GLVULKANPROCNV)0;}
void m_glPixelTransferxOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPixelTransferxOES");return (void)0;}
void m_glDeleteRenderbuffersEXT_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteRenderbuffersEXT");return (void)0;}
void m_glTexCoord4fColor4fNormal3fVertex4fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4fColor4fNormal3fVertex4fSUN");return (void)0;}
void m_glProgramUniformMatrix4dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4dvEXT");return (void)0;}
void m_glGetnColorTable_trap(GLenum,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnColorTable");return (void)0;}
void m_glFramebufferTextureLayerARB_trap(GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureLayerARB");return (void)0;}
void m_glVertexAttribL2dvEXT_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2dvEXT");return (void)0;}
void m_glGetCombinerStageParameterfvNV_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetCombinerStageParameterfvNV");return (void)0;}
void m_glMultiTexCoord1xvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1xvOES");return (void)0;}
void* m_glMapBuffer_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMapBuffer");return (void*)0;}
void m_glSecondaryColor3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3d");return (void)0;}
void m_glSecondaryColor3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3f");return (void)0;}
void m_glVertexAttribLFormat_trap(GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribLFormat");return (void)0;}
void m_glElementPointerAPPLE_trap(GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glElementPointerAPPLE");return (void)0;}
void m_glVertexStream1fATI_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1fATI");return (void)0;}
void m_glCoverageModulationNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCoverageModulationNV");return (void)0;}
void m_glSecondaryColor3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3i");return (void)0;}
void m_glDeleteSync_trap(GLsync)const{this->m_printMissingFunctionErrorAndExit("glDeleteSync");return (void)0;}
void m_glGetProgramParameterfvNV_trap(GLenum,GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramParameterfvNV");return (void)0;}
void m_glMaxShaderCompilerThreadsARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glMaxShaderCompilerThreadsARB");return (void)0;}
void m_glUniformMatrix4x2dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4x2dv");return (void)0;}
void m_glVertexArrayVertexAttribLOffsetEXT_trap(GLuint,GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribLOffsetEXT");return (void)0;}
void m_glSecondaryColor3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3s");return (void)0;}
GLboolean m_glIsImageHandleResidentNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glIsImageHandleResidentNV");return (GLboolean)0;}
void m_glUniform3iv_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform3iv");return (void)0;}
void m_glVertexAttribL3i64vNV_trap(GLuint,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3i64vNV");return (void)0;}
void m_glPolygonMode_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glPolygonMode");return (void)0;}
void m_glFramebufferSamplePositionsfvAMD_trap(GLenum,GLuint,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFramebufferSamplePositionsfvAMD");return (void)0;}
void m_glConvolutionFilter1DEXT_trap(GLenum,GLenum,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionFilter1DEXT");return (void)0;}
void m_glVertexAttrib1dvARB_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1dvARB");return (void)0;}
void m_glTextureSubImage2DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage2DEXT");return (void)0;}
GLboolean m_glIsVertexArrayAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsVertexArrayAPPLE");return (GLboolean)0;}
void m_glUseProgram_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glUseProgram");return (void)0;}
void m_glLineStipple_trap(GLint,GLushort)const{this->m_printMissingFunctionErrorAndExit("glLineStipple");return (void)0;}
void m_glMultiTexCoord4fvARB_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4fvARB");return (void)0;}
GLenum m_glVideoCaptureNV_trap(GLuint,GLuint*,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVideoCaptureNV");return (GLenum)0;}
void m_glVertexArrayVertexAttribLFormatEXT_trap(GLuint,GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribLFormatEXT");return (void)0;}
void m_glUniform3fvARB_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform3fvARB");return (void)0;}
void m_glProgramUniformMatrix3x2fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x2fvEXT");return (void)0;}
void m_glCopyTextureSubImage3DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage3DEXT");return (void)0;}
void m_glMultiTexCoord2bvOES_trap(GLenum,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2bvOES");return (void)0;}
void m_glDeleteObjectARB_trap(GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glDeleteObjectARB");return (void)0;}
void m_glTextureLightEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glTextureLightEXT");return (void)0;}
void m_glRasterPos3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3i");return (void)0;}
void m_glMultiTexCoord3dARB_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3dARB");return (void)0;}
void m_glNamedFramebufferTextureEXT_trap(GLuint,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTextureEXT");return (void)0;}
void m_glTextureParameteriEXT_trap(GLuint,GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glTextureParameteriEXT");return (void)0;}
void m_glEvalCoord2xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2xvOES");return (void)0;}
void m_glBindVideoCaptureStreamBufferNV_trap(GLuint,GLuint,GLenum,GLintptrARB)const{this->m_printMissingFunctionErrorAndExit("glBindVideoCaptureStreamBufferNV");return (void)0;}
void m_glTexImage2DMultisampleCoverageNV_trap(GLenum,GLsizei,GLsizei,GLint,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexImage2DMultisampleCoverageNV");return (void)0;}
GLint m_glGetAttribLocationARB_trap(GLhandleARB,const GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetAttribLocationARB");return (GLint)0;}
void m_glDeleteShader_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDeleteShader");return (void)0;}
void m_glVertexAttrib1fARB_trap(GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1fARB");return (void)0;}
void m_glTexCoord2fColor4ubVertex3fSUN_trap(GLfloat,GLfloat,GLubyte,GLubyte,GLubyte,GLubyte,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor4ubVertex3fSUN");return (void)0;}
void m_glTexCoord4fVertex4fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4fVertex4fSUN");return (void)0;}
void m_glGetMapdv_trap(GLenum,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetMapdv");return (void)0;}
void m_glMapParameterfvNV_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMapParameterfvNV");return (void)0;}
void m_glTextureParameterIuiv_trap(GLuint,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterIuiv");return (void)0;}
void m_glTransformFeedbackAttribsNV_trap(GLsizei,const GLint*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackAttribsNV");return (void)0;}
void m_glFragmentLightfvSGIX_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightfvSGIX");return (void)0;}
void m_glWindowPos3sARB_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3sARB");return (void)0;}
void m_glGetConvolutionParameterfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionParameterfv");return (void)0;}
void m_glCopyTexSubImage3D_trap(GLenum,GLint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage3D");return (void)0;}
void m_glVertexAttribI3i_trap(GLuint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3i");return (void)0;}
GLhandleARB m_glCreateShaderObjectARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCreateShaderObjectARB");return (GLhandleARB)0;}
void m_glVertexAttribFormat_trap(GLuint,GLint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribFormat");return (void)0;}
void m_glGetProgramivARB_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramivARB");return (void)0;}
void m_glVertexAttribI4usv_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4usv");return (void)0;}
void m_glTexParameterf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexParameterf");return (void)0;}
void m_glVertexAttribBinding_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribBinding");return (void)0;}
void m_glGetHistogramParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramParameteriv");return (void)0;}
void m_glTexParameteri_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexParameteri");return (void)0;}
void m_glGetShaderSource_trap(GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetShaderSource");return (void)0;}
void m_glVertexAttrib4s_trap(GLuint,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4s");return (void)0;}
void m_glVertexAttrib4dvNV_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4dvNV");return (void)0;}
void m_glVertexAttrib1dvNV_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1dvNV");return (void)0;}
void m_glPopName_trap()const{this->m_printMissingFunctionErrorAndExit("glPopName");return (void)0;}
void m_glTextureBufferEXT_trap(GLuint,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTextureBufferEXT");return (void)0;}
void m_glGetMultiTexImageEXT_trap(GLenum,GLenum,GLint,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexImageEXT");return (void)0;}
void m_glGetPointerIndexedvEXT_trap(GLenum,GLuint,void**)const{this->m_printMissingFunctionErrorAndExit("glGetPointerIndexedvEXT");return (void)0;}
GLboolean m_glIsNameAMD_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsNameAMD");return (GLboolean)0;}
void m_glColor4ub_trap(GLubyte,GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glColor4ub");return (void)0;}
void m_glBufferParameteriAPPLE_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glBufferParameteriAPPLE");return (void)0;}
void m_glColor4ui_trap(GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColor4ui");return (void)0;}
void m_glGetInternalformativ_trap(GLenum,GLenum,GLenum,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetInternalformativ");return (void)0;}
void m_glColor4us_trap(GLushort,GLushort,GLushort,GLushort)const{this->m_printMissingFunctionErrorAndExit("glColor4us");return (void)0;}
void m_glVertexAttribP1uiv_trap(GLuint,GLenum,GLboolean,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP1uiv");return (void)0;}
void m_glLinkProgram_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glLinkProgram");return (void)0;}
void m_glTexCoord3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3s");return (void)0;}
void m_glTexCoord2dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2dv");return (void)0;}
void m_glGetObjectLabel_trap(GLenum,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectLabel");return (void)0;}
void m_glVertexPointerEXT_trap(GLint,GLenum,GLsizei,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexPointerEXT");return (void)0;}
void m_glDebugMessageCallbackARB_trap(GLDEBUGPROCARB,const void*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageCallbackARB");return (void)0;}
const GLubyte* m_glGetString_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glGetString");return (const GLubyte*)0;}
void m_glGetPathParameterfvNV_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathParameterfvNV");return (void)0;}
void m_glLightxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glLightxvOES");return (void)0;}
void m_glEndQuery_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glEndQuery");return (void)0;}
void m_glSecondaryColor3uiv_trap(const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3uiv");return (void)0;}
void m_glPrioritizeTexturesxOES_trap(GLsizei,const GLuint*,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glPrioritizeTexturesxOES");return (void)0;}
void m_glEdgeFlagPointer_trap(GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlagPointer");return (void)0;}
void m_glFramebufferParameteri_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferParameteri");return (void)0;}
void m_glTexCoord3hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3hNV");return (void)0;}
void m_glMultiModeDrawElementsIBM_trap(const GLenum*,const GLsizei*,GLenum,const void*const*,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiModeDrawElementsIBM");return (void)0;}
void m_glCopyPixels_trap(GLint,GLint,GLsizei,GLsizei,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCopyPixels");return (void)0;}
void m_glVertexAttribI2ui_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2ui");return (void)0;}
void m_glClampColorARB_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glClampColorARB");return (void)0;}
void m_glColorPointervINTEL_trap(GLint,GLenum,const void**)const{this->m_printMissingFunctionErrorAndExit("glColorPointervINTEL");return (void)0;}
void m_glDeleteTextures_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteTextures");return (void)0;}
void m_glGetMinmaxParameterfvEXT_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmaxParameterfvEXT");return (void)0;}
void m_glWindowPos3sMESA_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3sMESA");return (void)0;}
void m_glVertexAttrib4f_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4f");return (void)0;}
void m_glNamedFramebufferParameteri_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferParameteri");return (void)0;}
void m_glTexCoord2fVertex3fvSUN_trap(const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fVertex3fvSUN");return (void)0;}
void m_glReplacementCodeusSUN_trap(GLushort)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeusSUN");return (void)0;}
void m_glGetNamedFramebufferParameteriv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedFramebufferParameteriv");return (void)0;}
void m_glVertexStream1fvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1fvATI");return (void)0;}
void m_glCreateVertexArrays_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateVertexArrays");return (void)0;}
void m_glBeginConditionalRender_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBeginConditionalRender");return (void)0;}
void m_glGetUnsignedBytevEXT_trap(GLenum,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetUnsignedBytevEXT");return (void)0;}
void m_glConvolutionFilter1D_trap(GLenum,GLenum,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionFilter1D");return (void)0;}
void m_glMultiTexCoord3fARB_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3fARB");return (void)0;}
void m_glGetQueryObjectuivARB_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectuivARB");return (void)0;}
void m_glScalexOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glScalexOES");return (void)0;}
void m_glSamplerParameteri_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameteri");return (void)0;}
void m_glSamplerParameterf_trap(GLuint,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameterf");return (void)0;}
void m_glShaderOp1EXT_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glShaderOp1EXT");return (void)0;}
void m_glBeginVideoCaptureNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginVideoCaptureNV");return (void)0;}
void m_glGetnHistogram_trap(GLenum,GLboolean,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnHistogram");return (void)0;}
void m_glUniform1d_trap(GLint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glUniform1d");return (void)0;}
GLint m_glRenderMode_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glRenderMode");return (GLint)0;}
void m_glClearColorIiEXT_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glClearColorIiEXT");return (void)0;}
void m_glSignalSemaphoreEXT_trap(GLuint,GLuint,const GLuint*,GLuint,const GLuint*,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glSignalSemaphoreEXT");return (void)0;}
void m_glGetCompressedTexImage_trap(GLenum,GLint,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedTexImage");return (void)0;}
void m_glCompressedTextureImage1DEXT_trap(GLuint,GLenum,GLint,GLenum,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureImage1DEXT");return (void)0;}
void m_glGetActiveUniformBlockiv_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniformBlockiv");return (void)0;}
void m_glUniform1i_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform1i");return (void)0;}
void m_glMultiDrawArraysIndirectCount_trap(GLenum,const void*,GLintptr,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirectCount");return (void)0;}
void m_glGetTexEnvfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexEnvfv");return (void)0;}
void m_glColorTableParameterivSGI_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glColorTableParameterivSGI");return (void)0;}
void m_glCullFace_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCullFace");return (void)0;}
void m_glDeleteFencesAPPLE_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteFencesAPPLE");return (void)0;}
void m_glProgramUniform4i_trap(GLuint,GLint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4i");return (void)0;}
void m_glUniformHandleui64ARB_trap(GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniformHandleui64ARB");return (void)0;}
void m_glProgramUniform4f_trap(GLuint,GLint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4f");return (void)0;}
void m_glViewportIndexedf_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glViewportIndexedf");return (void)0;}
void m_glProgramUniform4d_trap(GLuint,GLint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4d");return (void)0;}
void m_glTexCoord1xOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1xOES");return (void)0;}
void m_glVertexStream3ivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3ivATI");return (void)0;}
GLboolean m_glPointAlongPathNV_trap(GLuint,GLsizei,GLsizei,GLfloat,GLfloat*,GLfloat*,GLfloat*,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPointAlongPathNV");return (GLboolean)0;}
void m_glEndQueryARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glEndQueryARB");return (void)0;}
void m_glVDPAUMapSurfacesNV_trap(GLsizei,const GLvdpauSurfaceNV*)const{this->m_printMissingFunctionErrorAndExit("glVDPAUMapSurfacesNV");return (void)0;}
void m_glVertex3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertex3i");return (void)0;}
void m_glVertexAttrib4uivARB_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4uivARB");return (void)0;}
void m_glTextureStorageMem3DEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageMem3DEXT");return (void)0;}
void m_glAttachShader_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glAttachShader");return (void)0;}
void m_glColor4hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glColor4hNV");return (void)0;}
void m_glGetFenceivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFenceivNV");return (void)0;}
void m_glTexCoord2fColor4ubVertex3fvSUN_trap(const GLfloat*,const GLubyte*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor4ubVertex3fvSUN");return (void)0;}
void m_glGetColorTable_trap(GLenum,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTable");return (void)0;}
void m_glFogCoordPointer_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glFogCoordPointer");return (void)0;}
void m_glTexStorageSparseAMD_trap(GLenum,GLenum,GLsizei,GLsizei,GLsizei,GLsizei,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glTexStorageSparseAMD");return (void)0;}
GLboolean m_glUnmapNamedBuffer_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glUnmapNamedBuffer");return (GLboolean)0;}
void m_glTexCoord4bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4bvOES");return (void)0;}
void m_glVertexAttrib3fARB_trap(GLuint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3fARB");return (void)0;}
void m_glRasterPos2xOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2xOES");return (void)0;}
void m_glCreateMemoryObjectsEXT_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateMemoryObjectsEXT");return (void)0;}
void m_glColor4ubVertex2fvSUN_trap(const GLubyte*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor4ubVertex2fvSUN");return (void)0;}
void m_glSecondaryColor3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3dv");return (void)0;}
void m_glVertexAttribI4sv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4sv");return (void)0;}
void m_glDrawTransformFeedbackStreamInstanced_trap(GLenum,GLuint,GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawTransformFeedbackStreamInstanced");return (void)0;}
void m_glMultiTexCoord4ivARB_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4ivARB");return (void)0;}
void m_glSpriteParameterfSGIX_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glSpriteParameterfSGIX");return (void)0;}
void m_glSecondaryColor3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3sv");return (void)0;}
void m_glBindVideoCaptureStreamTextureNV_trap(GLuint,GLuint,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindVideoCaptureStreamTextureNV");return (void)0;}
void m_glTexParameterIuiv_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterIuiv");return (void)0;}
void m_glFlushPixelDataRangeNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glFlushPixelDataRangeNV");return (void)0;}
void m_glWindowPos3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3fv");return (void)0;}
void m_glVertexAttribLFormatNV_trap(GLuint,GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribLFormatNV");return (void)0;}
void m_glLightModelfv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glLightModelfv");return (void)0;}
void m_glGetColorTableSGI_trap(GLenum,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableSGI");return (void)0;}
void m_glGetCompressedTexImageARB_trap(GLenum,GLint,void*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedTexImageARB");return (void)0;}
void m_glConvolutionParameteri_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameteri");return (void)0;}
void m_glVertexWeighthNV_trap(GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertexWeighthNV");return (void)0;}
void m_glColorMaskIndexedEXT_trap(GLuint,GLboolean,GLboolean,GLboolean,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glColorMaskIndexedEXT");return (void)0;}
void m_glColorMaski_trap(GLuint,GLboolean,GLboolean,GLboolean,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glColorMaski");return (void)0;}
void m_glColorFragmentOp1ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColorFragmentOp1ATI");return (void)0;}
void m_glVertexAttribI4ubvEXT_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4ubvEXT");return (void)0;}
void m_glVertexAttrib1dNV_trap(GLuint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1dNV");return (void)0;}
void m_glUnmapObjectBufferATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glUnmapObjectBufferATI");return (void)0;}
void m_glNamedProgramLocalParameterI4uiEXT_trap(GLuint,GLenum,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameterI4uiEXT");return (void)0;}
void m_glProgramUniform1iEXT_trap(GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1iEXT");return (void)0;}
void m_glDeleteQueriesARB_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteQueriesARB");return (void)0;}
void m_glWindowPos3svARB_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3svARB");return (void)0;}
void m_glVertex4s_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertex4s");return (void)0;}
void m_glImportMemoryWin32NameEXT_trap(GLuint,GLuint64,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glImportMemoryWin32NameEXT");return (void)0;}
void m_glStringMarkerGREMEDY_trap(GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glStringMarkerGREMEDY");return (void)0;}
GLboolean m_glIsTransformFeedback_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsTransformFeedback");return (GLboolean)0;}
void m_glProgramUniformMatrix2x3dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x3dvEXT");return (void)0;}
void m_glGetObjectLabelEXT_trap(GLenum,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectLabelEXT");return (void)0;}
void m_glUniformHandleui64vNV_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniformHandleui64vNV");return (void)0;}
void m_glRotated_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glRotated");return (void)0;}
GLboolean m_glIsProgramPipeline_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsProgramPipeline");return (GLboolean)0;}
void m_glRotatef_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glRotatef");return (void)0;}
void m_glVertex4i_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertex4i");return (void)0;}
void m_glGetActiveSubroutineUniformName_trap(GLuint,GLenum,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveSubroutineUniformName");return (void)0;}
void m_glVertexAttrib4sNV_trap(GLuint,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4sNV");return (void)0;}
void m_glProgramLocalParameter4dvARB_trap(GLenum,GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameter4dvARB");return (void)0;}
void m_glReplacementCodeubSUN_trap(GLubyte)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeubSUN");return (void)0;}
void m_glMultiDrawElementsIndirectBindlessNV_trap(GLenum,GLenum,const void*,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirectBindlessNV");return (void)0;}
void m_glImportSemaphoreWin32HandleEXT_trap(GLuint,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glImportSemaphoreWin32HandleEXT");return (void)0;}
void m_glUniformMatrix3fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3fv");return (void)0;}
void m_glGetnMapfvARB_trap(GLenum,GLenum,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapfvARB");return (void)0;}
void m_glGetnUniformfv_trap(GLuint,GLint,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformfv");return (void)0;}
void m_glVertexAttribL2dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2dv");return (void)0;}
void m_glVertexWeightPointerEXT_trap(GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexWeightPointerEXT");return (void)0;}
void m_glTangent3sEXT_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glTangent3sEXT");return (void)0;}
void m_glSecondaryColorPointer_trap(GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorPointer");return (void)0;}
void m_glAlphaFunc_trap(GLenum,GLclampf)const{this->m_printMissingFunctionErrorAndExit("glAlphaFunc");return (void)0;}
void m_glGetNamedStringARB_trap(GLint,const GLchar*,GLsizei,GLint*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedStringARB");return (void)0;}
void m_glTexCoord4d_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4d");return (void)0;}
void m_glBufferPageCommitmentARB_trap(GLenum,GLintptr,GLsizeiptr,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glBufferPageCommitmentARB");return (void)0;}
void m_glProgramLocalParameters4fvEXT_trap(GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameters4fvEXT");return (void)0;}
void m_glStencilFunc_trap(GLenum,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilFunc");return (void)0;}
void m_glSemaphoreParameterui64vEXT_trap(GLuint,GLenum,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glSemaphoreParameterui64vEXT");return (void)0;}
void m_glGetVertexAttribdvNV_trap(GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribdvNV");return (void)0;}
void m_glTexCoord3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3dv");return (void)0;}
void m_glGetQueryBufferObjectiv_trap(GLuint,GLuint,GLenum,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glGetQueryBufferObjectiv");return (void)0;}
void m_glTexGenxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexGenxOES");return (void)0;}
void m_glMultiTexCoord1fvARB_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1fvARB");return (void)0;}
void m_glLightEnviSGIX_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glLightEnviSGIX");return (void)0;}
void m_glGetProgramPipelineiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramPipelineiv");return (void)0;}
void m_glVertexStream2ivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2ivATI");return (void)0;}
void m_glGetColorTableEXT_trap(GLenum,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableEXT");return (void)0;}
void m_glGetShaderInfoLog_trap(GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetShaderInfoLog");return (void)0;}
void m_glGetOcclusionQueryuivNV_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetOcclusionQueryuivNV");return (void)0;}
void m_glInvalidateNamedFramebufferSubData_trap(GLuint,GLsizei,const GLenum*,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glInvalidateNamedFramebufferSubData");return (void)0;}
void m_glVertexAttribL1i64NV_trap(GLuint,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1i64NV");return (void)0;}
void m_glVDPAUInitNV_trap(const void*,const void*)const{this->m_printMissingFunctionErrorAndExit("glVDPAUInitNV");return (void)0;}
void m_glVertexAttrib1hvNV_trap(GLuint,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1hvNV");return (void)0;}
void m_glVertexAttribI4i_trap(GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4i");return (void)0;}
void m_glRasterPos2iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2iv");return (void)0;}
void m_glGetIntegerui64i_vNV_trap(GLenum,GLuint,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetIntegerui64i_vNV");return (void)0;}
void m_glUniformHandleui64NV_trap(GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniformHandleui64NV");return (void)0;}
void m_glWindowPos3ivMESA_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3ivMESA");return (void)0;}
void m_glBlendEquationSeparate_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparate");return (void)0;}
void m_glDrawElementsInstancedARB_trap(GLenum,GLsizei,GLenum,const void*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstancedARB");return (void)0;}
GLuint m_glGetSubroutineIndex_trap(GLuint,GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetSubroutineIndex");return (GLuint)0;}
void m_glVertexAttrib2sv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2sv");return (void)0;}
void m_glSamplePatternSGIS_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glSamplePatternSGIS");return (void)0;}
void m_glEGLImageTargetRenderbufferStorageOES_trap(GLenum,GLeglImageOES)const{this->m_printMissingFunctionErrorAndExit("glEGLImageTargetRenderbufferStorageOES");return (void)0;}
void m_glPushAttrib_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glPushAttrib");return (void)0;}
void m_glVertex3hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertex3hNV");return (void)0;}
void m_glRasterPos3xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3xvOES");return (void)0;}
void m_glPathParameterfNV_trap(GLuint,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathParameterfNV");return (void)0;}
void m_glGetUniformi64vNV_trap(GLuint,GLint,GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformi64vNV");return (void)0;}
void m_glLightiv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glLightiv");return (void)0;}
void m_glMaterialxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMaterialxvOES");return (void)0;}
void m_glNamedProgramLocalParameter4fEXT_trap(GLuint,GLenum,GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameter4fEXT");return (void)0;}
void m_glVertexAttribL1dEXT_trap(GLuint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1dEXT");return (void)0;}
void m_glGetnUniformdvARB_trap(GLuint,GLint,GLsizei,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformdvARB");return (void)0;}
void m_glSecondaryColor3bEXT_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3bEXT");return (void)0;}
void m_glBeginPerfQueryINTEL_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginPerfQueryINTEL");return (void)0;}
void m_glProgramUniform1uivEXT_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1uivEXT");return (void)0;}
void m_glImageTransformParameterivHP_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glImageTransformParameterivHP");return (void)0;}
void m_glDeleteBuffers_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteBuffers");return (void)0;}
void m_glBindProgramPipeline_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindProgramPipeline");return (void)0;}
void m_glScissor_trap(GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glScissor");return (void)0;}
void m_glProgramUniform4fv_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4fv");return (void)0;}
void m_glGetBooleanv_trap(GLenum,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetBooleanv");return (void)0;}
void m_glMaterialfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMaterialfv");return (void)0;}
void m_glWindowPos4fvMESA_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4fvMESA");return (void)0;}
void m_glVertexAttribIPointerEXT_trap(GLuint,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribIPointerEXT");return (void)0;}
void m_glProgramBufferParametersfvNV_trap(GLenum,GLuint,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramBufferParametersfvNV");return (void)0;}
void m_glAlphaFuncxOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glAlphaFuncxOES");return (void)0;}
void m_glMultiDrawArraysIndirectAMD_trap(GLenum,const void*,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirectAMD");return (void)0;}
void m_glNormalStream3ivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3ivATI");return (void)0;}
void m_glTextureImage3DMultisampleNV_trap(GLuint,GLenum,GLsizei,GLint,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureImage3DMultisampleNV");return (void)0;}
void m_glProgramUniform4uivEXT_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4uivEXT");return (void)0;}
void m_glReplacementCodeusvSUN_trap(const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeusvSUN");return (void)0;}
GLint m_glPollInstrumentsSGIX_trap(GLint*)const{this->m_printMissingFunctionErrorAndExit("glPollInstrumentsSGIX");return (GLint)0;}
void m_glGetTextureLevelParameteriv_trap(GLuint,GLint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureLevelParameteriv");return (void)0;}
void m_glVertexAttribI2uiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2uiv");return (void)0;}
void m_glMapControlPointsNV_trap(GLenum,GLuint,GLenum,GLsizei,GLsizei,GLint,GLint,GLboolean,const void*)const{this->m_printMissingFunctionErrorAndExit("glMapControlPointsNV");return (void)0;}
void m_glColor4dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glColor4dv");return (void)0;}
void m_glInvalidateBufferSubData_trap(GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glInvalidateBufferSubData");return (void)0;}
void m_glMultiTexCoord1hNV_trap(GLenum,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1hNV");return (void)0;}
void m_glPointParameterfv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfv");return (void)0;}
void m_glUniformMatrix2fvARB_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2fvARB");return (void)0;}
void m_glUniform2fv_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform2fv");return (void)0;}
void m_glVertexPointerListIBM_trap(GLint,GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexPointerListIBM");return (void)0;}
void m_glGetMultiTexGenfvEXT_trap(GLenum,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexGenfvEXT");return (void)0;}
void m_glGetMinmaxEXT_trap(GLenum,GLboolean,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmaxEXT");return (void)0;}
GLboolean m_glIsFenceNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsFenceNV");return (GLboolean)0;}
void m_glMatrixFrustumEXT_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMatrixFrustumEXT");return (void)0;}
void m_glDispatchComputeIndirect_trap(GLintptr)const{this->m_printMissingFunctionErrorAndExit("glDispatchComputeIndirect");return (void)0;}
GLint m_glQueryResourceNV_trap(GLenum,GLint,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glQueryResourceNV");return (GLint)0;}
void m_glMultiTexCoord4bOES_trap(GLenum,GLbyte,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4bOES");return (void)0;}
void m_glProgramEnvParameter4dARB_trap(GLenum,GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameter4dARB");return (void)0;}
void m_glProgramUniform1uiEXT_trap(GLuint,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1uiEXT");return (void)0;}
void m_glBindBufferRange_trap(GLenum,GLuint,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glBindBufferRange");return (void)0;}
void m_glNormal3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glNormal3iv");return (void)0;}
void m_glVertexAttribL3dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3dv");return (void)0;}
void m_glGetUniformdv_trap(GLuint,GLint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformdv");return (void)0;}
void m_glGetMultiTexLevelParameterfvEXT_trap(GLenum,GLenum,GLint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexLevelParameterfvEXT");return (void)0;}
void m_glFinalCombinerInputNV_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFinalCombinerInputNV");return (void)0;}
void m_glCullParameterdvEXT_trap(GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glCullParameterdvEXT");return (void)0;}
void m_glMultiTexCoord4s_trap(GLenum,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4s");return (void)0;}
void m_glMapVertexAttrib1fAPPLE_trap(GLuint,GLuint,GLfloat,GLfloat,GLint,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMapVertexAttrib1fAPPLE");return (void)0;}
void m_glConvolutionParameterfEXT_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterfEXT");return (void)0;}
void m_glTexCoord1iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1iv");return (void)0;}
void m_glProgramUniform3fvEXT_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3fvEXT");return (void)0;}
void m_glColor3uiv_trap(const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glColor3uiv");return (void)0;}
void m_glRenderGpuMaskNV_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glRenderGpuMaskNV");return (void)0;}
void m_glListBase_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glListBase");return (void)0;}
void m_glTexCoord2bOES_trap(GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2bOES");return (void)0;}
GLuint m_glBindMaterialParameterEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindMaterialParameterEXT");return (GLuint)0;}
void m_glGlobalAlphaFactorubSUN_trap(GLubyte)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactorubSUN");return (void)0;}
void m_glVertexAttribL1ui64NV_trap(GLuint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1ui64NV");return (void)0;}
void m_glPointParameterfSGIS_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfSGIS");return (void)0;}
void m_glGetImageTransformParameterivHP_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetImageTransformParameterivHP");return (void)0;}
void m_glColorSubTableEXT_trap(GLenum,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glColorSubTableEXT");return (void)0;}
void m_glPixelTexGenParameterfvSGIS_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPixelTexGenParameterfvSGIS");return (void)0;}
GLenum m_glClientWaitSync_trap(GLsync,GLbitfield,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glClientWaitSync");return (GLenum)0;}
void m_glQueryObjectParameteruiAMD_trap(GLenum,GLuint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glQueryObjectParameteruiAMD");return (void)0;}
void m_glVertexAttribs1fvNV_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs1fvNV");return (void)0;}
void m_glVertexAttrib4NusvARB_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NusvARB");return (void)0;}
void m_glVariantPointerEXT_trap(GLuint,GLenum,GLuint,const void*)const{this->m_printMissingFunctionErrorAndExit("glVariantPointerEXT");return (void)0;}
void m_glTextureBuffer_trap(GLuint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTextureBuffer");return (void)0;}
void m_glVertexAttribI1uiEXT_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1uiEXT");return (void)0;}
void m_glInvalidateTexImage_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glInvalidateTexImage");return (void)0;}
void m_glProgramEnvParametersI4ivNV_trap(GLenum,GLuint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParametersI4ivNV");return (void)0;}
GLenum m_glPathGlyphIndexArrayNV_trap(GLuint,GLenum,const void*,GLbitfield,GLuint,GLsizei,GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathGlyphIndexArrayNV");return (GLenum)0;}
void m_glCopyImageSubData_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyImageSubData");return (void)0;}
void m_glGetUniformSubroutineuiv_trap(GLenum,GLint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformSubroutineuiv");return (void)0;}
void m_glBindVertexBuffer_trap(GLuint,GLuint,GLintptr,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glBindVertexBuffer");return (void)0;}
void m_glMultiTexCoord1iARB_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1iARB");return (void)0;}
void m_glDebugMessageInsert_trap(GLenum,GLenum,GLuint,GLenum,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageInsert");return (void)0;}
void m_glBeginVertexShaderEXT_trap()const{this->m_printMissingFunctionErrorAndExit("glBeginVertexShaderEXT");return (void)0;}
GLboolean m_glIsVariantEnabledEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glIsVariantEnabledEXT");return (GLboolean)0;}
void m_glPassThroughxOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPassThroughxOES");return (void)0;}
GLboolean m_glIsSampler_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsSampler");return (GLboolean)0;}
void m_glConservativeRasterParameterfNV_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glConservativeRasterParameterfNV");return (void)0;}
void m_glMultiTexGenivEXT_trap(GLenum,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGenivEXT");return (void)0;}
void m_glNamedFramebufferTexture2DEXT_trap(GLuint,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTexture2DEXT");return (void)0;}
void m_glCopyTexSubImage1D_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage1D");return (void)0;}
void m_glTexCoord1i_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1i");return (void)0;}
GLenum m_glCheckFramebufferStatus_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCheckFramebufferStatus");return (GLenum)0;}
void m_glDrawElementArrayAPPLE_trap(GLenum,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawElementArrayAPPLE");return (void)0;}
void m_glTexCoord1d_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1d");return (void)0;}
void m_glTexCoord1f_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1f");return (void)0;}
void m_glFragmentLightivSGIX_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightivSGIX");return (void)0;}
void m_glBindImageTexture_trap(GLuint,GLuint,GLint,GLboolean,GLint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindImageTexture");return (void)0;}
void m_glTransformFeedbackVaryings_trap(GLuint,GLsizei,const GLchar*const*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackVaryings");return (void)0;}
void m_glMulticastBufferSubDataNV_trap(GLbitfield,GLuint,GLintptr,GLsizeiptr,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glMulticastBufferSubDataNV");return (void)0;}
void m_glDrawRangeElements_trap(GLenum,GLuint,GLuint,GLsizei,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glDrawRangeElements");return (void)0;}
void m_glTexCoord1s_trap(GLshort)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1s");return (void)0;}
void m_glBindBufferBase_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindBufferBase");return (void)0;}
void m_glColor3bv_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glColor3bv");return (void)0;}
void m_glSyncTextureINTEL_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glSyncTextureINTEL");return (void)0;}
void m_glCreateSamplers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateSamplers");return (void)0;}
void m_glCombinerParameterfNV_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glCombinerParameterfNV");return (void)0;}
void m_glGetArrayObjectivATI_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetArrayObjectivATI");return (void)0;}
void m_glMultiDrawArrays_trap(GLenum,const GLint*,const GLsizei*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArrays");return (void)0;}
void m_glSampleMapATI_trap(GLuint,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glSampleMapATI");return (void)0;}
void m_glProgramUniform2i64ARB_trap(GLuint,GLint,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2i64ARB");return (void)0;}
void m_glBinormal3ivEXT_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glBinormal3ivEXT");return (void)0;}
void m_glMultiDrawArraysIndirectCountARB_trap(GLenum,const void*,GLintptr,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirectCountARB");return (void)0;}
void m_glTextureStorageMem1DEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageMem1DEXT");return (void)0;}
void m_glWindowPos2ivMESA_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2ivMESA");return (void)0;}
void m_glTexCoordP4ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP4ui");return (void)0;}
void m_glMultiTexSubImage1DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexSubImage1DEXT");return (void)0;}
void m_glProgramUniformMatrix2x3fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x3fvEXT");return (void)0;}
void m_glBufferDataARB_trap(GLenum,GLsizeiptrARB,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBufferDataARB");return (void)0;}
void m_glVertexAttribIFormat_trap(GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribIFormat");return (void)0;}
void m_glCreateFramebuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateFramebuffers");return (void)0;}
void m_glNormalStream3dvATI_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3dvATI");return (void)0;}
void m_glClearAccum_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glClearAccum");return (void)0;}
void m_glUniform3i64vNV_trap(GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform3i64vNV");return (void)0;}
void m_glNormal3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glNormal3fVertex3fSUN");return (void)0;}
void m_glUniform2uivEXT_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform2uivEXT");return (void)0;}
void m_glBeginQuery_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginQuery");return (void)0;}
void m_glStencilThenCoverStrokePathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLint,GLuint,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glStencilThenCoverStrokePathInstancedNV");return (void)0;}
void m_glBindBuffer_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindBuffer");return (void)0;}
void m_glMap2d_trap(GLenum,GLdouble,GLdouble,GLint,GLint,GLdouble,GLdouble,GLint,GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMap2d");return (void)0;}
void m_glMap2f_trap(GLenum,GLfloat,GLfloat,GLint,GLint,GLfloat,GLfloat,GLint,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMap2f");return (void)0;}
void m_glMakeImageHandleResidentNV_trap(GLuint64,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMakeImageHandleResidentNV");return (void)0;}
void m_glUniformMatrix2x4fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2x4fv");return (void)0;}
void m_glGetMultiTexParameterfvEXT_trap(GLenum,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexParameterfvEXT");return (void)0;}
void m_glDepthRangeIndexed_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glDepthRangeIndexed");return (void)0;}
GLboolean m_glIsEnabled_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glIsEnabled");return (GLboolean)0;}
void m_glMatrixScalefEXT_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMatrixScalefEXT");return (void)0;}
GLenum m_glGetError_trap()const{this->m_printMissingFunctionErrorAndExit("glGetError");return (GLenum)0;}
void m_glGetTexEnviv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexEnviv");return (void)0;}
GLuint m_glBindTextureUnitParameterEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindTextureUnitParameterEXT");return (GLuint)0;}
void m_glGetnUniformfvARB_trap(GLuint,GLint,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformfvARB");return (void)0;}
void m_glReplacementCodeuiNormal3fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiNormal3fVertex3fvSUN");return (void)0;}
void m_glDeletePerfQueryINTEL_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDeletePerfQueryINTEL");return (void)0;}
void m_glActiveVaryingNV_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glActiveVaryingNV");return (void)0;}
void m_glGetActiveUniformARB_trap(GLhandleARB,GLuint,GLsizei,GLsizei*,GLint*,GLenum*,GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniformARB");return (void)0;}
void m_glVertexAttribI3ivEXT_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3ivEXT");return (void)0;}
void m_glEvalCoord1d_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1d");return (void)0;}
void m_glNamedCopyBufferSubDataEXT_trap(GLuint,GLuint,GLintptr,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glNamedCopyBufferSubDataEXT");return (void)0;}
void m_glEvalCoord1f_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1f");return (void)0;}
void m_glPixelMapfv_trap(GLenum,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPixelMapfv");return (void)0;}
void m_glVertexAttribI1ivEXT_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1ivEXT");return (void)0;}
GLsync m_glCreateSyncFromCLeventARB_trap(struct _cl_context*,struct _cl_event*,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glCreateSyncFromCLeventARB");return (GLsync)0;}
void m_glGetPixelMapusv_trap(GLenum,GLushort*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelMapusv");return (void)0;}
void m_glGetnColorTableARB_trap(GLenum,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnColorTableARB");return (void)0;}
void m_glAccum_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glAccum");return (void)0;}
void m_glRasterPos3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3sv");return (void)0;}
void m_glTexCoord2iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2iv");return (void)0;}
void m_glBlendFunciARB_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFunciARB");return (void)0;}
void m_glProgramUniform3i64vARB_trap(GLuint,GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3i64vARB");return (void)0;}
void m_glGetFramebufferAttachmentParameteriv_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFramebufferAttachmentParameteriv");return (void)0;}
void m_glProgramUniform4ui_trap(GLuint,GLint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ui");return (void)0;}
void m_glStencilMask_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilMask");return (void)0;}
void m_glResetHistogramEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glResetHistogramEXT");return (void)0;}
void m_glLightxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glLightxOES");return (void)0;}
void m_glNamedBufferData_trap(GLuint,GLsizeiptr,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferData");return (void)0;}
void m_glVertexStream3sATI_trap(GLenum,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3sATI");return (void)0;}
void m_glVertexAttrib3fvARB_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3fvARB");return (void)0;}
void m_glClearNamedBufferSubData_trap(GLuint,GLenum,GLintptr,GLsizeiptr,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedBufferSubData");return (void)0;}
void m_glProgramUniformHandleui64ARB_trap(GLuint,GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformHandleui64ARB");return (void)0;}
void m_glUniform3iARB_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform3iARB");return (void)0;}
GLhandleARB m_glCreateProgramObjectARB_trap()const{this->m_printMissingFunctionErrorAndExit("glCreateProgramObjectARB");return (GLhandleARB)0;}
void m_glMultiTexCoord1dvARB_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1dvARB");return (void)0;}
void m_glGetObjectParameterfvARB_trap(GLhandleARB,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectParameterfvARB");return (void)0;}
void m_glRectsv_trap(const GLshort*,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glRectsv");return (void)0;}
void m_glMultiTexImage2DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexImage2DEXT");return (void)0;}
void m_glProgramUniform1i64NV_trap(GLuint,GLint,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1i64NV");return (void)0;}
void m_glGetObjectBufferivATI_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectBufferivATI");return (void)0;}
void m_glUniform4i64ARB_trap(GLint,GLint64,GLint64,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glUniform4i64ARB");return (void)0;}
void m_glReplacementCodeuiColor4ubVertex3fvSUN_trap(const GLuint*,const GLubyte*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor4ubVertex3fvSUN");return (void)0;}
void m_glBlendFuncSeparateINGR_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparateINGR");return (void)0;}
void m_glGetVideoCaptureStreamfvNV_trap(GLuint,GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoCaptureStreamfvNV");return (void)0;}
void m_glVertexAttrib2fARB_trap(GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2fARB");return (void)0;}
void m_glGetTexGeniv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexGeniv");return (void)0;}
void m_glPixelStorei_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPixelStorei");return (void)0;}
void m_glGetCompressedTextureSubImage_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedTextureSubImage");return (void)0;}
void m_glCopyImageSubDataNV_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyImageSubDataNV");return (void)0;}
void m_glActiveShaderProgram_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glActiveShaderProgram");return (void)0;}
void m_glVertexStream1iATI_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1iATI");return (void)0;}
void m_glPatchParameterfv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPatchParameterfv");return (void)0;}
GLboolean m_glIsFramebufferEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsFramebufferEXT");return (GLboolean)0;}
void m_glTextureStorage2D_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage2D");return (void)0;}
void m_glProgramUniform1ui64ARB_trap(GLuint,GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ui64ARB");return (void)0;}
void m_glTexBufferRange_trap(GLenum,GLenum,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glTexBufferRange");return (void)0;}
void m_glGetPixelTexGenParameterivSGIS_trap(GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelTexGenParameterivSGIS");return (void)0;}
void m_glTextureSubImage3DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage3DEXT");return (void)0;}
void m_glClipControl_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glClipControl");return (void)0;}
void m_glGetProgramResourceiv_trap(GLuint,GLenum,GLuint,GLsizei,const GLenum*,GLsizei,GLsizei*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourceiv");return (void)0;}
void m_glMultiTexCoordP2uiv_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP2uiv");return (void)0;}
void m_glVertexAttribI3ui_trap(GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3ui");return (void)0;}
void m_glSampleMaskSGIS_trap(GLclampf,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glSampleMaskSGIS");return (void)0;}
void m_glVertexAttrib4NivARB_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NivARB");return (void)0;}
void m_glGlobalAlphaFactorfSUN_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactorfSUN");return (void)0;}
void m_glBlendEquationSeparateIndexedAMD_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparateIndexedAMD");return (void)0;}
void m_glGetPerfCounterInfoINTEL_trap(GLuint,GLuint,GLuint,GLchar*,GLuint,GLchar*,GLuint*,GLuint*,GLuint*,GLuint*,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfCounterInfoINTEL");return (void)0;}
void m_glDeleteProgramsNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteProgramsNV");return (void)0;}
void m_glPixelZoomxOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPixelZoomxOES");return (void)0;}
void m_glGetCombinerOutputParameterivNV_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetCombinerOutputParameterivNV");return (void)0;}
void m_glRasterPos2xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2xvOES");return (void)0;}
void m_glGetTexImage_trap(GLenum,GLint,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetTexImage");return (void)0;}
void m_glVertexArrayVertexBuffers_trap(GLuint,GLuint,GLsizei,const GLuint*,const GLintptr*,const GLsizei*)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexBuffers");return (void)0;}
void m_glUniform1ui64NV_trap(GLint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform1ui64NV");return (void)0;}
void m_glProgramParameteri_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramParameteri");return (void)0;}
void m_glNormal3xOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glNormal3xOES");return (void)0;}
void m_glGetMapfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMapfv");return (void)0;}
void m_glVertexStream2dvATI_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2dvATI");return (void)0;}
void m_glPathStencilDepthOffsetNV_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathStencilDepthOffsetNV");return (void)0;}
GLboolean m_glIsStateNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsStateNV");return (GLboolean)0;}
void m_glGetIntegerui64vNV_trap(GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetIntegerui64vNV");return (void)0;}
void m_glGetImageTransformParameterfvHP_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetImageTransformParameterfvHP");return (void)0;}
void m_glRasterPos2fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2fv");return (void)0;}
void m_glVertex3xOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glVertex3xOES");return (void)0;}
GLboolean m_glIsMemoryObjectEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsMemoryObjectEXT");return (GLboolean)0;}
void m_glWeightPointerARB_trap(GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glWeightPointerARB");return (void)0;}
void m_glFinishFenceNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glFinishFenceNV");return (void)0;}
void m_glDepthRangexOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glDepthRangexOES");return (void)0;}
void m_glEnableVertexArrayAttribEXT_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexArrayAttribEXT");return (void)0;}
void m_glProgramUniform2uivEXT_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2uivEXT");return (void)0;}
void m_glGetDoubleIndexedvEXT_trap(GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetDoubleIndexedvEXT");return (void)0;}
void m_glWindowPos2fMESA_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2fMESA");return (void)0;}
void m_glSecondaryColor3b_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3b");return (void)0;}
void m_glCopyConvolutionFilter1DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyConvolutionFilter1DEXT");return (void)0;}
void m_glWindowPos2sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2sv");return (void)0;}
void m_glBindFramebufferEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindFramebufferEXT");return (void)0;}
GLuint m_glCreateShader_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCreateShader");return (GLuint)0;}
GLuint m_glGenPathsNV_trap(GLsizei)const{this->m_printMissingFunctionErrorAndExit("glGenPathsNV");return (GLuint)0;}
void m_glGenRenderbuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenRenderbuffers");return (void)0;}
void m_glCopyTexSubImage2D_trap(GLenum,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage2D");return (void)0;}
void m_glVertexAttrib4ubvARB_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4ubvARB");return (void)0;}
void m_glDrawTextureNV_trap(GLuint,GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glDrawTextureNV");return (void)0;}
void m_glVertexAttribs1svNV_trap(GLuint,GLsizei,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs1svNV");return (void)0;}
void m_glClearNamedBufferSubDataEXT_trap(GLuint,GLenum,GLsizeiptr,GLsizeiptr,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedBufferSubDataEXT");return (void)0;}
void m_glBlendFuncSeparate_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparate");return (void)0;}
void m_glPointParameterfARB_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfARB");return (void)0;}
void m_glTexCoord2fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fv");return (void)0;}
void m_glGetVariantFloatvEXT_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVariantFloatvEXT");return (void)0;}
void m_glVertexP2ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexP2ui");return (void)0;}
void m_glWindowPos2dMESA_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2dMESA");return (void)0;}
void m_glTexCoord4fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4fv");return (void)0;}
void m_glBindFragDataLocationEXT_trap(GLuint,GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glBindFragDataLocationEXT");return (void)0;}
void m_glCompressedTexSubImage1DARB_trap(GLenum,GLint,GLint,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage1DARB");return (void)0;}
void m_glGetTextureImageEXT_trap(GLuint,GLenum,GLint,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureImageEXT");return (void)0;}
void m_glFogCoordd_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glFogCoordd");return (void)0;}
void m_glPointSize_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPointSize");return (void)0;}
void m_glBindTextureUnit_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindTextureUnit");return (void)0;}
void m_glProgramEnvParameterI4uiNV_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameterI4uiNV");return (void)0;}
void m_glGetProgramPipelineInfoLog_trap(GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramPipelineInfoLog");return (void)0;}
void m_glProgramUniform4i64vARB_trap(GLuint,GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4i64vARB");return (void)0;}
void m_glVertexAttrib4Nuiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nuiv");return (void)0;}
void m_glGetUniformfvARB_trap(GLhandleARB,GLint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformfvARB");return (void)0;}
void m_glWaitSync_trap(GLsync,GLbitfield,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glWaitSync");return (void)0;}
void m_glUniform3i_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform3i");return (void)0;}
void m_glBlendEquationSeparatei_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparatei");return (void)0;}
void m_glVertexAttrib2hvNV_trap(GLuint,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2hvNV");return (void)0;}
void m_glTextureParameterivEXT_trap(GLuint,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterivEXT");return (void)0;}
void m_glUniform3d_trap(GLint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glUniform3d");return (void)0;}
void m_glUniform3f_trap(GLint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform3f");return (void)0;}
void m_glActiveProgramEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glActiveProgramEXT");return (void)0;}
void m_glProgramUniform3uiv_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3uiv");return (void)0;}
void m_glUniform3ui64vARB_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform3ui64vARB");return (void)0;}
void m_glProgramUniform1ui64vARB_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ui64vARB");return (void)0;}
void m_glTextureParameterfEXT_trap(GLuint,GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterfEXT");return (void)0;}
void m_glSetFragmentShaderConstantATI_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSetFragmentShaderConstantATI");return (void)0;}
void m_glColorSubTable_trap(GLenum,GLsizei,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glColorSubTable");return (void)0;}
void m_glReplacementCodeuiSUN_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiSUN");return (void)0;}
void m_glStateCaptureNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStateCaptureNV");return (void)0;}
void m_glBindAttribLocation_trap(GLuint,GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glBindAttribLocation");return (void)0;}
void m_glWeightusvARB_trap(GLint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glWeightusvARB");return (void)0;}
GLint m_glGetFragDataIndex_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetFragDataIndex");return (GLint)0;}
void m_glMultiTexCoord2xOES_trap(GLenum,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2xOES");return (void)0;}
void m_glColor3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glColor3sv");return (void)0;}
void m_glTexCoord2fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fVertex3fSUN");return (void)0;}
void m_glGetMemoryObjectParameterivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMemoryObjectParameterivEXT");return (void)0;}
void m_glPolygonOffsetEXT_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPolygonOffsetEXT");return (void)0;}
void m_glWeightPathsNV_trap(GLuint,GLsizei,const GLuint*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWeightPathsNV");return (void)0;}
void m_glCombinerStageParameterfvNV_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCombinerStageParameterfvNV");return (void)0;}
void m_glPointParameterfEXT_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfEXT");return (void)0;}
void m_glCopyTexImage1DEXT_trap(GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTexImage1DEXT");return (void)0;}
void m_glVertex4sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertex4sv");return (void)0;}
void m_glMatrixMultfEXT_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMultfEXT");return (void)0;}
void m_glCompressedTextureSubImage3DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage3DEXT");return (void)0;}
void m_glGetTexLevelParameterxvOES_trap(GLenum,GLint,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetTexLevelParameterxvOES");return (void)0;}
void m_glVertexAttribL3dvEXT_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3dvEXT");return (void)0;}
void m_glMultiTexCoordP4ui_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP4ui");return (void)0;}
void m_glGetTextureLevelParameterivEXT_trap(GLuint,GLenum,GLint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureLevelParameterivEXT");return (void)0;}
void m_glAlphaFragmentOp2ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glAlphaFragmentOp2ATI");return (void)0;}
void m_glDeleteFramebuffers_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteFramebuffers");return (void)0;}
void m_glDrawArrays_trap(GLenum,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawArrays");return (void)0;}
void m_glGetTransformFeedbackiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbackiv");return (void)0;}
void m_glGetnTexImageARB_trap(GLenum,GLint,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnTexImageARB");return (void)0;}
void m_glClear_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glClear");return (void)0;}
void m_glVertexArrayParameteriAPPLE_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayParameteriAPPLE");return (void)0;}
void m_glMultiTexCoord2dvARB_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2dvARB");return (void)0;}
void m_glGetVideoCaptureStreamdvNV_trap(GLuint,GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoCaptureStreamdvNV");return (void)0;}
void m_glFragmentLightModelivSGIX_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightModelivSGIX");return (void)0;}
void m_glVertexAttribP2ui_trap(GLuint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP2ui");return (void)0;}
void m_glMultiTexCoordPointerEXT_trap(GLenum,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordPointerEXT");return (void)0;}
void m_glProgramUniform3iEXT_trap(GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3iEXT");return (void)0;}
void m_glTranslatef_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTranslatef");return (void)0;}
void m_glVertexAttrib4Nub_trap(GLuint,GLubyte,GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nub");return (void)0;}
void m_glTranslated_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTranslated");return (void)0;}
void m_glSamplerParameterIiv_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameterIiv");return (void)0;}
void m_glTexCoord4hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4hNV");return (void)0;}
void m_glDrawElementsIndirect_trap(GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsIndirect");return (void)0;}
void m_glDeletePerfMonitorsAMD_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeletePerfMonitorsAMD");return (void)0;}
GLboolean m_glIsRenderbufferEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsRenderbufferEXT");return (GLboolean)0;}
void m_glDrawCommandsNV_trap(GLenum,GLuint,const GLintptr*,const GLsizei*,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawCommandsNV");return (void)0;}
void m_glUniform3ivARB_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform3ivARB");return (void)0;}
void m_glBufferSubData_trap(GLenum,GLintptr,GLsizeiptr,const void*)const{this->m_printMissingFunctionErrorAndExit("glBufferSubData");return (void)0;}
void m_glSecondaryColor3bv_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3bv");return (void)0;}
void m_glMatrixMultTransposedEXT_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMultTransposedEXT");return (void)0;}
void m_glRequestResidentProgramsNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glRequestResidentProgramsNV");return (void)0;}
void m_glAlphaFragmentOp1ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glAlphaFragmentOp1ATI");return (void)0;}
void m_glGetQueryObjecti64v_trap(GLuint,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjecti64v");return (void)0;}
void m_glMatrixMult3x3fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMult3x3fNV");return (void)0;}
void m_glColorTableParameteriv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glColorTableParameteriv");return (void)0;}
void m_glPathSubCommandsNV_trap(GLuint,GLsizei,GLsizei,GLsizei,const GLubyte*,GLsizei,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glPathSubCommandsNV");return (void)0;}
void m_glGetFinalCombinerInputParameterivNV_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFinalCombinerInputParameterivNV");return (void)0;}
GLboolean m_glIsRenderbuffer_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsRenderbuffer");return (GLboolean)0;}
void m_glVertex3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertex3iv");return (void)0;}
void m_glTexGenfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexGenfv");return (void)0;}
void m_glFrustumfOES_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFrustumfOES");return (void)0;}
void m_glBindVertexBuffers_trap(GLuint,GLsizei,const GLuint*,const GLintptr*,const GLsizei*)const{this->m_printMissingFunctionErrorAndExit("glBindVertexBuffers");return (void)0;}
void m_glMateriali_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMateriali");return (void)0;}
void m_glMultiTexCoord2svARB_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2svARB");return (void)0;}
void m_glDisableVertexAttribArray_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexAttribArray");return (void)0;}
void m_glWindowPos3ivARB_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3ivARB");return (void)0;}
void m_glTexCoordFormatNV_trap(GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTexCoordFormatNV");return (void)0;}
void m_glBlitNamedFramebuffer_trap(GLuint,GLuint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLbitfield,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlitNamedFramebuffer");return (void)0;}
void m_glMatrixLoadTransposefEXT_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoadTransposefEXT");return (void)0;}
void m_glMultiTexGenfEXT_trap(GLenum,GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGenfEXT");return (void)0;}
void m_glShaderStorageBlockBinding_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glShaderStorageBlockBinding");return (void)0;}
void m_glMaterialf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMaterialf");return (void)0;}
void m_glReplacementCodeuiColor4fNormal3fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor4fNormal3fVertex3fSUN");return (void)0;}
GLenum m_glCheckNamedFramebufferStatusEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCheckNamedFramebufferStatusEXT");return (GLenum)0;}
void m_glVertexArrayVertexAttribFormatEXT_trap(GLuint,GLuint,GLint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribFormatEXT");return (void)0;}
void m_glVertex2hNV_trap(GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertex2hNV");return (void)0;}
void m_glDeleteVertexShaderEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDeleteVertexShaderEXT");return (void)0;}
void m_glTexImage3DEXT_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexImage3DEXT");return (void)0;}
void m_glSignalVkFenceNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glSignalVkFenceNV");return (void)0;}
void m_glProgramLocalParameterI4ivNV_trap(GLenum,GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameterI4ivNV");return (void)0;}
void m_glGlobalAlphaFactoriSUN_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactoriSUN");return (void)0;}
void m_glTextureStorage1D_trap(GLuint,GLsizei,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage1D");return (void)0;}
void m_glBinormal3sEXT_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glBinormal3sEXT");return (void)0;}
void m_glGetProgramInterfaceiv_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramInterfaceiv");return (void)0;}
void m_glMatrixIndexPointerARB_trap(GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glMatrixIndexPointerARB");return (void)0;}
void m_glTexCoordPointerEXT_trap(GLint,GLenum,GLsizei,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordPointerEXT");return (void)0;}
void m_glMultiTexGeniEXT_trap(GLenum,GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGeniEXT");return (void)0;}
void m_glVertexAttrib2fNV_trap(GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2fNV");return (void)0;}
void m_glNamedProgramStringEXT_trap(GLuint,GLenum,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramStringEXT");return (void)0;}
void* m_glMapNamedBuffer_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMapNamedBuffer");return (void*)0;}
void m_glGetMinmaxParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmaxParameteriv");return (void)0;}
void m_glGetnUniformdv_trap(GLuint,GLint,GLsizei,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformdv");return (void)0;}
void m_glEndConditionalRenderNVX_trap()const{this->m_printMissingFunctionErrorAndExit("glEndConditionalRenderNVX");return (void)0;}
void m_glBinormal3fEXT_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glBinormal3fEXT");return (void)0;}
void m_glNormalStream3iATI_trap(GLenum,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3iATI");return (void)0;}
void m_glProgramBufferParametersIivNV_trap(GLenum,GLuint,GLuint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramBufferParametersIivNV");return (void)0;}
void m_glMapGrid1xOES_trap(GLint,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMapGrid1xOES");return (void)0;}
void m_glGetVertexAttribPointervARB_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribPointervARB");return (void)0;}
void m_glFlushMappedNamedBufferRangeEXT_trap(GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glFlushMappedNamedBufferRangeEXT");return (void)0;}
void m_glGetVertexAttribIiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribIiv");return (void)0;}
void m_glVertexP4uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexP4uiv");return (void)0;}
void m_glUniformui64NV_trap(GLint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniformui64NV");return (void)0;}
void m_glColor4fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor4fv");return (void)0;}
void m_glTexParameterxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterxvOES");return (void)0;}
void m_glPatchParameteri_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPatchParameteri");return (void)0;}
void m_glMap1d_trap(GLenum,GLdouble,GLdouble,GLint,GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMap1d");return (void)0;}
void m_glGetTexFilterFuncSGIS_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexFilterFuncSGIS");return (void)0;}
void m_glVertexStream3dATI_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3dATI");return (void)0;}
void m_glVertexArrayVertexBindingDivisorEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexBindingDivisorEXT");return (void)0;}
void m_glMultiTexCoord3svARB_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3svARB");return (void)0;}
void m_glBindProgramNV_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindProgramNV");return (void)0;}
void m_glGetConvolutionParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionParameteriv");return (void)0;}
void m_glGetProgramLocalParameterfvARB_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramLocalParameterfvARB");return (void)0;}
GLuint m_glGenFragmentShadersATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGenFragmentShadersATI");return (GLuint)0;}
void m_glTexBumpParameterivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexBumpParameterivATI");return (void)0;}
void m_glGetNamedFramebufferAttachmentParameteriv_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedFramebufferAttachmentParameteriv");return (void)0;}
void m_glGetnSeparableFilter_trap(GLenum,GLenum,GLenum,GLsizei,void*,GLsizei,void*,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnSeparableFilter");return (void)0;}
void m_glNormal3xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glNormal3xvOES");return (void)0;}
void m_glPassTexCoordATI_trap(GLuint,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glPassTexCoordATI");return (void)0;}
void m_glFramebufferTextureFaceARB_trap(GLenum,GLenum,GLuint,GLint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureFaceARB");return (void)0;}
void m_glProgramUniform1dv_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1dv");return (void)0;}
void m_glTextureStorage2DEXT_trap(GLuint,GLenum,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage2DEXT");return (void)0;}
void m_glVertexArrayFogCoordOffsetEXT_trap(GLuint,GLuint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayFogCoordOffsetEXT");return (void)0;}
void m_glDeleteNamedStringARB_trap(GLint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glDeleteNamedStringARB");return (void)0;}
void m_glMulticastGetQueryObjecti64vNV_trap(GLuint,GLuint,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glMulticastGetQueryObjecti64vNV");return (void)0;}
void m_glGenOcclusionQueriesNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenOcclusionQueriesNV");return (void)0;}
void m_glLighti_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glLighti");return (void)0;}
void m_glTexImage1D_trap(GLenum,GLint,GLint,GLsizei,GLint,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexImage1D");return (void)0;}
void m_glLightf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glLightf");return (void)0;}
void m_glClientAttribDefaultEXT_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glClientAttribDefaultEXT");return (void)0;}
void m_glVertexAttrib4bvARB_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4bvARB");return (void)0;}
void m_glVertexAttribIFormatNV_trap(GLuint,GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribIFormatNV");return (void)0;}
void m_glStencilFuncSeparate_trap(GLenum,GLenum,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilFuncSeparate");return (void)0;}
void m_glGetVertexAttribfvARB_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribfvARB");return (void)0;}
void m_glVertexAttrib2dNV_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2dNV");return (void)0;}
void m_glProgramUniform2iEXT_trap(GLuint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2iEXT");return (void)0;}
void m_glClientActiveVertexStreamATI_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glClientActiveVertexStreamATI");return (void)0;}
void m_glRasterPos3xOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3xOES");return (void)0;}
void m_glGetMapParameterivNV_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMapParameterivNV");return (void)0;}
void m_glSampleCoverage_trap(GLclampf,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glSampleCoverage");return (void)0;}
void m_glClearDepthxOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glClearDepthxOES");return (void)0;}
void m_glUniformBufferEXT_trap(GLuint,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniformBufferEXT");return (void)0;}
void m_glTexCoord2fNormal3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fNormal3fVertex3fvSUN");return (void)0;}
void m_glMulticastGetQueryObjectuivNV_trap(GLuint,GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMulticastGetQueryObjectuivNV");return (void)0;}
void m_glGetFirstPerfQueryIdINTEL_trap(GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetFirstPerfQueryIdINTEL");return (void)0;}
GLboolean m_glUnmapNamedBufferEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glUnmapNamedBufferEXT");return (GLboolean)0;}
void m_glGetTransformFeedbacki_v_trap(GLuint,GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbacki_v");return (void)0;}
void m_glUniform4fvARB_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform4fvARB");return (void)0;}
void m_glRenderbufferStorageMultisampleCoverageNV_trap(GLenum,GLsizei,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glRenderbufferStorageMultisampleCoverageNV");return (void)0;}
void m_glGetFloati_vEXT_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFloati_vEXT");return (void)0;}
void m_glBindAttribLocationARB_trap(GLhandleARB,GLuint,const GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glBindAttribLocationARB");return (void)0;}
void m_glBufferAddressRangeNV_trap(GLenum,GLuint,GLuint64EXT,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glBufferAddressRangeNV");return (void)0;}
void m_glGenProgramsARB_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenProgramsARB");return (void)0;}
void m_glMultiTexEnvivEXT_trap(GLenum,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexEnvivEXT");return (void)0;}
void m_glSecondaryColor3uiEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3uiEXT");return (void)0;}
void m_glCompressedTextureImage2DEXT_trap(GLuint,GLenum,GLint,GLenum,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureImage2DEXT");return (void)0;}
void m_glUniform2i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform2i");return (void)0;}
void m_glCopyTexImage2DEXT_trap(GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTexImage2DEXT");return (void)0;}
void m_glUniform2d_trap(GLint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glUniform2d");return (void)0;}
void m_glVertexAttribL1d_trap(GLuint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1d");return (void)0;}
void m_glFramebufferTextureFaceEXT_trap(GLenum,GLenum,GLuint,GLint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureFaceEXT");return (void)0;}
void m_glFramebufferTextureLayer_trap(GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureLayer");return (void)0;}
void m_glMultiTexCoord4bvOES_trap(GLenum,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4bvOES");return (void)0;}
void m_glGetVertexArrayPointeri_vEXT_trap(GLuint,GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayPointeri_vEXT");return (void)0;}
void m_glNamedProgramLocalParameter4dEXT_trap(GLuint,GLenum,GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameter4dEXT");return (void)0;}
void m_glBinormal3bEXT_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glBinormal3bEXT");return (void)0;}
void m_glConvolutionFilter2DEXT_trap(GLenum,GLenum,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionFilter2DEXT");return (void)0;}
void m_glProgramUniform2fv_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2fv");return (void)0;}
void m_glColor3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor3fVertex3fSUN");return (void)0;}
void m_glNormal3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNormal3fVertex3fvSUN");return (void)0;}
void m_glCopyMultiTexSubImage3DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyMultiTexSubImage3DEXT");return (void)0;}
void m_glProgramLocalParameterI4iNV_trap(GLenum,GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameterI4iNV");return (void)0;}
void m_glProgramUniformMatrix2x4dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x4dv");return (void)0;}
GLenum m_glPathMemoryGlyphIndexArrayNV_trap(GLuint,GLenum,GLsizeiptr,const void*,GLsizei,GLuint,GLsizei,GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathMemoryGlyphIndexArrayNV");return (GLenum)0;}
void m_glDrawArraysEXT_trap(GLenum,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysEXT");return (void)0;}
void m_glBlendEquationEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationEXT");return (void)0;}
void m_glStencilOp_trap(GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStencilOp");return (void)0;}
void m_glCopyTextureSubImage2DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage2DEXT");return (void)0;}
void m_glTexEnvf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexEnvf");return (void)0;}
void m_glVertexAttrib2dvNV_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2dvNV");return (void)0;}
void m_glGenPerfMonitorsAMD_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenPerfMonitorsAMD");return (void)0;}
void m_glGetInteger64i_v_trap(GLenum,GLuint,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetInteger64i_v");return (void)0;}
void m_glGetHistogramParameterfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramParameterfv");return (void)0;}
void m_glVertexFormatNV_trap(GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexFormatNV");return (void)0;}
void m_glBlendFuncIndexedAMD_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncIndexedAMD");return (void)0;}
void m_glTexEnvi_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexEnvi");return (void)0;}
void m_glMultiTexCoord1iv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1iv");return (void)0;}
GLboolean m_glIsEnabledi_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsEnabledi");return (GLboolean)0;}
void m_glVertexAttribL2ui64vNV_trap(GLuint,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2ui64vNV");return (void)0;}
void m_glVertexAttribL4i64NV_trap(GLuint,GLint64EXT,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4i64NV");return (void)0;}
void m_glMatrixTranslatedEXT_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMatrixTranslatedEXT");return (void)0;}
void m_glMakeTextureHandleResidentARB_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeTextureHandleResidentARB");return (void)0;}
void m_glMatrixMultdEXT_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMultdEXT");return (void)0;}
void m_glBinormal3dvEXT_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glBinormal3dvEXT");return (void)0;}
GLsync m_glImportSyncEXT_trap(GLenum,GLintptr,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glImportSyncEXT");return (GLsync)0;}
void m_glGetMapiv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMapiv");return (void)0;}
void m_glImportSemaphoreFdEXT_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glImportSemaphoreFdEXT");return (void)0;}
void m_glMultiTexCoord4sv_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4sv");return (void)0;}
void m_glPNTrianglesiATI_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPNTrianglesiATI");return (void)0;}
void m_glBindVertexArrayAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindVertexArrayAPPLE");return (void)0;}
void m_glObjectPtrLabel_trap(const void*,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glObjectPtrLabel");return (void)0;}
GLuint m_glGetDebugMessageLog_trap(GLuint,GLsizei,GLenum*,GLenum*,GLuint*,GLenum*,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetDebugMessageLog");return (GLuint)0;}
void m_glTrackMatrixNV_trap(GLenum,GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTrackMatrixNV");return (void)0;}
void m_glProgramPathFragmentInputGenNV_trap(GLuint,GLint,GLenum,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramPathFragmentInputGenNV");return (void)0;}
void m_glTangent3ivEXT_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTangent3ivEXT");return (void)0;}
void m_glGetUniformfv_trap(GLuint,GLint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformfv");return (void)0;}
void m_glSecondaryColor3ubv_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ubv");return (void)0;}
void m_glMakeTextureHandleNonResidentNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeTextureHandleNonResidentNV");return (void)0;}
void m_glVertexAttribs4ubvNV_trap(GLuint,GLsizei,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs4ubvNV");return (void)0;}
void m_glClipPlanexOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glClipPlanexOES");return (void)0;}
void m_glMultiTexCoord3iv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3iv");return (void)0;}
void m_glGetnPolygonStippleARB_trap(GLsizei,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetnPolygonStippleARB");return (void)0;}
void m_glUniform2i64vNV_trap(GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform2i64vNV");return (void)0;}
void m_glLightModelf_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glLightModelf");return (void)0;}
void m_glDeleteMemoryObjectsEXT_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteMemoryObjectsEXT");return (void)0;}
void m_glMultiTexSubImage2DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexSubImage2DEXT");return (void)0;}
void m_glReplacementCodeuiColor3fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor3fVertex3fSUN");return (void)0;}
void m_glTangent3dvEXT_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTangent3dvEXT");return (void)0;}
void m_glLightModeli_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glLightModeli");return (void)0;}
void m_glVertexWeighthvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexWeighthvNV");return (void)0;}
void m_glWindowPos3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3iv");return (void)0;}
void m_glMultiTexCoordP1uiv_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP1uiv");return (void)0;}
void m_glTransformPathNV_trap(GLuint,GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTransformPathNV");return (void)0;}
void m_glProgramNamedParameter4dNV_trap(GLuint,GLsizei,const GLubyte*,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramNamedParameter4dNV");return (void)0;}
void m_glMultiDrawElementsIndirect_trap(GLenum,GLenum,const void*,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirect");return (void)0;}
void m_glProgramUniform1dEXT_trap(GLuint,GLint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1dEXT");return (void)0;}
void m_glCallLists_trap(GLsizei,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCallLists");return (void)0;}
void m_glNormal3hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glNormal3hvNV");return (void)0;}
void m_glGetCombinerOutputParameterfvNV_trap(GLenum,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetCombinerOutputParameterfvNV");return (void)0;}
void m_glVertexAttrib4sARB_trap(GLuint,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4sARB");return (void)0;}
void m_glTexCoord3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3i");return (void)0;}
void m_glVertexAttribI3uiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3uiv");return (void)0;}
void m_glPushDebugGroup_trap(GLenum,GLuint,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glPushDebugGroup");return (void)0;}
void m_glTexCoord3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3f");return (void)0;}
void m_glTexCoord3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3d");return (void)0;}
void m_glTexCoord2xOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2xOES");return (void)0;}
GLushort m_glGetStageIndexNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glGetStageIndexNV");return (GLushort)0;}
void m_glProgramUniform4i64vNV_trap(GLuint,GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4i64vNV");return (void)0;}
void m_glGetNamedBufferPointervEXT_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferPointervEXT");return (void)0;}
void m_glTextureBarrierNV_trap()const{this->m_printMissingFunctionErrorAndExit("glTextureBarrierNV");return (void)0;}
void m_glColor4ubVertex3fvSUN_trap(const GLubyte*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor4ubVertex3fvSUN");return (void)0;}
GLuint m_glGetCommandHeaderNV_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetCommandHeaderNV");return (GLuint)0;}
void m_glGetPerfMonitorCounterInfoAMD_trap(GLuint,GLuint,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorCounterInfoAMD");return (void)0;}
void m_glVertexAttrib1svARB_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1svARB");return (void)0;}
void m_glCombinerParameteriNV_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glCombinerParameteriNV");return (void)0;}
void m_glMatrixMultTransposefEXT_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMultTransposefEXT");return (void)0;}
void m_glDetailTexFuncSGIS_trap(GLenum,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glDetailTexFuncSGIS");return (void)0;}
GLboolean m_glAreTexturesResident_trap(GLsizei,const GLuint*,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glAreTexturesResident");return (GLboolean)0;}
void m_glProgramUniform2d_trap(GLuint,GLint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2d");return (void)0;}
void m_glGetConvolutionParameterfvEXT_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionParameterfvEXT");return (void)0;}
void m_glIndexPointerListIBM_trap(GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glIndexPointerListIBM");return (void)0;}
void m_glVertexAttribI4iEXT_trap(GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4iEXT");return (void)0;}
void m_glProgramUniform2f_trap(GLuint,GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2f");return (void)0;}
void m_glRasterPos4sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4sv");return (void)0;}
void m_glColor4s_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glColor4s");return (void)0;}
void m_glMulticastGetQueryObjectivNV_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glMulticastGetQueryObjectivNV");return (void)0;}
void m_glColorFragmentOp3ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColorFragmentOp3ATI");return (void)0;}
void m_glResizeBuffersMESA_trap()const{this->m_printMissingFunctionErrorAndExit("glResizeBuffersMESA");return (void)0;}
void m_glGetMinmaxParameterfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmaxParameterfv");return (void)0;}
void m_glClientActiveTextureARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glClientActiveTextureARB");return (void)0;}
void m_glBindVertexArray_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindVertexArray");return (void)0;}
void m_glColor4b_trap(GLbyte,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glColor4b");return (void)0;}
void m_glColor4f_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor4f");return (void)0;}
void m_glColor4d_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glColor4d");return (void)0;}
void m_glColor4i_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glColor4i");return (void)0;}
void m_glEdgeFlagFormatNV_trap(GLsizei)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlagFormatNV");return (void)0;}
void m_glNamedBufferSubData_trap(GLuint,GLintptr,GLsizeiptr,const void*)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferSubData");return (void)0;}
void m_glDrawElementsInstanced_trap(GLenum,GLsizei,GLenum,const void*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstanced");return (void)0;}
void m_glGetMultiTexParameterIivEXT_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexParameterIivEXT");return (void)0;}
void m_glVertex2dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertex2dv");return (void)0;}
void m_glDisableVertexArrayAttribEXT_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexArrayAttribEXT");return (void)0;}
GLenum m_glObjectUnpurgeableAPPLE_trap(GLenum,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glObjectUnpurgeableAPPLE");return (GLenum)0;}
void m_glVertexAttribs2dvNV_trap(GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs2dvNV");return (void)0;}
void m_glReplacementCodeuiTexCoord2fVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fVertex3fSUN");return (void)0;}
void m_glGetMapParameterfvNV_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMapParameterfvNV");return (void)0;}
void m_glProgramUniform4ivEXT_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ivEXT");return (void)0;}
void m_glProgramUniform3ui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ui64vNV");return (void)0;}
void m_glRectfv_trap(const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glRectfv");return (void)0;}
void m_glTexFilterFuncSGIS_trap(GLenum,GLenum,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexFilterFuncSGIS");return (void)0;}
void m_glSpriteParameterfvSGIX_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSpriteParameterfvSGIX");return (void)0;}
void m_glCopyMultiTexImage1DEXT_trap(GLenum,GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyMultiTexImage1DEXT");return (void)0;}
void m_glGetVertexAttribIuivEXT_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribIuivEXT");return (void)0;}
void m_glUniformMatrix2x4dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2x4dv");return (void)0;}
GLint m_glGetProgramResourceLocationIndex_trap(GLuint,GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourceLocationIndex");return (GLint)0;}
void m_glColor3hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glColor3hNV");return (void)0;}
void m_glViewport_trap(GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glViewport");return (void)0;}
void m_glProgramNamedParameter4fNV_trap(GLuint,GLsizei,const GLubyte*,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramNamedParameter4fNV");return (void)0;}
void m_glGetInvariantBooleanvEXT_trap(GLuint,GLenum,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetInvariantBooleanvEXT");return (void)0;}
void m_glTexStorage2DMultisample_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexStorage2DMultisample");return (void)0;}
void m_glPixelStorex_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPixelStorex");return (void)0;}
void m_glVertexAttribL1dvEXT_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1dvEXT");return (void)0;}
void m_glGetActiveSubroutineUniformiv_trap(GLuint,GLenum,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveSubroutineUniformiv");return (void)0;}
void m_glVertexAttribPointerARB_trap(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribPointerARB");return (void)0;}
void m_glCompressedTexSubImage2DARB_trap(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage2DARB");return (void)0;}
void m_glTexStorageMem1DEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTexStorageMem1DEXT");return (void)0;}
void m_glVertex2hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertex2hvNV");return (void)0;}
void m_glTexBuffer_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexBuffer");return (void)0;}
void m_glArrayElement_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glArrayElement");return (void)0;}
void m_glValidateProgram_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glValidateProgram");return (void)0;}
void m_glPixelStoref_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPixelStoref");return (void)0;}
void m_glWindowPos3dARB_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3dARB");return (void)0;}
void m_glEvalCoord1dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1dv");return (void)0;}
void m_glVertexAttribs2fvNV_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs2fvNV");return (void)0;}
void m_glRecti_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glRecti");return (void)0;}
void m_glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fColor4fNormal3fVertex3fvSUN");return (void)0;}
void m_glTexCoord1bOES_trap(GLbyte)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1bOES");return (void)0;}
void m_glProgramUniform2i64vARB_trap(GLuint,GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2i64vARB");return (void)0;}
void m_glWindowPos2dARB_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2dARB");return (void)0;}
void m_glGetProgramParameterdvNV_trap(GLenum,GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramParameterdvNV");return (void)0;}
void m_glRectf_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glRectf");return (void)0;}
void m_glRectd_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glRectd");return (void)0;}
void m_glMap1xOES_trap(GLenum,GLfixed,GLfixed,GLint,GLint,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMap1xOES");return (void)0;}
void m_glVertexAttrib3fvNV_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3fvNV");return (void)0;}
void m_glReferencePlaneSGIX_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glReferencePlaneSGIX");return (void)0;}
void m_glMulticastBlitFramebufferNV_trap(GLuint,GLuint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLbitfield,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMulticastBlitFramebufferNV");return (void)0;}
void m_glGetCombinerInputParameterfvNV_trap(GLenum,GLenum,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetCombinerInputParameterfvNV");return (void)0;}
GLuint64 m_glGetTextureSamplerHandleARB_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetTextureSamplerHandleARB");return (GLuint64)0;}
void m_glBindTexture_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindTexture");return (void)0;}
void m_glRects_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glRects");return (void)0;}
void m_glGetActiveAttribARB_trap(GLhandleARB,GLuint,GLsizei,GLsizei*,GLint*,GLenum*,GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveAttribARB");return (void)0;}
void m_glHistogramEXT_trap(GLenum,GLsizei,GLenum,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glHistogramEXT");return (void)0;}
GLuint64 m_glGetTextureSamplerHandleNV_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetTextureSamplerHandleNV");return (GLuint64)0;}
void m_glDetachShader_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDetachShader");return (void)0;}
void m_glFinishTextureSUNX_trap()const{this->m_printMissingFunctionErrorAndExit("glFinishTextureSUNX");return (void)0;}
void m_glUniformMatrix3x4dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3x4dv");return (void)0;}
void m_glVertexAttrib4fARB_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4fARB");return (void)0;}
void m_glGetPathColorGenivNV_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPathColorGenivNV");return (void)0;}
GLint m_glGetProgramResourceLocation_trap(GLuint,GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourceLocation");return (GLint)0;}
void m_glVertexArrayAttribLFormat_trap(GLuint,GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayAttribLFormat");return (void)0;}
void m_glGetTexLevelParameterfv_trap(GLenum,GLint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexLevelParameterfv");return (void)0;}
void m_glVertexArrayVertexAttribOffsetEXT_trap(GLuint,GLuint,GLuint,GLint,GLenum,GLboolean,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribOffsetEXT");return (void)0;}
void m_glIndexFormatNV_trap(GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glIndexFormatNV");return (void)0;}
void m_glMultiTexCoord3i_trap(GLenum,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3i");return (void)0;}
void m_glReplacementCodeuiVertex3fvSUN_trap(const GLuint*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiVertex3fvSUN");return (void)0;}
void m_glViewportIndexedfv_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glViewportIndexedfv");return (void)0;}
void m_glBindBuffersBase_trap(GLenum,GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glBindBuffersBase");return (void)0;}
void m_glTexBumpParameterfvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexBumpParameterfvATI");return (void)0;}
void m_glMatrixIndexuivARB_trap(GLint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMatrixIndexuivARB");return (void)0;}
void m_glVertexAttrib1hNV_trap(GLuint,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1hNV");return (void)0;}
void m_glWindowPos3svMESA_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3svMESA");return (void)0;}
void m_glStencilOpSeparateATI_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStencilOpSeparateATI");return (void)0;}
void m_glDrawElementsBaseVertex_trap(GLenum,GLsizei,GLenum,const void*,GLint)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsBaseVertex");return (void)0;}
void m_glBlendEquationSeparateiARB_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationSeparateiARB");return (void)0;}
void m_glVertexAttrib1fNV_trap(GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1fNV");return (void)0;}
void m_glMapVertexAttrib2fAPPLE_trap(GLuint,GLuint,GLfloat,GLfloat,GLint,GLint,GLfloat,GLfloat,GLint,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMapVertexAttrib2fAPPLE");return (void)0;}
void m_glCompressedTextureSubImage1DEXT_trap(GLuint,GLenum,GLint,GLint,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage1DEXT");return (void)0;}
void m_glClearBufferSubData_trap(GLenum,GLenum,GLintptr,GLsizeiptr,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearBufferSubData");return (void)0;}
void m_glTexStorage1D_trap(GLenum,GLsizei,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTexStorage1D");return (void)0;}
void m_glVertexAttribI3iEXT_trap(GLuint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3iEXT");return (void)0;}
void m_glMakeTextureHandleNonResidentARB_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeTextureHandleNonResidentARB");return (void)0;}
void m_glMultiDrawElementArrayAPPLE_trap(GLenum,const GLint*,const GLsizei*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementArrayAPPLE");return (void)0;}
void m_glVertexStream4dATI_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4dATI");return (void)0;}
void m_glProgramUniformMatrix2dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2dvEXT");return (void)0;}
void m_glVertexAttribs2hvNV_trap(GLuint,GLsizei,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs2hvNV");return (void)0;}
void m_glGetUniformiv_trap(GLuint,GLint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformiv");return (void)0;}
void m_glClipPlanefOES_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glClipPlanefOES");return (void)0;}
void m_glRenderbufferStorage_trap(GLenum,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glRenderbufferStorage");return (void)0;}
void m_glUniform4ui_trap(GLint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform4ui");return (void)0;}
void m_glBindFramebuffer_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindFramebuffer");return (void)0;}
void m_glValidateProgramARB_trap(GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glValidateProgramARB");return (void)0;}
void m_glTexGenf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexGenf");return (void)0;}
void m_glTexGend_trap(GLenum,GLenum,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTexGend");return (void)0;}
void m_glTexGeni_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexGeni");return (void)0;}
void m_glDeleteFramebuffersEXT_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteFramebuffersEXT");return (void)0;}
void m_glResetMinmaxEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glResetMinmaxEXT");return (void)0;}
void m_glVertexAttrib1fvNV_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1fvNV");return (void)0;}
GLboolean m_glIsQueryARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsQueryARB");return (GLboolean)0;}
void m_glEnableVariantClientStateEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableVariantClientStateEXT");return (void)0;}
void m_glScissorIndexed_trap(GLuint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glScissorIndexed");return (void)0;}
void m_glGetInvariantIntegervEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetInvariantIntegervEXT");return (void)0;}
void m_glProgramLocalParameterI4uiNV_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameterI4uiNV");return (void)0;}
void m_glConvolutionParameterxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterxvOES");return (void)0;}
void m_glGenFramebuffersEXT_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenFramebuffersEXT");return (void)0;}
void m_glVertexArrayColorOffsetEXT_trap(GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayColorOffsetEXT");return (void)0;}
void m_glMultiTexCoord3ivARB_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3ivARB");return (void)0;}
void m_glVertexWeightfEXT_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexWeightfEXT");return (void)0;}
void m_glRasterPos4dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4dv");return (void)0;}
GLboolean m_glIsTextureHandleResidentARB_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glIsTextureHandleResidentARB");return (GLboolean)0;}
void m_glRasterPos2dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2dv");return (void)0;}
void m_glWindowPos4ivMESA_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4ivMESA");return (void)0;}
void m_glGetVariantPointervEXT_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVariantPointervEXT");return (void)0;}
void* m_glMapNamedBufferRangeEXT_trap(GLuint,GLintptr,GLsizeiptr,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMapNamedBufferRangeEXT");return (void*)0;}
void m_glGetnUniformui64vARB_trap(GLuint,GLint,GLsizei,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformui64vARB");return (void)0;}
GLuint m_glCreateShaderProgramv_trap(GLenum,GLsizei,const GLchar*const*)const{this->m_printMissingFunctionErrorAndExit("glCreateShaderProgramv");return (GLuint)0;}
void m_glGetQueryObjectiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectiv");return (void)0;}
void m_glMaxShaderCompilerThreadsKHR_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glMaxShaderCompilerThreadsKHR");return (void)0;}
void m_glPNTrianglesfATI_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPNTrianglesfATI");return (void)0;}
void m_glGlobalAlphaFactorusSUN_trap(GLushort)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactorusSUN");return (void)0;}
void m_glVertexAttrib3dvNV_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3dvNV");return (void)0;}
void m_glMultiTexCoord3sARB_trap(GLenum,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3sARB");return (void)0;}
void m_glGenerateMipmap_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glGenerateMipmap");return (void)0;}
void m_glCompressedTextureSubImage2D_trap(GLuint,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage2D");return (void)0;}
void m_glNamedRenderbufferStorageMultisampleEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNamedRenderbufferStorageMultisampleEXT");return (void)0;}
void m_glPolygonOffsetClampEXT_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPolygonOffsetClampEXT");return (void)0;}
void m_glTextureRangeAPPLE_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureRangeAPPLE");return (void)0;}
void m_glBlendEquationIndexedAMD_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationIndexedAMD");return (void)0;}
void m_glTexCoord2d_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2d");return (void)0;}
void m_glPointParameteri_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPointParameteri");return (void)0;}
void m_glTexCoord2f_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2f");return (void)0;}
void m_glGetUnsignedBytei_vEXT_trap(GLenum,GLuint,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetUnsignedBytei_vEXT");return (void)0;}
void m_glColor4iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glColor4iv");return (void)0;}
void* m_glMapNamedBufferRange_trap(GLuint,GLintptr,GLsizeiptr,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMapNamedBufferRange");return (void*)0;}
GLboolean m_glUnmapBuffer_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glUnmapBuffer");return (GLboolean)0;}
void m_glSampleMaskEXT_trap(GLclampf,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glSampleMaskEXT");return (void)0;}
void m_glTexCoord2i_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2i");return (void)0;}
void m_glTexCoord1xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1xvOES");return (void)0;}
void m_glVertexAttrib1sARB_trap(GLuint,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1sARB");return (void)0;}
void m_glGetVertexArrayiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayiv");return (void)0;}
void m_glProgramParameter4dvNV_trap(GLenum,GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramParameter4dvNV");return (void)0;}
void m_glTexCoord2s_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2s");return (void)0;}
void m_glTextureParameterIuivEXT_trap(GLuint,GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterIuivEXT");return (void)0;}
void m_glGetColorTableParameterfvSGI_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameterfvSGI");return (void)0;}
void m_glTexCoord4dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4dv");return (void)0;}
void m_glVertexAttrib1svNV_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1svNV");return (void)0;}
void m_glNamedFramebufferTextureFaceEXT_trap(GLuint,GLenum,GLuint,GLint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTextureFaceEXT");return (void)0;}
void m_glProgramUniform2ui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ui64vNV");return (void)0;}
void m_glStencilFillPathNV_trap(GLuint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilFillPathNV");return (void)0;}
void m_glNormal3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glNormal3dv");return (void)0;}
void m_glReleaseShaderCompiler_trap()const{this->m_printMissingFunctionErrorAndExit("glReleaseShaderCompiler");return (void)0;}
void m_glTexStorageMem3DEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTexStorageMem3DEXT");return (void)0;}
void m_glTexCoord3bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3bvOES");return (void)0;}
GLboolean m_glIsVertexAttribEnabledAPPLE_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glIsVertexAttribEnabledAPPLE");return (GLboolean)0;}
void m_glTexCoord1dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1dv");return (void)0;}
void m_glReadPixels_trap(GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glReadPixels");return (void)0;}
void m_glVertexAttribI3iv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3iv");return (void)0;}
void m_glSetFenceAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glSetFenceAPPLE");return (void)0;}
void m_glWeightsvARB_trap(GLint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWeightsvARB");return (void)0;}
void m_glShadeModel_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glShadeModel");return (void)0;}
void m_glTextureStorageMem3DMultisampleEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageMem3DMultisampleEXT");return (void)0;}
void m_glMapGrid1d_trap(GLint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMapGrid1d");return (void)0;}
void m_glGetHistogramParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramParameterivEXT");return (void)0;}
void m_glConservativeRasterParameteriNV_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glConservativeRasterParameteriNV");return (void)0;}
void m_glClearNamedBufferData_trap(GLuint,GLenum,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedBufferData");return (void)0;}
void m_glClearDepthf_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glClearDepthf");return (void)0;}
void m_glCreatePerfQueryINTEL_trap(GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreatePerfQueryINTEL");return (void)0;}
void m_glFogCoordfEXT_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFogCoordfEXT");return (void)0;}
void m_glVertexAttrib2dARB_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2dARB");return (void)0;}
void m_glMultiTexCoord4dARB_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4dARB");return (void)0;}
void m_glReadnPixelsARB_trap(GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glReadnPixelsARB");return (void)0;}
void m_glMultiTexBufferEXT_trap(GLenum,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexBufferEXT");return (void)0;}
void m_glWindowPos4dvMESA_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4dvMESA");return (void)0;}
void m_glInvalidateNamedFramebufferData_trap(GLuint,GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glInvalidateNamedFramebufferData");return (void)0;}
void m_glSecondaryColorPointerListIBM_trap(GLint,GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorPointerListIBM");return (void)0;}
void m_glRectiv_trap(const GLint*,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glRectiv");return (void)0;}
void m_glColorP4ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColorP4ui");return (void)0;}
void m_glUseProgramStages_trap(GLuint,GLbitfield,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUseProgramStages");return (void)0;}
void m_glRasterPos3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3dv");return (void)0;}
void m_glPathTexGenNV_trap(GLenum,GLenum,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPathTexGenNV");return (void)0;}
void m_glVertexBlendEnviATI_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexBlendEnviATI");return (void)0;}
void m_glUniform3i64ARB_trap(GLint,GLint64,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glUniform3i64ARB");return (void)0;}
void m_glLoadMatrixf_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glLoadMatrixf");return (void)0;}
void m_glProgramUniform2dEXT_trap(GLuint,GLint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2dEXT");return (void)0;}
void m_glVertexAttribI4iv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4iv");return (void)0;}
void m_glNamedFramebufferDrawBuffer_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferDrawBuffer");return (void)0;}
void m_glColor4ubv_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glColor4ubv");return (void)0;}
void m_glColor3hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glColor3hvNV");return (void)0;}
void m_glGetMapAttribParameterfvNV_trap(GLenum,GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMapAttribParameterfvNV");return (void)0;}
void m_glGetBufferSubData_trap(GLenum,GLintptr,GLsizeiptr,void*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferSubData");return (void)0;}
void m_glGetVertexAttribLdv_trap(GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribLdv");return (void)0;}
void m_glGetnUniformuiv_trap(GLuint,GLint,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformuiv");return (void)0;}
void m_glGetUniformui64vNV_trap(GLuint,GLint,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformui64vNV");return (void)0;}
void m_glNamedRenderbufferStorageEXT_trap(GLuint,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNamedRenderbufferStorageEXT");return (void)0;}
void m_glVertexAttrib3dNV_trap(GLuint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3dNV");return (void)0;}
void m_glTextureStorage1DEXT_trap(GLuint,GLenum,GLsizei,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage1DEXT");return (void)0;}
void m_glPixelTexGenParameteriSGIS_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPixelTexGenParameteriSGIS");return (void)0;}
void m_glColorTableEXT_trap(GLenum,GLenum,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glColorTableEXT");return (void)0;}
void m_glGenBuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenBuffers");return (void)0;}
void m_glMultiTexCoord3xvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3xvOES");return (void)0;}
void m_glExecuteProgramNV_trap(GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glExecuteProgramNV");return (void)0;}
void m_glVariantArrayObjectATI_trap(GLuint,GLenum,GLsizei,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVariantArrayObjectATI");return (void)0;}
void m_glColor3xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glColor3xvOES");return (void)0;}
void m_glGetnConvolutionFilterARB_trap(GLenum,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnConvolutionFilterARB");return (void)0;}
void m_glNormalFormatNV_trap(GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNormalFormatNV");return (void)0;}
void m_glGetInvariantFloatvEXT_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetInvariantFloatvEXT");return (void)0;}
void m_glClearNamedFramebufferiv_trap(GLuint,GLenum,GLint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedFramebufferiv");return (void)0;}
void m_glTexImage3D_trap(GLenum,GLint,GLint,GLsizei,GLsizei,GLsizei,GLint,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexImage3D");return (void)0;}
void m_glGenSamplers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenSamplers");return (void)0;}
GLboolean m_glIsFramebuffer_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsFramebuffer");return (GLboolean)0;}
void m_glProgramUniform3dvEXT_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3dvEXT");return (void)0;}
void m_glGetVertexAttribfvNV_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribfvNV");return (void)0;}
void m_glDrawRangeElementArrayAPPLE_trap(GLenum,GLuint,GLuint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawRangeElementArrayAPPLE");return (void)0;}
void m_glUniform3i64NV_trap(GLint,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform3i64NV");return (void)0;}
void m_glMatrixPopEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glMatrixPopEXT");return (void)0;}
void m_glVertexStream1sATI_trap(GLenum,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1sATI");return (void)0;}
void m_glGetnPixelMapuivARB_trap(GLenum,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapuivARB");return (void)0;}
void m_glMultiTexEnviEXT_trap(GLenum,GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexEnviEXT");return (void)0;}
void m_glVertexAttribI2iEXT_trap(GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2iEXT");return (void)0;}
void m_glProgramParameter4fvNV_trap(GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramParameter4fvNV");return (void)0;}
void m_glWaitSemaphoreEXT_trap(GLuint,GLuint,const GLuint*,GLuint,const GLuint*,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glWaitSemaphoreEXT");return (void)0;}
void m_glNamedFramebufferSampleLocationsfvNV_trap(GLuint,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferSampleLocationsfvNV");return (void)0;}
void m_glTexCoordP4uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP4uiv");return (void)0;}
void m_glRectxvOES_trap(const GLfixed*,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glRectxvOES");return (void)0;}
void m_glGetVariantIntegervEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVariantIntegervEXT");return (void)0;}
void m_glDeleteLists_trap(GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDeleteLists");return (void)0;}
void m_glTexGendv_trap(GLenum,GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glTexGendv");return (void)0;}
void m_glVertexP2uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexP2uiv");return (void)0;}
void m_glGetPerfMonitorGroupsAMD_trap(GLint*,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorGroupsAMD");return (void)0;}
void m_glMultTransposeMatrixfARB_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultTransposeMatrixfARB");return (void)0;}
void m_glVertexAttribI2ivEXT_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2ivEXT");return (void)0;}
void m_glReplacementCodeuiColor4fNormal3fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor4fNormal3fVertex3fvSUN");return (void)0;}
void m_glDeleteStatesNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteStatesNV");return (void)0;}
void m_glGetBufferParameteri64v_trap(GLenum,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferParameteri64v");return (void)0;}
void m_glProgramUniform4dv_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4dv");return (void)0;}
void m_glEdgeFlagPointerEXT_trap(GLsizei,GLsizei,const GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlagPointerEXT");return (void)0;}
void m_glVideoCaptureStreamParameterivNV_trap(GLuint,GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVideoCaptureStreamParameterivNV");return (void)0;}
void m_glVertexStream4iATI_trap(GLenum,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4iATI");return (void)0;}
void m_glVDPAUFiniNV_trap()const{this->m_printMissingFunctionErrorAndExit("glVDPAUFiniNV");return (void)0;}
void m_glMakeBufferNonResidentNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glMakeBufferNonResidentNV");return (void)0;}
void m_glUniform1ui64ARB_trap(GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniform1ui64ARB");return (void)0;}
void m_glStencilStrokePathNV_trap(GLuint,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilStrokePathNV");return (void)0;}
void m_glVariantuivEXT_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVariantuivEXT");return (void)0;}
void m_glCopyTexSubImage3DEXT_trap(GLenum,GLint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage3DEXT");return (void)0;}
void m_glSpriteParameteriSGIX_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glSpriteParameteriSGIX");return (void)0;}
void m_glMultiTexCoord1sARB_trap(GLenum,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1sARB");return (void)0;}
void m_glConvolutionParameterfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterfv");return (void)0;}
void m_glMakeTextureHandleResidentNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeTextureHandleResidentNV");return (void)0;}
void m_glMultMatrixxOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultMatrixxOES");return (void)0;}
void m_glTextureNormalEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glTextureNormalEXT");return (void)0;}
void m_glGetQueryivARB_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryivARB");return (void)0;}
void m_glCompressedMultiTexImage3DEXT_trap(GLenum,GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexImage3DEXT");return (void)0;}
GLint m_glGetInstrumentsSGIX_trap()const{this->m_printMissingFunctionErrorAndExit("glGetInstrumentsSGIX");return (GLint)0;}
void m_glProgramUniformMatrix4x3fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x3fvEXT");return (void)0;}
void m_glPointParameterf_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPointParameterf");return (void)0;}
void m_glProgramUniform3dEXT_trap(GLuint,GLint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3dEXT");return (void)0;}
void m_glMultiTexCoord2hNV_trap(GLenum,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2hNV");return (void)0;}
void m_glGetConvolutionFilterEXT_trap(GLenum,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionFilterEXT");return (void)0;}
void m_glVertexAttrib2hNV_trap(GLuint,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2hNV");return (void)0;}
void m_glCurrentPaletteMatrixARB_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glCurrentPaletteMatrixARB");return (void)0;}
void m_glFogxvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glFogxvOES");return (void)0;}
void m_glCreateRenderbuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateRenderbuffers");return (void)0;}
void m_glVertexAttrib4Nusv_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nusv");return (void)0;}
void m_glCombinerInputNV_trap(GLenum,GLenum,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCombinerInputNV");return (void)0;}
void m_glDepthFunc_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glDepthFunc");return (void)0;}
void m_glWindowPos4fMESA_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4fMESA");return (void)0;}
void m_glEnableClientStateIndexedEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableClientStateIndexedEXT");return (void)0;}
void m_glTexCoord4iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4iv");return (void)0;}
void m_glProgramUniform4i64ARB_trap(GLuint,GLint,GLint64,GLint64,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4i64ARB");return (void)0;}
void m_glBlendFunci_trap(GLuint,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFunci");return (void)0;}
void m_glResolveDepthValuesNV_trap()const{this->m_printMissingFunctionErrorAndExit("glResolveDepthValuesNV");return (void)0;}
void m_glTextureColorMaskSGIS_trap(GLboolean,GLboolean,GLboolean,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureColorMaskSGIS");return (void)0;}
GLuint m_glCreateShaderProgramEXT_trap(GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glCreateShaderProgramEXT");return (GLuint)0;}
void m_glBufferStorage_trap(GLenum,GLsizeiptr,const void*,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glBufferStorage");return (void)0;}
void m_glMakeNamedBufferNonResidentNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glMakeNamedBufferNonResidentNV");return (void)0;}
void m_glRenderbufferStorageMultisampleEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glRenderbufferStorageMultisampleEXT");return (void)0;}
void m_glGetFloati_v_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFloati_v");return (void)0;}
void m_glUniform2ui64ARB_trap(GLint,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniform2ui64ARB");return (void)0;}
void m_glVertex3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertex3fv");return (void)0;}
GLint m_glGetUniformLocation_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformLocation");return (GLint)0;}
void m_glVertexStream1svATI_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1svATI");return (void)0;}
void m_glVertexStream3fATI_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3fATI");return (void)0;}
void m_glNamedFramebufferDrawBuffers_trap(GLuint,GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferDrawBuffers");return (void)0;}
void m_glUniform2ui64vNV_trap(GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform2ui64vNV");return (void)0;}
void m_glTexCoordPointervINTEL_trap(GLint,GLenum,const void**)const{this->m_printMissingFunctionErrorAndExit("glTexCoordPointervINTEL");return (void)0;}
void m_glUniform4fv_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform4fv");return (void)0;}
void m_glNormalPointerEXT_trap(GLenum,GLsizei,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glNormalPointerEXT");return (void)0;}
void m_glVertexAttrib4hNV_trap(GLuint,GLhalfNV,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4hNV");return (void)0;}
void m_glNormal3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glNormal3f");return (void)0;}
void m_glVertexStream2iATI_trap(GLenum,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2iATI");return (void)0;}
void m_glVertexAttribP4uiv_trap(GLuint,GLenum,GLboolean,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP4uiv");return (void)0;}
void m_glCompressedTextureSubImage3D_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage3D");return (void)0;}
void m_glAsyncMarkerSGIX_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glAsyncMarkerSGIX");return (void)0;}
void m_glTextureStorageSparseAMD_trap(GLuint,GLenum,GLenum,GLsizei,GLsizei,GLsizei,GLsizei,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageSparseAMD");return (void)0;}
void m_glGetConvolutionParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionParameterivEXT");return (void)0;}
void m_glEndPerfQueryINTEL_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEndPerfQueryINTEL");return (void)0;}
void m_glFragmentLightModeliSGIX_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightModeliSGIX");return (void)0;}
void m_glPrioritizeTexturesEXT_trap(GLsizei,const GLuint*,const GLclampf*)const{this->m_printMissingFunctionErrorAndExit("glPrioritizeTexturesEXT");return (void)0;}
void m_glEndConditionalRender_trap()const{this->m_printMissingFunctionErrorAndExit("glEndConditionalRender");return (void)0;}
void m_glEnableClientState_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glEnableClientState");return (void)0;}
void m_glResetHistogram_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glResetHistogram");return (void)0;}
void m_glGetOcclusionQueryivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetOcclusionQueryivNV");return (void)0;}
void m_glUniform1uiEXT_trap(GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform1uiEXT");return (void)0;}
void m_glMultiTexCoord2sv_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2sv");return (void)0;}
void m_glTexSubImage2DEXT_trap(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage2DEXT");return (void)0;}
void m_glProgramUniform2uiv_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2uiv");return (void)0;}
void m_glMultiTexCoord2iARB_trap(GLenum,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2iARB");return (void)0;}
void m_glGetQueryObjectuiv_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectuiv");return (void)0;}
void m_glGenerateMultiTexMipmapEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glGenerateMultiTexMipmapEXT");return (void)0;}
void m_glVertexAttrib4iv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4iv");return (void)0;}
void m_glWindowPos3dvMESA_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3dvMESA");return (void)0;}
void m_glLabelObjectEXT_trap(GLenum,GLuint,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glLabelObjectEXT");return (void)0;}
void m_glProgramUniform1uiv_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1uiv");return (void)0;}
void m_glFramebufferTexture_trap(GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture");return (void)0;}
void m_glMultiTexEnvfEXT_trap(GLenum,GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexEnvfEXT");return (void)0;}
void m_glGetTexGendv_trap(GLenum,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetTexGendv");return (void)0;}
void m_glVertex4xOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glVertex4xOES");return (void)0;}
void m_glVertexAttribI2uivEXT_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2uivEXT");return (void)0;}
void m_glNamedProgramLocalParameter4fvEXT_trap(GLuint,GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameter4fvEXT");return (void)0;}
void m_glColor3usv_trap(const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glColor3usv");return (void)0;}
void m_glGetPixelTransformParameterfvEXT_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelTransformParameterfvEXT");return (void)0;}
void m_glIndexxvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glIndexxvOES");return (void)0;}
void m_glDepthMask_trap(GLboolean)const{this->m_printMissingFunctionErrorAndExit("glDepthMask");return (void)0;}
void m_glProgramUniformMatrix2x4fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x4fv");return (void)0;}
GLboolean m_glAreProgramsResidentNV_trap(GLsizei,const GLuint*,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glAreProgramsResidentNV");return (GLboolean)0;}
void m_glColorTable_trap(GLenum,GLenum,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glColorTable");return (void)0;}
void m_glBeginQueryIndexed_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginQueryIndexed");return (void)0;}
void m_glVertexStream1dvATI_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1dvATI");return (void)0;}
void m_glGetMultiTexEnvfvEXT_trap(GLenum,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexEnvfvEXT");return (void)0;}
void m_glDeleteFencesNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteFencesNV");return (void)0;}
void m_glVertexAttribs1dvNV_trap(GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs1dvNV");return (void)0;}
void m_glBufferStorageExternalEXT_trap(GLenum,GLintptr,GLsizeiptr,GLeglClientBufferEXT,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glBufferStorageExternalEXT");return (void)0;}
void m_glVertexStream2sATI_trap(GLenum,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2sATI");return (void)0;}
void m_glGetnSeparableFilterARB_trap(GLenum,GLenum,GLenum,GLsizei,void*,GLsizei,void*,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnSeparableFilterARB");return (void)0;}
void m_glProgramUniform2dv_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2dv");return (void)0;}
void m_glActiveStencilFaceEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glActiveStencilFaceEXT");return (void)0;}
void m_glProgramUniform4dEXT_trap(GLuint,GLint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4dEXT");return (void)0;}
void m_glPointSizexOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPointSizexOES");return (void)0;}
void m_glRasterPos2sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2sv");return (void)0;}
GLuint m_glBindParameterEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindParameterEXT");return (GLuint)0;}
void m_glTexCoord1sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1sv");return (void)0;}
void m_glBlendParameteriNV_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glBlendParameteriNV");return (void)0;}
void m_glNamedProgramLocalParameter4dvEXT_trap(GLuint,GLenum,GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameter4dvEXT");return (void)0;}
void m_glProgramUniformHandleui64NV_trap(GLuint,GLint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformHandleui64NV");return (void)0;}
void m_glGetTextureParameterfvEXT_trap(GLuint,GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterfvEXT");return (void)0;}
void m_glGetPathMetricsNV_trap(GLbitfield,GLsizei,GLenum,const void*,GLuint,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathMetricsNV");return (void)0;}
void m_glVertex2i_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertex2i");return (void)0;}
void m_glNewList_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNewList");return (void)0;}
void m_glMatrixLoad3x3fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoad3x3fNV");return (void)0;}
void m_glMultiTexCoord2fARB_trap(GLenum,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2fARB");return (void)0;}
void m_glWeightdvARB_trap(GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWeightdvARB");return (void)0;}
GLboolean m_glIsTransformFeedbackNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsTransformFeedbackNV");return (GLboolean)0;}
void m_glVertexAttribDivisorARB_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribDivisorARB");return (void)0;}
void m_glSecondaryColorP3uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorP3uiv");return (void)0;}
void m_glGetnCompressedTexImageARB_trap(GLenum,GLint,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnCompressedTexImageARB");return (void)0;}
void m_glGetIntegerv_trap(GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetIntegerv");return (void)0;}
void m_glMatrixLoaddEXT_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoaddEXT");return (void)0;}
GLfloat m_glGetPathLengthNV_trap(GLuint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glGetPathLengthNV");return (GLfloat)0;}
void m_glProgramUniformMatrix3dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3dv");return (void)0;}
void m_glUniform4i64NV_trap(GLint,GLint64EXT,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform4i64NV");return (void)0;}
void m_glGetHistogramEXT_trap(GLenum,GLboolean,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramEXT");return (void)0;}
void m_glVertexAttrib4NuivARB_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NuivARB");return (void)0;}
void m_glMapGrid2xOES_trap(GLint,GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMapGrid2xOES");return (void)0;}
void m_glTexImage2D_trap(GLenum,GLint,GLint,GLsizei,GLsizei,GLint,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexImage2D");return (void)0;}
void m_glWindowPos2fvARB_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2fvARB");return (void)0;}
void m_glEnableIndexedEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableIndexedEXT");return (void)0;}
void m_glTexCoord1bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1bvOES");return (void)0;}
void m_glDrawPixels_trap(GLsizei,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glDrawPixels");return (void)0;}
void m_glMultMatrixd_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultMatrixd");return (void)0;}
void m_glMultMatrixf_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultMatrixf");return (void)0;}
void m_glReplacementCodePointerSUN_trap(GLenum,GLsizei,const void**)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodePointerSUN");return (void)0;}
void m_glLoadTransposeMatrixdARB_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glLoadTransposeMatrixdARB");return (void)0;}
void m_glVertexAttrib4Nubv_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nubv");return (void)0;}
void m_glVertexArrayVertexAttribIOffsetEXT_trap(GLuint,GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribIOffsetEXT");return (void)0;}
void m_glCompileShaderARB_trap(GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glCompileShaderARB");return (void)0;}
void m_glWindowPos3dMESA_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3dMESA");return (void)0;}
void m_glNormalStream3fvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3fvATI");return (void)0;}
void m_glColor4usv_trap(const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glColor4usv");return (void)0;}
void m_glMapGrid1f_trap(GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMapGrid1f");return (void)0;}
void m_glPolygonStipple_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glPolygonStipple");return (void)0;}
void m_glUniform4ui64ARB_trap(GLint,GLuint64,GLuint64,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glUniform4ui64ARB");return (void)0;}
void m_glTextureRenderbufferEXT_trap(GLuint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTextureRenderbufferEXT");return (void)0;}
GLint m_glGetSubroutineUniformLocation_trap(GLuint,GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetSubroutineUniformLocation");return (GLint)0;}
void m_glGetFramebufferParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFramebufferParameteriv");return (void)0;}
void m_glPixelMapusv_trap(GLenum,GLsizei,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glPixelMapusv");return (void)0;}
void m_glGetSamplerParameteriv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetSamplerParameteriv");return (void)0;}
void m_glVertexStream2fvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2fvATI");return (void)0;}
void m_glProgramStringARB_trap(GLenum,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glProgramStringARB");return (void)0;}
void m_glProgramUniformMatrix3dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3dvEXT");return (void)0;}
void m_glSeparableFilter2D_trap(GLenum,GLenum,GLsizei,GLsizei,GLenum,GLenum,const GLvoid*,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glSeparableFilter2D");return (void)0;}
void m_glVertexAttribI1uiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1uiv");return (void)0;}
void m_glLGPUCopyImageSubDataNVX_trap(GLuint,GLbitfield,GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glLGPUCopyImageSubDataNVX");return (void)0;}
void m_glTexStorage2D_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTexStorage2D");return (void)0;}
void m_glColor3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor3fv");return (void)0;}
void m_glGetMultiTexGendvEXT_trap(GLenum,GLenum,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexGendvEXT");return (void)0;}
void m_glVertexAttribL4dvEXT_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4dvEXT");return (void)0;}
void m_glGetActiveUniform_trap(GLuint,GLuint,GLsizei,GLsizei*,GLint*,GLenum*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniform");return (void)0;}
void m_glUniform2ui64vARB_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform2ui64vARB");return (void)0;}
void m_glMakeNamedBufferResidentNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMakeNamedBufferResidentNV");return (void)0;}
GLenum m_glPathGlyphIndexRangeNV_trap(GLenum,const void*,GLbitfield,GLuint,GLfloat,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glPathGlyphIndexRangeNV");return (GLenum)0;}
void m_glColorPointer_trap(GLint,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glColorPointer");return (void)0;}
void m_glProgramEnvParameterI4ivNV_trap(GLenum,GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameterI4ivNV");return (void)0;}
void m_glMulticastGetQueryObjectui64vNV_trap(GLuint,GLuint,GLenum,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glMulticastGetQueryObjectui64vNV");return (void)0;}
void m_glMultiTexParameterfEXT_trap(GLenum,GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameterfEXT");return (void)0;}
void m_glNamedFramebufferTextureLayer_trap(GLuint,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTextureLayer");return (void)0;}
void m_glGetVertexArrayIntegervEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayIntegervEXT");return (void)0;}
void m_glVertexAttrib3dARB_trap(GLuint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3dARB");return (void)0;}
GLboolean m_glVDPAUIsSurfaceNV_trap(GLvdpauSurfaceNV)const{this->m_printMissingFunctionErrorAndExit("glVDPAUIsSurfaceNV");return (GLboolean)0;}
void m_glMultiTexImage1DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexImage1DEXT");return (void)0;}
GLboolean m_glIsAsyncMarkerSGIX_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsAsyncMarkerSGIX");return (GLboolean)0;}
void m_glGetDoublei_vEXT_trap(GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetDoublei_vEXT");return (void)0;}
void m_glUniform2i64NV_trap(GLint,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform2i64NV");return (void)0;}
GLboolean m_glIsCommandListNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsCommandListNV");return (GLboolean)0;}
void m_glUniform3uiEXT_trap(GLint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform3uiEXT");return (void)0;}
void m_glTexParameterIuivEXT_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterIuivEXT");return (void)0;}
void m_glProgramUniformMatrix4fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4fv");return (void)0;}
void m_glVertex2fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertex2fv");return (void)0;}
void m_glVertexAttribL3dEXT_trap(GLuint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3dEXT");return (void)0;}
void m_glFramebufferRenderbuffer_trap(GLenum,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferRenderbuffer");return (void)0;}
GLint m_glGetUniformLocationARB_trap(GLhandleARB,const GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformLocationARB");return (GLint)0;}
void m_glPathParameterfvNV_trap(GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPathParameterfvNV");return (void)0;}
void m_glVertexAttrib3sNV_trap(GLuint,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3sNV");return (void)0;}
void m_glGetDoublei_v_trap(GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetDoublei_v");return (void)0;}
void m_glVertexAttrib1sv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1sv");return (void)0;}
void m_glBindSampler_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindSampler");return (void)0;}
void m_glLineWidth_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glLineWidth");return (void)0;}
void m_glVertexArrayRangeAPPLE_trap(GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayRangeAPPLE");return (void)0;}
void m_glBindBufferOffsetEXT_trap(GLenum,GLuint,GLuint,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glBindBufferOffsetEXT");return (void)0;}
void m_glWeightfvARB_trap(GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWeightfvARB");return (void)0;}
void m_glGetIntegeri_v_trap(GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetIntegeri_v");return (void)0;}
void m_glGetTransformFeedbackVarying_trap(GLuint,GLuint,GLsizei,GLsizei*,GLsizei*,GLenum*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbackVarying");return (void)0;}
void m_glProgramLocalParameter4fvARB_trap(GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameter4fvARB");return (void)0;}
void m_glGetTransformFeedbackVaryingNV_trap(GLuint,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbackVaryingNV");return (void)0;}
void m_glWindowPos2iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2iv");return (void)0;}
void m_glVertexStream1dATI_trap(GLenum,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexStream1dATI");return (void)0;}
void m_glColorFragmentOp2ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColorFragmentOp2ATI");return (void)0;}
void m_glFogiv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glFogiv");return (void)0;}
GLuint64 m_glGetTextureHandleNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetTextureHandleNV");return (GLuint64)0;}
void m_glLightModeliv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glLightModeliv");return (void)0;}
void m_glDepthRangef_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glDepthRangef");return (void)0;}
void m_glGetFragmentMaterialivSGIX_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFragmentMaterialivSGIX");return (void)0;}
void m_glVideoCaptureStreamParameterfvNV_trap(GLuint,GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVideoCaptureStreamParameterfvNV");return (void)0;}
void m_glDeleteProgramsARB_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteProgramsARB");return (void)0;}
void m_glWindowPos3fvARB_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3fvARB");return (void)0;}
void m_glFeedbackBufferxOES_trap(GLsizei,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glFeedbackBufferxOES");return (void)0;}
void m_glGetTexBumpParameterfvATI_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexBumpParameterfvATI");return (void)0;}
void m_glEnablei_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnablei");return (void)0;}
void m_glGetActiveSubroutineName_trap(GLuint,GLenum,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveSubroutineName");return (void)0;}
void m_glDrawBuffersARB_trap(GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glDrawBuffersARB");return (void)0;}
void m_glBindProgramARB_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindProgramARB");return (void)0;}
void m_glEvalCoord1fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1fv");return (void)0;}
void m_glProgramUniform3ui64vARB_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ui64vARB");return (void)0;}
void m_glProgramUniformMatrix2dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2dv");return (void)0;}
void m_glMultiTexCoord2hvNV_trap(GLenum,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2hvNV");return (void)0;}
void m_glGetFloatIndexedvEXT_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFloatIndexedvEXT");return (void)0;}
void m_glSampleCoverageARB_trap(GLfloat,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glSampleCoverageARB");return (void)0;}
void m_glProgramUniform2ui64vARB_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ui64vARB");return (void)0;}
void m_glPixelDataRangeNV_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glPixelDataRangeNV");return (void)0;}
void m_glVertexStream3svATI_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3svATI");return (void)0;}
void m_glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fNormal3fVertex3fvSUN");return (void)0;}
void m_glTexCoord3hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3hvNV");return (void)0;}
void m_glSampleMaski_trap(GLuint,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glSampleMaski");return (void)0;}
void m_glIndexFuncEXT_trap(GLenum,GLclampf)const{this->m_printMissingFunctionErrorAndExit("glIndexFuncEXT");return (void)0;}
void m_glPointParameteriNV_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPointParameteriNV");return (void)0;}
void m_glUniformMatrix3x2fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3x2fv");return (void)0;}
void m_glGetFramebufferParameterivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFramebufferParameterivEXT");return (void)0;}
void m_glUniform2i64ARB_trap(GLint,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glUniform2i64ARB");return (void)0;}
void m_glNamedBufferStorageEXT_trap(GLuint,GLsizeiptr,const void*,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferStorageEXT");return (void)0;}
void m_glNamedFramebufferTexture3DEXT_trap(GLuint,GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTexture3DEXT");return (void)0;}
void m_glVertexAttrib2dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2dv");return (void)0;}
void m_glGetVertexArrayPointervEXT_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayPointervEXT");return (void)0;}
void m_glGetVertexAttribArrayObjectivATI_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribArrayObjectivATI");return (void)0;}
void m_glProgramUniformMatrix3fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3fvEXT");return (void)0;}
void m_glEnableVertexArrayEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexArrayEXT");return (void)0;}
void m_glColorTableParameterfvSGI_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColorTableParameterfvSGI");return (void)0;}
void m_glEdgeFlag_trap(GLboolean)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlag");return (void)0;}
void m_glFogCoordf_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFogCoordf");return (void)0;}
void m_glVertex3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertex3d");return (void)0;}
void m_glVertex3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertex3f");return (void)0;}
void m_glSpriteParameterivSGIX_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glSpriteParameterivSGIX");return (void)0;}
void m_glPathGlyphRangeNV_trap(GLuint,GLenum,const void*,GLbitfield,GLuint,GLsizei,GLenum,GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPathGlyphRangeNV");return (void)0;}
void m_glPrimitiveBoundingBoxARB_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPrimitiveBoundingBoxARB");return (void)0;}
void m_glVertexAttribL3ui64vNV_trap(GLuint,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3ui64vNV");return (void)0;}
void m_glVertex3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertex3s");return (void)0;}
void m_glTexCoordP2ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP2ui");return (void)0;}
void m_glProgramUniform2fvEXT_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2fvEXT");return (void)0;}
void m_glDeletePathsNV_trap(GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDeletePathsNV");return (void)0;}
void m_glPrimitiveRestartIndexNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glPrimitiveRestartIndexNV");return (void)0;}
void m_glTexCoord2fColor3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor3fVertex3fvSUN");return (void)0;}
void m_glTexCoordPointerListIBM_trap(GLint,GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexCoordPointerListIBM");return (void)0;}
void m_glRectxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glRectxOES");return (void)0;}
void m_glCopyNamedBufferSubData_trap(GLuint,GLuint,GLintptr,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glCopyNamedBufferSubData");return (void)0;}
void m_glGenProgramsNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenProgramsNV");return (void)0;}
void m_glFragmentLightfSGIX_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightfSGIX");return (void)0;}
void m_glTexStorage3D_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTexStorage3D");return (void)0;}
void m_glTextureParameteriv_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameteriv");return (void)0;}
void m_glNamedBufferDataEXT_trap(GLuint,GLsizeiptr,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferDataEXT");return (void)0;}
void m_glImportSemaphoreWin32NameEXT_trap(GLuint,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glImportSemaphoreWin32NameEXT");return (void)0;}
void m_glMultiTexCoord3fvARB_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3fvARB");return (void)0;}
void m_glUniformMatrix3x4fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3x4fv");return (void)0;}
void m_glSubpixelPrecisionBiasNV_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glSubpixelPrecisionBiasNV");return (void)0;}
void m_glNormalPointer_trap(GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glNormalPointer");return (void)0;}
void m_glNamedFramebufferTexture_trap(GLuint,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTexture");return (void)0;}
void m_glVertexAttrib4NsvARB_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NsvARB");return (void)0;}
void m_glPassThrough_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPassThrough");return (void)0;}
void m_glSecondaryColorP3ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorP3ui");return (void)0;}
void m_glInvalidateTexSubImage_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glInvalidateTexSubImage");return (void)0;}
GLboolean m_glIsImageHandleResidentARB_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glIsImageHandleResidentARB");return (GLboolean)0;}
void m_glTangent3fvEXT_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTangent3fvEXT");return (void)0;}
void m_glProgramUniformMatrix4x3fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x3fv");return (void)0;}
void m_glBegin_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBegin");return (void)0;}
void m_glEvalCoord2dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2dv");return (void)0;}
void m_glColor3ubv_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glColor3ubv");return (void)0;}
void m_glFogCoordfvEXT_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFogCoordfvEXT");return (void)0;}
void m_glVertexP3ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexP3ui");return (void)0;}
void m_glLightfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glLightfv");return (void)0;}
void m_glVertexAttribL3i64NV_trap(GLuint,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3i64NV");return (void)0;}
void m_glStencilClearTagEXT_trap(GLsizei,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilClearTagEXT");return (void)0;}
void m_glGetActiveUniformName_trap(GLuint,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniformName");return (void)0;}
void m_glTangentPointerEXT_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glTangentPointerEXT");return (void)0;}
void m_glUniform4ui64vNV_trap(GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform4ui64vNV");return (void)0;}
void m_glDebugMessageEnableAMD_trap(GLenum,GLenum,GLsizei,const GLuint*,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageEnableAMD");return (void)0;}
void m_glProgramUniform2ui_trap(GLuint,GLint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ui");return (void)0;}
void m_glCopyTexSubImage2DEXT_trap(GLenum,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage2DEXT");return (void)0;}
void m_glGenRenderbuffersEXT_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenRenderbuffersEXT");return (void)0;}
void m_glNamedProgramLocalParameterI4ivEXT_trap(GLuint,GLenum,GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameterI4ivEXT");return (void)0;}
void m_glMultiTexCoord2f_trap(GLenum,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2f");return (void)0;}
void m_glMapGrid2d_trap(GLint,GLdouble,GLdouble,GLint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMapGrid2d");return (void)0;}
void m_glGetMultiTexParameterIuivEXT_trap(GLenum,GLenum,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexParameterIuivEXT");return (void)0;}
void m_glBlendEquationiARB_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationiARB");return (void)0;}
void m_glTexParameteriv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexParameteriv");return (void)0;}
void m_glUniform4ivARB_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform4ivARB");return (void)0;}
void m_glMatrixOrthoEXT_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMatrixOrthoEXT");return (void)0;}
void m_glVertexArrayVertexBuffer_trap(GLuint,GLuint,GLuint,GLintptr,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexBuffer");return (void)0;}
void m_glProgramLocalParametersI4ivNV_trap(GLenum,GLuint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParametersI4ivNV");return (void)0;}
void m_glProgramUniform4ui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ui64vNV");return (void)0;}
void m_glGetNamedStringivARB_trap(GLint,const GLchar*,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedStringivARB");return (void)0;}
void m_glVertexAttribL1i64vNV_trap(GLuint,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1i64vNV");return (void)0;}
void m_glTransformFeedbackBufferBase_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackBufferBase");return (void)0;}
void m_glIndexsv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glIndexsv");return (void)0;}
void m_glPointParameterivNV_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterivNV");return (void)0;}
void m_glGetDetailTexFuncSGIS_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetDetailTexFuncSGIS");return (void)0;}
void m_glReplacementCodeuiColor3fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor3fVertex3fvSUN");return (void)0;}
void m_glProgramLocalParameter4fARB_trap(GLenum,GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameter4fARB");return (void)0;}
void m_glBitmap_trap(GLsizei,GLsizei,GLfloat,GLfloat,GLfloat,GLfloat,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glBitmap");return (void)0;}
void m_glNamedFramebufferTextureLayerEXT_trap(GLuint,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTextureLayerEXT");return (void)0;}
void m_glMultiTexGenfvEXT_trap(GLenum,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGenfvEXT");return (void)0;}
void m_glGetNamedBufferSubData_trap(GLuint,GLintptr,GLsizeiptr,void*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferSubData");return (void)0;}
void m_glStencilFuncSeparateATI_trap(GLenum,GLenum,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilFuncSeparateATI");return (void)0;}
void m_glProgramUniform2iv_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2iv");return (void)0;}
void m_glGetQueryiv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryiv");return (void)0;}
void m_glTexCoord4f_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4f");return (void)0;}
void m_glMapGrid2f_trap(GLint,GLfloat,GLfloat,GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMapGrid2f");return (void)0;}
void m_glListParameterivSGIX_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glListParameterivSGIX");return (void)0;}
void m_glCreateQueries_trap(GLenum,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateQueries");return (void)0;}
void m_glGetSamplerParameterfv_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetSamplerParameterfv");return (void)0;}
void m_glTexCoord4i_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4i");return (void)0;}
void m_glObjectLabel_trap(GLenum,GLuint,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glObjectLabel");return (void)0;}
void m_glProgramUniform3i64NV_trap(GLuint,GLint,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3i64NV");return (void)0;}
GLuint64 m_glGetTextureHandleARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetTextureHandleARB");return (GLuint64)0;}
void m_glTexCoord4s_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4s");return (void)0;}
void m_glUniform4iARB_trap(GLint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform4iARB");return (void)0;}
void m_glGetUniformIndices_trap(GLuint,GLsizei,const GLchar*const*,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformIndices");return (void)0;}
void m_glMultiTexImage3DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexImage3DEXT");return (void)0;}
void m_glCoverageModulationTableNV_trap(GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCoverageModulationTableNV");return (void)0;}
void m_glPointParameteriv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glPointParameteriv");return (void)0;}
void m_glMultiTexCoord4svARB_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4svARB");return (void)0;}
void m_glNormal3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNormal3fv");return (void)0;}
void m_glProgramUniformMatrix3x4dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x4dvEXT");return (void)0;}
void m_glTexCoord1fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1fv");return (void)0;}
void m_glProgramUniformMatrix4x3dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x3dvEXT");return (void)0;}
void m_glGetActiveVaryingNV_trap(GLuint,GLuint,GLsizei,GLsizei*,GLsizei*,GLenum*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveVaryingNV");return (void)0;}
void m_glUniform1i64vARB_trap(GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform1i64vARB");return (void)0;}
void m_glMultiTexCoord1dv_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1dv");return (void)0;}
void m_glTexCoord3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3fv");return (void)0;}
void m_glMatrixTranslatefEXT_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMatrixTranslatefEXT");return (void)0;}
void m_glProgramUniform1ui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ui64vNV");return (void)0;}
void m_glTextureMaterialEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTextureMaterialEXT");return (void)0;}
void m_glMultiTexCoordP3uiv_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP3uiv");return (void)0;}
void m_glVertexAttribP3ui_trap(GLuint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP3ui");return (void)0;}
void m_glInterpolatePathsNV_trap(GLuint,GLuint,GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glInterpolatePathsNV");return (void)0;}
void m_glTextureBufferRange_trap(GLuint,GLenum,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glTextureBufferRange");return (void)0;}
void m_glVertexAttribL2dEXT_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2dEXT");return (void)0;}
void m_glGetPixelTransformParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelTransformParameterivEXT");return (void)0;}
void m_glTexCoord4xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4xvOES");return (void)0;}
void m_glGetVariantBooleanvEXT_trap(GLuint,GLenum,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetVariantBooleanvEXT");return (void)0;}
void m_glDepthRange_trap(GLclampd,GLclampd)const{this->m_printMissingFunctionErrorAndExit("glDepthRange");return (void)0;}
void m_glGetVertexAttribdvARB_trap(GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribdvARB");return (void)0;}
void m_glGetColorTableParameterfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameterfv");return (void)0;}
void m_glDrawArraysInstancedEXT_trap(GLenum,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysInstancedEXT");return (void)0;}
void m_glDisableClientStateIndexedEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableClientStateIndexedEXT");return (void)0;}
void m_glDrawBuffer_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glDrawBuffer");return (void)0;}
void m_glMultiDrawArraysIndirectBindlessNV_trap(GLenum,const void*,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirectBindlessNV");return (void)0;}
void m_glGetnPixelMapusv_trap(GLenum,GLsizei,GLushort*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapusv");return (void)0;}
void m_glRasterPos3fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3fv");return (void)0;}
void m_glClearBufferuiv_trap(GLenum,GLint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glClearBufferuiv");return (void)0;}
void m_glGetInternalformati64v_trap(GLenum,GLenum,GLenum,GLsizei,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetInternalformati64v");return (void)0;}
void m_glShaderSourceARB_trap(GLhandleARB,GLsizei,const GLcharARB**,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glShaderSourceARB");return (void)0;}
void m_glShaderOp3EXT_trap(GLenum,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glShaderOp3EXT");return (void)0;}
void m_glWindowPos2dvMESA_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2dvMESA");return (void)0;}
void m_glClearIndex_trap(GLfloat)const{this->m_printMissingFunctionErrorAndExit("glClearIndex");return (void)0;}
void m_glProvokingVertexEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glProvokingVertexEXT");return (void)0;}
void m_glVariantubvEXT_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVariantubvEXT");return (void)0;}
void m_glFlush_trap()const{this->m_printMissingFunctionErrorAndExit("glFlush");return (void)0;}
void m_glFramebufferTexture2DEXT_trap(GLenum,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture2DEXT");return (void)0;}
void m_glGetColorTableParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameterivEXT");return (void)0;}
void m_glPresentFrameDualFillNV_trap(GLuint,GLuint64EXT,GLuint,GLuint,GLenum,GLenum,GLuint,GLenum,GLuint,GLenum,GLuint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glPresentFrameDualFillNV");return (void)0;}
GLuint m_glGenVertexShadersEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGenVertexShadersEXT");return (GLuint)0;}
void m_glSpecializeShaderARB_trap(GLuint,const GLchar*,GLuint,const GLuint*,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSpecializeShaderARB");return (void)0;}
void m_glProgramUniformHandleui64vARB_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformHandleui64vARB");return (void)0;}
void m_glDepthRangefOES_trap(GLclampf,GLclampf)const{this->m_printMissingFunctionErrorAndExit("glDepthRangefOES");return (void)0;}
void m_glDeleteVertexArrays_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteVertexArrays");return (void)0;}
void m_glDrawElementsInstancedBaseVertexBaseInstance_trap(GLenum,GLsizei,GLenum,const void*,GLsizei,GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstancedBaseVertexBaseInstance");return (void)0;}
void m_glGetTexLevelParameteriv_trap(GLenum,GLint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexLevelParameteriv");return (void)0;}
void m_glDrawVkImageNV_trap(GLuint64,GLuint,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glDrawVkImageNV");return (void)0;}
void m_glWindowPos3iARB_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3iARB");return (void)0;}
void m_glPrioritizeTextures_trap(GLsizei,const GLuint*,const GLclampf*)const{this->m_printMissingFunctionErrorAndExit("glPrioritizeTextures");return (void)0;}
void m_glWindowPos3fvMESA_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3fvMESA");return (void)0;}
void m_glProgramUniformMatrix3x2dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x2dvEXT");return (void)0;}
void m_glVertex4xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glVertex4xvOES");return (void)0;}
void m_glTexStorage3DMultisample_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexStorage3DMultisample");return (void)0;}
void m_glWindowPos2sARB_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2sARB");return (void)0;}
void m_glStencilOpValueAMD_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glStencilOpValueAMD");return (void)0;}
void m_glProgramVertexLimitNV_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramVertexLimitNV");return (void)0;}
void m_glGetTexParameterPointervAPPLE_trap(GLenum,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterPointervAPPLE");return (void)0;}
void m_glProgramUniform3uivEXT_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3uivEXT");return (void)0;}
void m_glClampColor_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glClampColor");return (void)0;}
void m_glClearStencil_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glClearStencil");return (void)0;}
void m_glTexCoordP1uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP1uiv");return (void)0;}
void m_glVertexAttribs3svNV_trap(GLuint,GLsizei,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs3svNV");return (void)0;}
void m_glMultiTexCoord3fv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3fv");return (void)0;}
void m_glVertexBlendEnvfATI_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexBlendEnvfATI");return (void)0;}
GLboolean m_glIsFenceAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsFenceAPPLE");return (GLboolean)0;}
void m_glGetBufferParameterui64vNV_trap(GLenum,GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferParameterui64vNV");return (void)0;}
void m_glVertexAttribI4bvEXT_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4bvEXT");return (void)0;}
void m_glUniform2fARB_trap(GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform2fARB");return (void)0;}
void m_glStopInstrumentsSGIX_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glStopInstrumentsSGIX");return (void)0;}
void m_glVertexAttrib3fNV_trap(GLuint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3fNV");return (void)0;}
void m_glMapVertexAttrib2dAPPLE_trap(GLuint,GLuint,GLdouble,GLdouble,GLint,GLint,GLdouble,GLdouble,GLint,GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMapVertexAttrib2dAPPLE");return (void)0;}
void m_glVertex2f_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertex2f");return (void)0;}
void m_glCopyTextureImage2DEXT_trap(GLuint,GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureImage2DEXT");return (void)0;}
void m_glVertex2d_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertex2d");return (void)0;}
void m_glSecondaryColor3bvEXT_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3bvEXT");return (void)0;}
void m_glMultiTexCoord4fARB_trap(GLenum,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4fARB");return (void)0;}
void m_glPolygonOffset_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPolygonOffset");return (void)0;}
void m_glTangent3bvEXT_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glTangent3bvEXT");return (void)0;}
void m_glHistogram_trap(GLenum,GLsizei,GLenum,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glHistogram");return (void)0;}
void m_glGetProgramiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramiv");return (void)0;}
void m_glMatrixIndexubvARB_trap(GLint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glMatrixIndexubvARB");return (void)0;}
void m_glVertex2s_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertex2s");return (void)0;}
void m_glGetVertexAttribLui64vNV_trap(GLuint,GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribLui64vNV");return (void)0;}
void m_glGetProgramStringARB_trap(GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramStringARB");return (void)0;}
void m_glFlushMappedBufferRange_trap(GLenum,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glFlushMappedBufferRange");return (void)0;}
void m_glVertexAttribI3uiEXT_trap(GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI3uiEXT");return (void)0;}
void m_glLineWidthxOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glLineWidthxOES");return (void)0;}
void m_glProgramUniformMatrix2fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2fvEXT");return (void)0;}
void m_glGetTextureParameterIuivEXT_trap(GLuint,GLenum,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterIuivEXT");return (void)0;}
void m_glGetMultiTexEnvivEXT_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexEnvivEXT");return (void)0;}
void m_glPixelTexGenParameterivSGIS_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glPixelTexGenParameterivSGIS");return (void)0;}
void m_glGenQueries_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenQueries");return (void)0;}
void m_glGetPixelMapfv_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelMapfv");return (void)0;}
void m_glBlendColorEXT_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glBlendColorEXT");return (void)0;}
void m_glResetMinmax_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glResetMinmax");return (void)0;}
void m_glGetnUniformivARB_trap(GLuint,GLint,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformivARB");return (void)0;}
void m_glVertexBlendARB_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexBlendARB");return (void)0;}
void m_glVertexAttrib4d_trap(GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4d");return (void)0;}
GLint m_glGetVaryingLocationNV_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetVaryingLocationNV");return (GLint)0;}
void m_glGetMapAttribParameterivNV_trap(GLenum,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMapAttribParameterivNV");return (void)0;}
void m_glTexSubImage3D_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage3D");return (void)0;}
void m_glDeleteSamplers_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteSamplers");return (void)0;}
void m_glGetLightxOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetLightxOES");return (void)0;}
void m_glGetVertexAttribArrayObjectfvATI_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribArrayObjectfvATI");return (void)0;}
void m_glVertexArrayNormalOffsetEXT_trap(GLuint,GLuint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayNormalOffsetEXT");return (void)0;}
void m_glGetBufferParameterivARB_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferParameterivARB");return (void)0;}
void m_glGetTextureParameterfv_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterfv");return (void)0;}
void m_glDrawMeshArraysSUN_trap(GLenum,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawMeshArraysSUN");return (void)0;}
void m_glVertexAttrib4dNV_trap(GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4dNV");return (void)0;}
void m_glGetMultisamplefvNV_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMultisamplefvNV");return (void)0;}
void* m_glMapObjectBufferATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glMapObjectBufferATI");return (void*)0;}
void m_glGetPathCommandsNV_trap(GLuint,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetPathCommandsNV");return (void)0;}
void m_glVertexArrayTexCoordOffsetEXT_trap(GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayTexCoordOffsetEXT");return (void)0;}
void m_glGetHistogram_trap(GLenum,GLboolean,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogram");return (void)0;}
void m_glMatrixMode_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glMatrixMode");return (void)0;}
void m_glColorFormatNV_trap(GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glColorFormatNV");return (void)0;}
void m_glProgramUniformui64NV_trap(GLuint,GLint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformui64NV");return (void)0;}
void m_glProgramUniformMatrix4x2fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x2fvEXT");return (void)0;}
void m_glLoadMatrixxOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glLoadMatrixxOES");return (void)0;}
void m_glGetColorTableParameterfvEXT_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameterfvEXT");return (void)0;}
void m_glRasterPos4i_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4i");return (void)0;}
void m_glVertexAttribL2i64NV_trap(GLuint,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2i64NV");return (void)0;}
void m_glBindTextures_trap(GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glBindTextures");return (void)0;}
void m_glMatrixRotatefEXT_trap(GLenum,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMatrixRotatefEXT");return (void)0;}
void m_glGetClipPlanexOES_trap(GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetClipPlanexOES");return (void)0;}
void m_glSecondaryColor3uivEXT_trap(const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3uivEXT");return (void)0;}
void m_glGetPerfQueryInfoINTEL_trap(GLuint,GLuint,GLchar*,GLuint*,GLuint*,GLuint*,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfQueryInfoINTEL");return (void)0;}
void m_glGetDoublev_trap(GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetDoublev");return (void)0;}
void m_glBindBufferRangeEXT_trap(GLenum,GLuint,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glBindBufferRangeEXT");return (void)0;}
void m_glCompressedTexImage2D_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLint,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage2D");return (void)0;}
void* m_glMapBufferARB_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMapBufferARB");return (void*)0;}
void m_glGetPathSpacingNV_trap(GLenum,GLsizei,GLenum,const void*,GLuint,GLfloat,GLfloat,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathSpacingNV");return (void)0;}
void m_glUniform4dv_trap(GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniform4dv");return (void)0;}
void m_glGlobalAlphaFactordSUN_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactordSUN");return (void)0;}
void m_glProgramUniform3dv_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3dv");return (void)0;}
void m_glGetShaderSourceARB_trap(GLhandleARB,GLsizei,GLsizei*,GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetShaderSourceARB");return (void)0;}
void m_glVertexAttrib3dvARB_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3dvARB");return (void)0;}
void m_glInvalidateBufferData_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glInvalidateBufferData");return (void)0;}
void m_glMatrixLoad3x2fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoad3x2fNV");return (void)0;}
void m_glCompressedTextureSubImage1D_trap(GLuint,GLint,GLint,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage1D");return (void)0;}
void m_glTexCoord3xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3xvOES");return (void)0;}
void m_glGenTexturesEXT_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenTexturesEXT");return (void)0;}
void m_glTangent3iEXT_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glTangent3iEXT");return (void)0;}
void m_glClearTexImage_trap(GLuint,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearTexImage");return (void)0;}
void m_glBinormal3bvEXT_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glBinormal3bvEXT");return (void)0;}
void m_glUniform3fv_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform3fv");return (void)0;}
void m_glGetnPixelMapusvARB_trap(GLenum,GLsizei,GLushort*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapusvARB");return (void)0;}
void m_glMemoryObjectParameterivEXT_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMemoryObjectParameterivEXT");return (void)0;}
void m_glGenSemaphoresEXT_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenSemaphoresEXT");return (void)0;}
void m_glMultiTexCoordP1ui_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP1ui");return (void)0;}
void m_glClearNamedBufferDataEXT_trap(GLuint,GLenum,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedBufferDataEXT");return (void)0;}
void m_glUniformMatrix4dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4dv");return (void)0;}
void m_glWindowPos3fMESA_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3fMESA");return (void)0;}
void m_glDeleteRenderbuffers_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteRenderbuffers");return (void)0;}
void m_glGetTextureLevelParameterfvEXT_trap(GLuint,GLenum,GLint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureLevelParameterfvEXT");return (void)0;}
void m_glGetHistogramParameterxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramParameterxvOES");return (void)0;}
void m_glMultiDrawElements_trap(GLenum,const GLsizei*,GLenum,const void*const*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElements");return (void)0;}
void m_glMakeImageHandleNonResidentNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeImageHandleNonResidentNV");return (void)0;}
void m_glTexSubImage1DEXT_trap(GLenum,GLint,GLint,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage1DEXT");return (void)0;}
void m_glNormalStream3dATI_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3dATI");return (void)0;}
void m_glVertexAttribL4i64vNV_trap(GLuint,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4i64vNV");return (void)0;}
void m_glDrawBuffers_trap(GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glDrawBuffers");return (void)0;}
void m_glCopyTextureSubImage1DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage1DEXT");return (void)0;}
void m_glWindowRectanglesEXT_trap(GLenum,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowRectanglesEXT");return (void)0;}
void m_glNamedFramebufferReadBuffer_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferReadBuffer");return (void)0;}
void m_glUniform2i64vARB_trap(GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform2i64vARB");return (void)0;}
void m_glVertexAttribI1uivEXT_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1uivEXT");return (void)0;}
void m_glGetTexGenfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexGenfv");return (void)0;}
void m_glBeginQueryARB_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginQueryARB");return (void)0;}
void m_glUniform1iARB_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform1iARB");return (void)0;}
void m_glVertex4bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertex4bvOES");return (void)0;}
void m_glInvalidateSubFramebuffer_trap(GLenum,GLsizei,const GLenum*,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glInvalidateSubFramebuffer");return (void)0;}
void m_glUniform1fvARB_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform1fvARB");return (void)0;}
GLboolean m_glTestFenceNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glTestFenceNV");return (GLboolean)0;}
void m_glBindTransformFeedback_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindTransformFeedback");return (void)0;}
void m_glMultiTexCoord2iv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2iv");return (void)0;}
void m_glCopyMultiTexSubImage1DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyMultiTexSubImage1DEXT");return (void)0;}
void m_glVariantbvEXT_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVariantbvEXT");return (void)0;}
void m_glTexCoord1hNV_trap(GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1hNV");return (void)0;}
void m_glGenFencesNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenFencesNV");return (void)0;}
void m_glRasterPos3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3iv");return (void)0;}
void m_glVertexAttribL2ui64NV_trap(GLuint,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2ui64NV");return (void)0;}
void m_glMultiTexCoord1hvNV_trap(GLenum,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1hvNV");return (void)0;}
void m_glGetnConvolutionFilter_trap(GLenum,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnConvolutionFilter");return (void)0;}
void m_glNormal3bv_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glNormal3bv");return (void)0;}
void m_glWeightbvARB_trap(GLint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glWeightbvARB");return (void)0;}
void m_glTexCoord4sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4sv");return (void)0;}
void m_glUniform2uiv_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform2uiv");return (void)0;}
void m_glBeginConditionalRenderNVX_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginConditionalRenderNVX");return (void)0;}
void m_glFinish_trap()const{this->m_printMissingFunctionErrorAndExit("glFinish");return (void)0;}
void m_glColorTableParameterfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColorTableParameterfv");return (void)0;}
void m_glFragmentCoverageColorNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glFragmentCoverageColorNV");return (void)0;}
void m_glProgramUniform3ivEXT_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ivEXT");return (void)0;}
void m_glVertexArrayVertexOffsetEXT_trap(GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexOffsetEXT");return (void)0;}
void m_glViewportPositionWScaleNV_trap(GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glViewportPositionWScaleNV");return (void)0;}
void m_glGetProgramLocalParameterIuivNV_trap(GLenum,GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramLocalParameterIuivNV");return (void)0;}
void m_glReplacementCodeuiTexCoord2fVertex3fvSUN_trap(const GLuint*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiTexCoord2fVertex3fvSUN");return (void)0;}
void m_glUniform1uiv_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform1uiv");return (void)0;}
void m_glUniformMatrix2dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2dv");return (void)0;}
void m_glIndexdv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glIndexdv");return (void)0;}
void m_glSecondaryColor3ivEXT_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ivEXT");return (void)0;}
void m_glTexCoord3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3iv");return (void)0;}
void m_glVertexStream4fvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4fvATI");return (void)0;}
void m_glDeformationMap3fSGIX_trap(GLenum,GLfloat,GLfloat,GLint,GLint,GLfloat,GLfloat,GLint,GLint,GLfloat,GLfloat,GLint,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glDeformationMap3fSGIX");return (void)0;}
void m_glClearDepth_trap(GLclampd)const{this->m_printMissingFunctionErrorAndExit("glClearDepth");return (void)0;}
GLuint m_glGenAsyncMarkersSGIX_trap(GLsizei)const{this->m_printMissingFunctionErrorAndExit("glGenAsyncMarkersSGIX");return (GLuint)0;}
void m_glDisableIndexedEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableIndexedEXT");return (void)0;}
void m_glVertexWeightfvEXT_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexWeightfvEXT");return (void)0;}
void m_glGetProgramLocalParameterIivNV_trap(GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramLocalParameterIivNV");return (void)0;}
void m_glCompressedTexImage3DARB_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage3DARB");return (void)0;}
void m_glProgramParameter4fNV_trap(GLenum,GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramParameter4fNV");return (void)0;}
void m_glConvolutionParameterxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterxOES");return (void)0;}
void m_glInsertComponentEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glInsertComponentEXT");return (void)0;}
void m_glCreateTextures_trap(GLenum,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateTextures");return (void)0;}
void m_glSecondaryColor3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3iv");return (void)0;}
void m_glCreateBuffers_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateBuffers");return (void)0;}
void m_glMultiTexCoord2xvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2xvOES");return (void)0;}
void m_glTexGenxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexGenxvOES");return (void)0;}
void m_glMultTransposeMatrixf_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultTransposeMatrixf");return (void)0;}
void m_glBeginTransformFeedbackEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBeginTransformFeedbackEXT");return (void)0;}
void m_glTexCoord2fColor3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor3fVertex3fSUN");return (void)0;}
void m_glNormal3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glNormal3sv");return (void)0;}
void m_glFreeObjectBufferATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glFreeObjectBufferATI");return (void)0;}
void m_glBlendBarrierNV_trap()const{this->m_printMissingFunctionErrorAndExit("glBlendBarrierNV");return (void)0;}
void m_glUniform4i64vNV_trap(GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform4i64vNV");return (void)0;}
void m_glGetnUniformuivARB_trap(GLuint,GLint,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformuivARB");return (void)0;}
void m_glAlphaFragmentOp3ATI_trap(GLenum,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glAlphaFragmentOp3ATI");return (void)0;}
void m_glProgramEnvParameters4fvEXT_trap(GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameters4fvEXT");return (void)0;}
void m_glBlendFuncSeparateEXT_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparateEXT");return (void)0;}
void m_glConvolutionParameterivEXT_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterivEXT");return (void)0;}
void m_glPixelTexGenSGIX_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glPixelTexGenSGIX");return (void)0;}
void m_glDeleteProgram_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDeleteProgram");return (void)0;}
void m_glUniformMatrix4x3dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4x3dv");return (void)0;}
void m_glGetVideoCaptureStreamivNV_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoCaptureStreamivNV");return (void)0;}
void m_glProgramUniform4uiEXT_trap(GLuint,GLint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4uiEXT");return (void)0;}
void m_glMakeImageHandleNonResidentARB_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glMakeImageHandleNonResidentARB");return (void)0;}
void m_glSecondaryColor3dEXT_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3dEXT");return (void)0;}
void m_glDeleteQueries_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteQueries");return (void)0;}
void m_glNormalP3uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glNormalP3uiv");return (void)0;}
void m_glRasterPos2d_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2d");return (void)0;}
void m_glInitNames_trap()const{this->m_printMissingFunctionErrorAndExit("glInitNames");return (void)0;}
void m_glBinormal3fvEXT_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glBinormal3fvEXT");return (void)0;}
void m_glColor3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glColor3dv");return (void)0;}
void m_glVertexArrayVertexAttribDivisorEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribDivisorEXT");return (void)0;}
void m_glArrayElementEXT_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glArrayElementEXT");return (void)0;}
void m_glProgramParameter4dNV_trap(GLenum,GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramParameter4dNV");return (void)0;}
void m_glIndexxOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glIndexxOES");return (void)0;}
void m_glUniform3uivEXT_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform3uivEXT");return (void)0;}
void m_glPopGroupMarkerEXT_trap()const{this->m_printMissingFunctionErrorAndExit("glPopGroupMarkerEXT");return (void)0;}
void m_glClearNamedFramebufferuiv_trap(GLuint,GLenum,GLint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedFramebufferuiv");return (void)0;}
void m_glSetLocalConstantEXT_trap(GLuint,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glSetLocalConstantEXT");return (void)0;}
void m_glProgramUniform1ui64NV_trap(GLuint,GLint,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1ui64NV");return (void)0;}
void m_glColor4hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glColor4hvNV");return (void)0;}
void m_glGetVertexAttribfv_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribfv");return (void)0;}
void m_glDispatchCompute_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDispatchCompute");return (void)0;}
void m_glGetActiveAttrib_trap(GLuint,GLuint,GLsizei,GLsizei*,GLint*,GLenum*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveAttrib");return (void)0;}
void m_glFragmentColorMaterialSGIX_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFragmentColorMaterialSGIX");return (void)0;}
void m_glTexSubImage2D_trap(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage2D");return (void)0;}
void m_glGetnMinmaxARB_trap(GLenum,GLboolean,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnMinmaxARB");return (void)0;}
void m_glLogicOp_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glLogicOp");return (void)0;}
void m_glProgramUniformMatrix3x4fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x4fv");return (void)0;}
void m_glWindowPos4iMESA_trap(GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4iMESA");return (void)0;}
void m_glPixelTransferf_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPixelTransferf");return (void)0;}
void m_glGetTextureParameterIuiv_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterIuiv");return (void)0;}
void m_glMultiTexCoord1xOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1xOES");return (void)0;}
void m_glProgramUniformMatrix4dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4dv");return (void)0;}
void m_glGetnUniformiv_trap(GLuint,GLint,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformiv");return (void)0;}
void m_glFramebufferTexture1DEXT_trap(GLenum,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture1DEXT");return (void)0;}
void m_glVertexPointervINTEL_trap(GLint,GLenum,const void**)const{this->m_printMissingFunctionErrorAndExit("glVertexPointervINTEL");return (void)0;}
void m_glTextureParameterIiv_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterIiv");return (void)0;}
void m_glGetSeparableFilterEXT_trap(GLenum,GLenum,GLenum,void*,void*,void*)const{this->m_printMissingFunctionErrorAndExit("glGetSeparableFilterEXT");return (void)0;}
void m_glMultiTexCoord3iARB_trap(GLenum,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3iARB");return (void)0;}
void m_glRasterPos4xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4xvOES");return (void)0;}
void m_glDrawTransformFeedbackStream_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawTransformFeedbackStream");return (void)0;}
void m_glVertex3hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertex3hvNV");return (void)0;}
void m_glVertexArrayMultiTexCoordOffsetEXT_trap(GLuint,GLuint,GLenum,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayMultiTexCoordOffsetEXT");return (void)0;}
void m_glProvokingVertex_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glProvokingVertex");return (void)0;}
void m_glAccumxOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glAccumxOES");return (void)0;}
void m_glShaderBinary_trap(GLsizei,const GLuint*,GLenum,const void*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glShaderBinary");return (void)0;}
void m_glGetMultiTexGenivEXT_trap(GLenum,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexGenivEXT");return (void)0;}
void m_glPointParameterxvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterxvOES");return (void)0;}
void m_glCreateStatesNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateStatesNV");return (void)0;}
void m_glClearDepthdNV_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glClearDepthdNV");return (void)0;}
void m_glClearColorIuiEXT_trap(GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glClearColorIuiEXT");return (void)0;}
void m_glBindMultiTextureEXT_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindMultiTextureEXT");return (void)0;}
void m_glTexGeniv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexGeniv");return (void)0;}
void m_glDrawElements_trap(GLenum,GLsizei,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glDrawElements");return (void)0;}
void m_glProgramUniform4iv_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4iv");return (void)0;}
void m_glDisableVertexArrayEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexArrayEXT");return (void)0;}
void m_glProgramUniform3ui64NV_trap(GLuint,GLint,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ui64NV");return (void)0;}
void m_glClientActiveTexture_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glClientActiveTexture");return (void)0;}
void m_glMultiTexParameterIivEXT_trap(GLenum,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameterIivEXT");return (void)0;}
void m_glUniform1i64ARB_trap(GLint,GLint64)const{this->m_printMissingFunctionErrorAndExit("glUniform1i64ARB");return (void)0;}
void m_glUniform1iv_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform1iv");return (void)0;}
void m_glMulticastBarrierNV_trap()const{this->m_printMissingFunctionErrorAndExit("glMulticastBarrierNV");return (void)0;}
void m_glVertexAttribArrayObjectATI_trap(GLuint,GLint,GLenum,GLboolean,GLsizei,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribArrayObjectATI");return (void)0;}
void m_glUniform2iARB_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform2iARB");return (void)0;}
void m_glDrawArraysInstanced_trap(GLenum,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysInstanced");return (void)0;}
void m_glVertexAttrib2sNV_trap(GLuint,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2sNV");return (void)0;}
void m_glTexBufferEXT_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexBufferEXT");return (void)0;}
void m_glVertexStream2fATI_trap(GLenum,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2fATI");return (void)0;}
void m_glDebugMessageCallbackAMD_trap(GLDEBUGPROCAMD,void*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageCallbackAMD");return (void)0;}
void m_glSamplerParameteriv_trap(GLuint,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameteriv");return (void)0;}
void m_glVertexAttrib4uiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4uiv");return (void)0;}
void m_glEndQueryIndexed_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEndQueryIndexed");return (void)0;}
void m_glNormalStream3sATI_trap(GLenum,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3sATI");return (void)0;}
void m_glProgramParameteriARB_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramParameteriARB");return (void)0;}
void m_glTexEnvxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexEnvxOES");return (void)0;}
void m_glProgramUniform1iv_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1iv");return (void)0;}
void m_glDisableVertexAttribAPPLE_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexAttribAPPLE");return (void)0;}
void m_glBindRenderbuffer_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindRenderbuffer");return (void)0;}
void m_glMultiTexSubImage3DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexSubImage3DEXT");return (void)0;}
GLboolean m_glIsProgram_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsProgram");return (GLboolean)0;}
void m_glMultiDrawElementsIndirectAMD_trap(GLenum,GLenum,const void*,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirectAMD");return (void)0;}
void m_glGetProgramInfoLog_trap(GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramInfoLog");return (void)0;}
void m_glGetLocalConstantBooleanvEXT_trap(GLuint,GLenum,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetLocalConstantBooleanvEXT");return (void)0;}
void m_glPixelTransformParameteriEXT_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPixelTransformParameteriEXT");return (void)0;}
void m_glTexCoord4bOES_trap(GLbyte,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4bOES");return (void)0;}
void m_glVertexAttrib4fv_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4fv");return (void)0;}
void m_glProgramUniformMatrix2x3dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x3dv");return (void)0;}
void m_glProgramEnvParametersI4uivNV_trap(GLenum,GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParametersI4uivNV");return (void)0;}
void m_glTexCoord3xOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3xOES");return (void)0;}
void m_glLoadTransposeMatrixfARB_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glLoadTransposeMatrixfARB");return (void)0;}
void m_glImageTransformParameteriHP_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glImageTransformParameteriHP");return (void)0;}
void m_glMultiTexCoord4xOES_trap(GLenum,GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4xOES");return (void)0;}
void m_glVertexAttribs3fvNV_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs3fvNV");return (void)0;}
void m_glVertexAttrib2fv_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2fv");return (void)0;}
void m_glUniform3ui64NV_trap(GLint,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform3ui64NV");return (void)0;}
void m_glCombinerParameterfvNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCombinerParameterfvNV");return (void)0;}
void m_glFragmentMaterialiSGIX_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFragmentMaterialiSGIX");return (void)0;}
void m_glGetBooleani_v_trap(GLenum,GLuint,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetBooleani_v");return (void)0;}
GLuint m_glGetProgramResourceIndex_trap(GLuint,GLenum,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourceIndex");return (GLuint)0;}
void m_glBeginConditionalRenderNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBeginConditionalRenderNV");return (void)0;}
void m_glDisableClientState_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glDisableClientState");return (void)0;}
void m_glPathFogGenNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glPathFogGenNV");return (void)0;}
void m_glStencilThenCoverFillPathNV_trap(GLuint,GLenum,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStencilThenCoverFillPathNV");return (void)0;}
void m_glVertexArrayIndexOffsetEXT_trap(GLuint,GLuint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayIndexOffsetEXT");return (void)0;}
void m_glProgramBufferParametersIuivNV_trap(GLenum,GLuint,GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramBufferParametersIuivNV");return (void)0;}
void m_glPixelTransformParameterivEXT_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glPixelTransformParameterivEXT");return (void)0;}
void m_glDisableClientStateiEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableClientStateiEXT");return (void)0;}
void m_glTexBufferARB_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexBufferARB");return (void)0;}
void m_glGetLocalConstantIntegervEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetLocalConstantIntegervEXT");return (void)0;}
void m_glColor4uiv_trap(const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glColor4uiv");return (void)0;}
void m_glProgramUniform3i_trap(GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3i");return (void)0;}
void m_glMultiDrawElementsIndirectBindlessCountNV_trap(GLenum,GLenum,const void*,GLsizei,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirectBindlessCountNV");return (void)0;}
void m_glGetBufferPointervARB_trap(GLenum,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetBufferPointervARB");return (void)0;}
void m_glMultiTexParameterIuivEXT_trap(GLenum,GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameterIuivEXT");return (void)0;}
void m_glEvalMesh2_trap(GLenum,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glEvalMesh2");return (void)0;}
void m_glEvalMesh1_trap(GLenum,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glEvalMesh1");return (void)0;}
void m_glProgramUniform3f_trap(GLuint,GLint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3f");return (void)0;}
void m_glStencilThenCoverFillPathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLenum,GLuint,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glStencilThenCoverFillPathInstancedNV");return (void)0;}
void m_glProgramUniform3d_trap(GLuint,GLint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3d");return (void)0;}
void m_glMapVertexAttrib1dAPPLE_trap(GLuint,GLuint,GLdouble,GLdouble,GLint,GLint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMapVertexAttrib1dAPPLE");return (void)0;}
void m_glEvalCoord2fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2fv");return (void)0;}
void m_glGetUniformivARB_trap(GLhandleARB,GLint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformivARB");return (void)0;}
void m_glLoadTransposeMatrixd_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glLoadTransposeMatrixd");return (void)0;}
void m_glLoadTransposeMatrixf_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glLoadTransposeMatrixf");return (void)0;}
void m_glGetPointervEXT_trap(GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetPointervEXT");return (void)0;}
void m_glSignalVkSemaphoreNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glSignalVkSemaphoreNV");return (void)0;}
void m_glEndConditionalRenderNV_trap()const{this->m_printMissingFunctionErrorAndExit("glEndConditionalRenderNV");return (void)0;}
void m_glTexCoord2fNormal3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fNormal3fVertex3fSUN");return (void)0;}
void m_glUniform3i64vARB_trap(GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform3i64vARB");return (void)0;}
void m_glProgramUniform2uiEXT_trap(GLuint,GLint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2uiEXT");return (void)0;}
void m_glVertexAttribI1ui_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1ui");return (void)0;}
void m_glProgramNamedParameter4dvNV_trap(GLuint,GLsizei,const GLubyte*,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramNamedParameter4dvNV");return (void)0;}
void m_glCompileCommandListNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glCompileCommandListNV");return (void)0;}
void m_glGetRenderbufferParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetRenderbufferParameterivEXT");return (void)0;}
void m_glGetnPolygonStipple_trap(GLsizei,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetnPolygonStipple");return (void)0;}
GLboolean m_glIsBufferResidentNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glIsBufferResidentNV");return (GLboolean)0;}
void m_glSecondaryColor3ubvEXT_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ubvEXT");return (void)0;}
void m_glGetNamedRenderbufferParameterivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedRenderbufferParameterivEXT");return (void)0;}
void m_glNamedFramebufferSampleLocationsfvARB_trap(GLuint,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferSampleLocationsfvARB");return (void)0;}
void m_glMultiTexGendvEXT_trap(GLenum,GLenum,GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGendvEXT");return (void)0;}
void m_glVertexArrayRangeNV_trap(GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayRangeNV");return (void)0;}
GLboolean m_glIsTextureHandleResidentNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glIsTextureHandleResidentNV");return (GLboolean)0;}
void m_glGetProgramEnvParameterdvARB_trap(GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramEnvParameterdvARB");return (void)0;}
GLboolean m_glIsNamedStringARB_trap(GLint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glIsNamedStringARB");return (GLboolean)0;}
void m_glSecondaryColorFormatNV_trap(GLint,GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorFormatNV");return (void)0;}
void m_glVertexAttrib4ubvNV_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4ubvNV");return (void)0;}
void m_glTagSampleBufferSGIX_trap()const{this->m_printMissingFunctionErrorAndExit("glTagSampleBufferSGIX");return (void)0;}
void m_glVDPAUUnregisterSurfaceNV_trap(GLvdpauSurfaceNV)const{this->m_printMissingFunctionErrorAndExit("glVDPAUUnregisterSurfaceNV");return (void)0;}
void m_glGetPerfQueryIdByNameINTEL_trap(GLchar*,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfQueryIdByNameINTEL");return (void)0;}
void m_glGetInteger64v_trap(GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetInteger64v");return (void)0;}
void m_glClipPlane_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glClipPlane");return (void)0;}
void m_glColor4ubVertex3fSUN_trap(GLubyte,GLubyte,GLubyte,GLubyte,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor4ubVertex3fSUN");return (void)0;}
void m_glIndexub_trap(GLubyte)const{this->m_printMissingFunctionErrorAndExit("glIndexub");return (void)0;}
void m_glGetProgramEnvParameterfvARB_trap(GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramEnvParameterfvARB");return (void)0;}
void m_glVertexAttrib4usvARB_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4usvARB");return (void)0;}
void m_glNamedFramebufferRenderbuffer_trap(GLuint,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferRenderbuffer");return (void)0;}
void m_glProgramUniformMatrix3x4dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x4dv");return (void)0;}
GLboolean m_glTestFenceAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glTestFenceAPPLE");return (GLboolean)0;}
void m_glVertexAttrib4Niv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Niv");return (void)0;}
void m_glVertexAttribL2i64vNV_trap(GLuint,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL2i64vNV");return (void)0;}
void m_glColorP4uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glColorP4uiv");return (void)0;}
void m_glUniformMatrix2x3fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2x3fv");return (void)0;}
void m_glCallCommandListNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glCallCommandListNV");return (void)0;}
void m_glClearBufferiv_trap(GLenum,GLint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glClearBufferiv");return (void)0;}
void m_glNamedStringARB_trap(GLenum,GLint,const GLchar*,GLint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glNamedStringARB");return (void)0;}
void m_glMatrixMult3x2fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMult3x2fNV");return (void)0;}
void m_glGetNamedProgramStringEXT_trap(GLuint,GLenum,GLenum,void*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramStringEXT");return (void)0;}
void m_glGetnHistogramARB_trap(GLenum,GLboolean,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnHistogramARB");return (void)0;}
void m_glGetTextureLevelParameterfv_trap(GLuint,GLint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureLevelParameterfv");return (void)0;}
void m_glMultiTexCoord1fv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1fv");return (void)0;}
void m_glBitmapxOES_trap(GLsizei,GLsizei,GLfixed,GLfixed,GLfixed,GLfixed,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glBitmapxOES");return (void)0;}
void m_glGetSamplerParameterIuiv_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetSamplerParameterIuiv");return (void)0;}
void m_glTexCoordP3ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP3ui");return (void)0;}
void m_glTextureSubImage1D_trap(GLuint,GLint,GLint,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage1D");return (void)0;}
void m_glVertexAttribLPointerEXT_trap(GLuint,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribLPointerEXT");return (void)0;}
void m_glFogCoordPointerEXT_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glFogCoordPointerEXT");return (void)0;}
void m_glWindowPos3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3s");return (void)0;}
void m_glVertexAttribs2svNV_trap(GLuint,GLsizei,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs2svNV");return (void)0;}
void m_glTextureImage3DEXT_trap(GLuint,GLenum,GLint,GLint,GLsizei,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureImage3DEXT");return (void)0;}
void m_glWindowPos3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3i");return (void)0;}
void m_glWindowPos3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3d");return (void)0;}
void m_glWindowPos3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3f");return (void)0;}
GLboolean m_glIsEnabledIndexedEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsEnabledIndexedEXT");return (GLboolean)0;}
void m_glGetNamedProgramivEXT_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramivEXT");return (void)0;}
void m_glVertex3xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glVertex3xvOES");return (void)0;}
void m_glColor3us_trap(GLushort,GLushort,GLushort)const{this->m_printMissingFunctionErrorAndExit("glColor3us");return (void)0;}
void m_glBeginPerfMonitorAMD_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginPerfMonitorAMD");return (void)0;}
void m_glProgramUniformMatrix4x3dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x3dv");return (void)0;}
void m_glGetNamedProgramLocalParameterIuivEXT_trap(GLuint,GLenum,GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramLocalParameterIuivEXT");return (void)0;}
void m_glReadnPixels_trap(GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glReadnPixels");return (void)0;}
void m_glMultiTexCoord4f_trap(GLenum,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4f");return (void)0;}
void m_glColor3ub_trap(GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glColor3ub");return (void)0;}
void m_glMultiTexCoord4d_trap(GLenum,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4d");return (void)0;}
void m_glVertexAttribL3ui64NV_trap(GLuint,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL3ui64NV");return (void)0;}
void m_glColor3ui_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColor3ui");return (void)0;}
void m_glProgramUniform4fvEXT_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4fvEXT");return (void)0;}
void m_glVertexAttrib2sARB_trap(GLuint,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2sARB");return (void)0;}
void m_glMultiTexCoord4i_trap(GLenum,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4i");return (void)0;}
GLenum m_glCheckFramebufferStatusEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glCheckFramebufferStatusEXT");return (GLenum)0;}
void m_glGetnMapivARB_trap(GLenum,GLenum,GLsizei,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapivARB");return (void)0;}
void m_glMultiTexCoord1ivARB_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1ivARB");return (void)0;}
void m_glDisableVertexAttribArrayARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexAttribArrayARB");return (void)0;}
void m_glGetPolygonStipple_trap(GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetPolygonStipple");return (void)0;}
void m_glVertexAttribI4ui_trap(GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4ui");return (void)0;}
void m_glGetPathDashArrayNV_trap(GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathDashArrayNV");return (void)0;}
void m_glMultiTexRenderbufferEXT_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexRenderbufferEXT");return (void)0;}
void m_glCopyTextureSubImage1D_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage1D");return (void)0;}
void m_glDeleteOcclusionQueriesNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteOcclusionQueriesNV");return (void)0;}
void m_glVertex4hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertex4hvNV");return (void)0;}
void m_glGetnTexImage_trap(GLenum,GLint,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnTexImage");return (void)0;}
void m_glProgramLocalParameter4dARB_trap(GLenum,GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameter4dARB");return (void)0;}
void m_glBlendEquation_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquation");return (void)0;}
void m_glUnlockArraysEXT_trap()const{this->m_printMissingFunctionErrorAndExit("glUnlockArraysEXT");return (void)0;}
void m_glGetQueryObjectui64vEXT_trap(GLuint,GLenum,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectui64vEXT");return (void)0;}
void m_glVertexAttribI4uivEXT_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4uivEXT");return (void)0;}
void m_glUniform1i64vNV_trap(GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform1i64vNV");return (void)0;}
void m_glMultiTexCoord3dv_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3dv");return (void)0;}
void m_glColor4sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glColor4sv");return (void)0;}
void m_glVertexStream4ivATI_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4ivATI");return (void)0;}
void m_glPopClientAttrib_trap()const{this->m_printMissingFunctionErrorAndExit("glPopClientAttrib");return (void)0;}
void m_glClearBufferData_trap(GLenum,GLenum,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearBufferData");return (void)0;}
void m_glGetProgramivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramivNV");return (void)0;}
void m_glBeginTransformFeedback_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBeginTransformFeedback");return (void)0;}
void m_glFinishObjectAPPLE_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFinishObjectAPPLE");return (void)0;}
void m_glGetMinmaxParameterivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmaxParameterivEXT");return (void)0;}
void m_glColor3iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glColor3iv");return (void)0;}
void m_glVertexAttrib3sv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3sv");return (void)0;}
void m_glCompressedTexImage1D_trap(GLenum,GLint,GLenum,GLsizei,GLint,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage1D");return (void)0;}
void m_glDeleteTransformFeedbacks_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteTransformFeedbacks");return (void)0;}
void m_glGetVideoi64vNV_trap(GLuint,GLenum,GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoi64vNV");return (void)0;}
void m_glDrawRangeElementsBaseVertex_trap(GLenum,GLuint,GLuint,GLsizei,GLenum,const void*,GLint)const{this->m_printMissingFunctionErrorAndExit("glDrawRangeElementsBaseVertex");return (void)0;}
void m_glUniform4i64vARB_trap(GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform4i64vARB");return (void)0;}
void m_glTextureStorage3DMultisampleEXT_trap(GLuint,GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage3DMultisampleEXT");return (void)0;}
void m_glGetTexParameterfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterfv");return (void)0;}
void m_glProgramUniformui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformui64vNV");return (void)0;}
void m_glCompressedMultiTexImage1DEXT_trap(GLenum,GLenum,GLint,GLenum,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexImage1DEXT");return (void)0;}
void m_glProgramUniform2ivEXT_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ivEXT");return (void)0;}
void m_glPushGroupMarkerEXT_trap(GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glPushGroupMarkerEXT");return (void)0;}
void m_glVertexAttrib1dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1dv");return (void)0;}
void m_glMatrixLoadIdentityEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoadIdentityEXT");return (void)0;}
void m_glMultTransposeMatrixxOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultTransposeMatrixxOES");return (void)0;}
void m_glGetPixelMapxv_trap(GLenum,GLint,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetPixelMapxv");return (void)0;}
void m_glFramebufferSampleLocationsfvARB_trap(GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFramebufferSampleLocationsfvARB");return (void)0;}
void m_glGetLightiv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetLightiv");return (void)0;}
void m_glBlendFuncSeparatei_trap(GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparatei");return (void)0;}
GLboolean m_glAcquireKeyedMutexWin32EXT_trap(GLuint,GLuint64,GLuint)const{this->m_printMissingFunctionErrorAndExit("glAcquireKeyedMutexWin32EXT");return (GLboolean)0;}
void m_glGetBooleanIndexedvEXT_trap(GLenum,GLuint,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glGetBooleanIndexedvEXT");return (void)0;}
void m_glGetProgramSubroutineParameteruivNV_trap(GLenum,GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramSubroutineParameteruivNV");return (void)0;}
void m_glUniform2ui_trap(GLint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform2ui");return (void)0;}
void m_glApplyFramebufferAttachmentCMAAINTEL_trap()const{this->m_printMissingFunctionErrorAndExit("glApplyFramebufferAttachmentCMAAINTEL");return (void)0;}
void m_glWindowPos2fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2fv");return (void)0;}
void m_glWaitVkSemaphoreNV_trap(GLuint64)const{this->m_printMissingFunctionErrorAndExit("glWaitVkSemaphoreNV");return (void)0;}
void m_glDisablei_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisablei");return (void)0;}
void m_glSelectPerfMonitorCountersAMD_trap(GLuint,GLboolean,GLuint,GLint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSelectPerfMonitorCountersAMD");return (void)0;}
void m_glGetVertexAttribLi64vNV_trap(GLuint,GLenum,GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribLi64vNV");return (void)0;}
void m_glBlendFuncSeparateiARB_trap(GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparateiARB");return (void)0;}
void m_glWeightuivARB_trap(GLint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glWeightuivARB");return (void)0;}
void m_glWindowPos2iARB_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2iARB");return (void)0;}
void m_glGetProgramLocalParameterdvARB_trap(GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramLocalParameterdvARB");return (void)0;}
void m_glGetUniformui64vARB_trap(GLuint,GLint,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformui64vARB");return (void)0;}
void m_glSecondaryColor3us_trap(GLushort,GLushort,GLushort)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3us");return (void)0;}
void m_glGetSynciv_trap(GLsync,GLenum,GLsizei,GLsizei*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetSynciv");return (void)0;}
void m_glMakeImageHandleResidentARB_trap(GLuint64,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMakeImageHandleResidentARB");return (void)0;}
void m_glGetProgramNamedParameterfvNV_trap(GLuint,GLsizei,const GLubyte*,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramNamedParameterfvNV");return (void)0;}
void m_glTextureStorage3D_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage3D");return (void)0;}
void m_glVertexAttrib4svNV_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4svNV");return (void)0;}
void m_glProgramUniform2i_trap(GLuint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2i");return (void)0;}
void m_glListDrawCommandsStatesClientNV_trap(GLuint,GLuint,const void**,const GLsizei*,const GLuint*,const GLuint*,GLuint)const{this->m_printMissingFunctionErrorAndExit("glListDrawCommandsStatesClientNV");return (void)0;}
void m_glProgramLocalParametersI4uivNV_trap(GLenum,GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParametersI4uivNV");return (void)0;}
void m_glBeginTransformFeedbackNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glBeginTransformFeedbackNV");return (void)0;}
void m_glGetProgramBinary_trap(GLuint,GLsizei,GLsizei*,GLenum*,void*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramBinary");return (void)0;}
void m_glBinormal3iEXT_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glBinormal3iEXT");return (void)0;}
void m_glEvalPoint1_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glEvalPoint1");return (void)0;}
void m_glEvalPoint2_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glEvalPoint2");return (void)0;}
void m_glPauseTransformFeedback_trap()const{this->m_printMissingFunctionErrorAndExit("glPauseTransformFeedback");return (void)0;}
void m_glWindowPos2sMESA_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2sMESA");return (void)0;}
void m_glGlobalAlphaFactorbSUN_trap(GLbyte)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactorbSUN");return (void)0;}
void m_glCreateTransformFeedbacks_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateTransformFeedbacks");return (void)0;}
void m_glTexturePageCommitmentEXT_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexturePageCommitmentEXT");return (void)0;}
void m_glTransformFeedbackVaryingsNV_trap(GLuint,GLsizei,const GLint*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackVaryingsNV");return (void)0;}
void m_glTexSubImage1D_trap(GLenum,GLint,GLint,GLsizei,GLenum,GLenum,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage1D");return (void)0;}
void m_glConvolutionParameterfvEXT_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterfvEXT");return (void)0;}
void m_glBlitFramebufferEXT_trap(GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLint,GLbitfield,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlitFramebufferEXT");return (void)0;}
void m_glUniformMatrix4fvARB_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4fvARB");return (void)0;}
void m_glProgramEnvParameter4dvARB_trap(GLenum,GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameter4dvARB");return (void)0;}
void m_glTextureStorageMem2DEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageMem2DEXT");return (void)0;}
void m_glVertexAttribP3uiv_trap(GLuint,GLenum,GLboolean,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP3uiv");return (void)0;}
void m_glFogCoordFormatNV_trap(GLenum,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glFogCoordFormatNV");return (void)0;}
void m_glGetMultiTexLevelParameterivEXT_trap(GLenum,GLenum,GLint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMultiTexLevelParameterivEXT");return (void)0;}
GLboolean m_glIsOcclusionQueryNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsOcclusionQueryNV");return (GLboolean)0;}
void m_glCompressedTexImage2DARB_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage2DARB");return (void)0;}
void m_glGetProgramEnvParameterIuivNV_trap(GLenum,GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramEnvParameterIuivNV");return (void)0;}
void m_glVertexAttrib4sv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4sv");return (void)0;}
void m_glVertexAttrib4fvARB_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4fvARB");return (void)0;}
void m_glLoadName_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glLoadName");return (void)0;}
void m_glBindVertexShaderEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindVertexShaderEXT");return (void)0;}
void m_glGetNamedProgramLocalParameterIivEXT_trap(GLuint,GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramLocalParameterIivEXT");return (void)0;}
void m_glProgramUniform3uiEXT_trap(GLuint,GLint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3uiEXT");return (void)0;}
void m_glProgramUniformMatrix4x2dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x2dvEXT");return (void)0;}
void m_glTexCoord1hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord1hvNV");return (void)0;}
void m_glLoadMatrixd_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glLoadMatrixd");return (void)0;}
void m_glTexParameterfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterfv");return (void)0;}
void m_glVariantdvEXT_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVariantdvEXT");return (void)0;}
void m_glCullParameterfvEXT_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCullParameterfvEXT");return (void)0;}
void m_glUniform3dv_trap(GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniform3dv");return (void)0;}
void m_glProgramUniform3fv_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3fv");return (void)0;}
GLboolean m_glIsBufferARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsBufferARB");return (GLboolean)0;}
void m_glMultiTexCoord1bOES_trap(GLenum,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1bOES");return (void)0;}
void m_glFogCoordhNV_trap(GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glFogCoordhNV");return (void)0;}
void m_glFramebufferSampleLocationsfvNV_trap(GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFramebufferSampleLocationsfvNV");return (void)0;}
GLuint m_glGenSymbolsEXT_trap(GLenum,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glGenSymbolsEXT");return (GLuint)0;}
void m_glGetConvolutionFilter_trap(GLenum,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionFilter");return (void)0;}
void m_glProgramUniform1fvEXT_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1fvEXT");return (void)0;}
void m_glGetNextPerfQueryIdINTEL_trap(GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetNextPerfQueryIdINTEL");return (void)0;}
void m_glCompressedTexImage1DARB_trap(GLenum,GLint,GLenum,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage1DARB");return (void)0;}
void m_glBindSamplers_trap(GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glBindSamplers");return (void)0;}
void m_glGetProgramEnvParameterIivNV_trap(GLenum,GLuint,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramEnvParameterIivNV");return (void)0;}
void m_glGetQueryObjectui64v_trap(GLuint,GLenum,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectui64v");return (void)0;}
void m_glVertexAttribL4ui64vNV_trap(GLuint,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4ui64vNV");return (void)0;}
void m_glGetVideoivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoivNV");return (void)0;}
void m_glGetTextureImage_trap(GLuint,GLint,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureImage");return (void)0;}
void m_glProgramUniform1fv_trap(GLuint,GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1fv");return (void)0;}
void m_glUniformMatrix4fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4fv");return (void)0;}
void m_glColorMask_trap(GLboolean,GLboolean,GLboolean,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glColorMask");return (void)0;}
void m_glBeginFragmentShaderATI_trap()const{this->m_printMissingFunctionErrorAndExit("glBeginFragmentShaderATI");return (void)0;}
void m_glMultiDrawArraysEXT_trap(GLenum,const GLint*,const GLsizei*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysEXT");return (void)0;}
void m_glGenNamesAMD_trap(GLenum,GLuint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenNamesAMD");return (void)0;}
void m_glPathParameteriNV_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPathParameteriNV");return (void)0;}
void m_glCreateCommandListsNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateCommandListsNV");return (void)0;}
void m_glDeleteProgramPipelines_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteProgramPipelines");return (void)0;}
void m_glCopyColorSubTableEXT_trap(GLenum,GLsizei,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyColorSubTableEXT");return (void)0;}
void m_glVariantsvEXT_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVariantsvEXT");return (void)0;}
void m_glGenProgramPipelines_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenProgramPipelines");return (void)0;}
void m_glVertexArrayEdgeFlagOffsetEXT_trap(GLuint,GLuint,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayEdgeFlagOffsetEXT");return (void)0;}
void m_glWindowPos2s_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2s");return (void)0;}
void m_glSecondaryColor3iEXT_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3iEXT");return (void)0;}
void m_glWindowPos2i_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2i");return (void)0;}
void m_glWindowPos2f_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2f");return (void)0;}
void m_glWindowPos2d_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2d");return (void)0;}
void m_glUniform4uivEXT_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform4uivEXT");return (void)0;}
void m_glOrthoxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glOrthoxOES");return (void)0;}
void m_glUniformSubroutinesuiv_trap(GLenum,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniformSubroutinesuiv");return (void)0;}
void m_glRectdv_trap(const GLdouble*,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glRectdv");return (void)0;}
void m_glProgramUniform1i64vNV_trap(GLuint,GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1i64vNV");return (void)0;}
void m_glVertexAttribI4uiEXT_trap(GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4uiEXT");return (void)0;}
void m_glSecondaryColor3ubEXT_trap(GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ubEXT");return (void)0;}
void m_glCompressedMultiTexSubImage1DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexSubImage1DEXT");return (void)0;}
void m_glMultiTexGendEXT_trap(GLenum,GLenum,GLenum,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexGendEXT");return (void)0;}
void m_glColorP3uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glColorP3uiv");return (void)0;}
void m_glFogCoordfv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFogCoordfv");return (void)0;}
void m_glCompileShader_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glCompileShader");return (void)0;}
void m_glTexCoord2hNV_trap(GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2hNV");return (void)0;}
void m_glUniform1uivEXT_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform1uivEXT");return (void)0;}
void m_glMatrixLoadTransposedEXT_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMatrixLoadTransposedEXT");return (void)0;}
void m_glIndexfv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glIndexfv");return (void)0;}
void m_glGetCompressedTextureImage_trap(GLuint,GLint,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedTextureImage");return (void)0;}
void m_glGetUniformuivEXT_trap(GLuint,GLint,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformuivEXT");return (void)0;}
void m_glGetnPixelMapfvARB_trap(GLenum,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapfvARB");return (void)0;}
void m_glFramebufferTextureEXT_trap(GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureEXT");return (void)0;}
void m_glMultiDrawElementsIndirectCount_trap(GLenum,GLenum,const void*,GLintptr,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirectCount");return (void)0;}
void m_glVertexAttribIPointer_trap(GLuint,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribIPointer");return (void)0;}
void m_glMultiTexCoordP3ui_trap(GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP3ui");return (void)0;}
void m_glEvaluateDepthValuesARB_trap()const{this->m_printMissingFunctionErrorAndExit("glEvaluateDepthValuesARB");return (void)0;}
void m_glGetNamedBufferParameteriv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferParameteriv");return (void)0;}
void m_glGetNamedProgramLocalParameterfvEXT_trap(GLuint,GLenum,GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramLocalParameterfvEXT");return (void)0;}
void m_glColor4fNormal3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor4fNormal3fVertex3fvSUN");return (void)0;}
void m_glSeparableFilter2DEXT_trap(GLenum,GLenum,GLsizei,GLsizei,GLenum,GLenum,const void*,const void*)const{this->m_printMissingFunctionErrorAndExit("glSeparableFilter2DEXT");return (void)0;}
void m_glTexParameterxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexParameterxOES");return (void)0;}
void m_glClearAccumxOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glClearAccumxOES");return (void)0;}
void m_glInvalidateFramebuffer_trap(GLenum,GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glInvalidateFramebuffer");return (void)0;}
void m_glWeightubvARB_trap(GLint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glWeightubvARB");return (void)0;}
void m_glVertexAttrib1d_trap(GLuint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1d");return (void)0;}
void m_glVertexAttrib1f_trap(GLuint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1f");return (void)0;}
void m_glVertex4fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertex4fv");return (void)0;}
void m_glClearNamedFramebufferfi_trap(GLuint,GLenum,GLint,GLfloat,GLint)const{this->m_printMissingFunctionErrorAndExit("glClearNamedFramebufferfi");return (void)0;}
void m_glGetQueryBufferObjectuiv_trap(GLuint,GLuint,GLenum,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glGetQueryBufferObjectuiv");return (void)0;}
void m_glClearNamedFramebufferfv_trap(GLuint,GLenum,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glClearNamedFramebufferfv");return (void)0;}
void m_glEndVertexShaderEXT_trap()const{this->m_printMissingFunctionErrorAndExit("glEndVertexShaderEXT");return (void)0;}
void m_glVertexAttrib1s_trap(GLuint,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1s");return (void)0;}
void m_glMultiTexCoord4dvARB_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4dvARB");return (void)0;}
void m_glMultiTexCoord1sv_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1sv");return (void)0;}
void m_glUniform1ui64vNV_trap(GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform1ui64vNV");return (void)0;}
void m_glGetClipPlanefOES_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetClipPlanefOES");return (void)0;}
void m_glRasterPos2s_trap(GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2s");return (void)0;}
void m_glWeightivARB_trap(GLint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWeightivARB");return (void)0;}
void m_glMultiTexCoord4hvNV_trap(GLenum,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4hvNV");return (void)0;}
void m_glNormal3hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glNormal3hNV");return (void)0;}
void m_glGetSeparableFilter_trap(GLenum,GLenum,GLenum,GLvoid*,GLvoid*,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetSeparableFilter");return (void)0;}
void m_glGetPathTexGenivNV_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPathTexGenivNV");return (void)0;}
void m_glColor4bv_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glColor4bv");return (void)0;}
void m_glRasterPos2f_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2f");return (void)0;}
void m_glNamedBufferPageCommitmentARB_trap(GLuint,GLintptr,GLsizeiptr,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferPageCommitmentARB");return (void)0;}
void m_glLoadIdentity_trap()const{this->m_printMissingFunctionErrorAndExit("glLoadIdentity");return (void)0;}
void m_glRasterPos2i_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glRasterPos2i");return (void)0;}
void m_glRasterPos4iv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4iv");return (void)0;}
void m_glMultiTexCoord2fvARB_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2fvARB");return (void)0;}
void m_glUniformMatrix4x3fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4x3fv");return (void)0;}
void m_glClearBufferfv_trap(GLenum,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glClearBufferfv");return (void)0;}
void m_glMultiTexCoord4hNV_trap(GLenum,GLhalfNV,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4hNV");return (void)0;}
void m_glTextureBarrier_trap()const{this->m_printMissingFunctionErrorAndExit("glTextureBarrier");return (void)0;}
void m_glReplacementCodeuivSUN_trap(const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuivSUN");return (void)0;}
void m_glDeleteAsyncMarkersSGIX_trap(GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDeleteAsyncMarkersSGIX");return (void)0;}
void m_glTexCoord2bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2bvOES");return (void)0;}
void m_glEvalCoord2xOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord2xOES");return (void)0;}
void m_glGetSharpenTexFuncSGIS_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetSharpenTexFuncSGIS");return (void)0;}
void m_glProgramUniformHandleui64vNV_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformHandleui64vNV");return (void)0;}
void m_glIglooInterfaceSGIX_trap(GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glIglooInterfaceSGIX");return (void)0;}
void m_glWindowPos2dvARB_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2dvARB");return (void)0;}
void m_glClearBufferfi_trap(GLenum,GLint,GLfloat,GLint)const{this->m_printMissingFunctionErrorAndExit("glClearBufferfi");return (void)0;}
void m_glDrawArraysIndirect_trap(GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysIndirect");return (void)0;}
void m_glGenVertexArrays_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenVertexArrays");return (void)0;}
void m_glGetTransformFeedbacki64_v_trap(GLuint,GLenum,GLuint,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbacki64_v");return (void)0;}
void m_glEnableVertexArrayAttrib_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexArrayAttrib");return (void)0;}
void m_glProgramUniformMatrix3x2dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x2dv");return (void)0;}
void m_glVertexStream4fATI_trap(GLenum,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4fATI");return (void)0;}
void m_glVertexBindingDivisor_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexBindingDivisor");return (void)0;}
void m_glGetSamplerParameterIiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetSamplerParameterIiv");return (void)0;}
void m_glGetCoverageModulationTableNV_trap(GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetCoverageModulationTableNV");return (void)0;}
void m_glDepthRangedNV_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glDepthRangedNV");return (void)0;}
void m_glVertexAttrib3f_trap(GLuint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3f");return (void)0;}
void m_glMultiDrawRangeElementArrayAPPLE_trap(GLenum,GLuint,GLuint,const GLint*,const GLsizei*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawRangeElementArrayAPPLE");return (void)0;}
void m_glVertexAttribFormatNV_trap(GLuint,GLint,GLenum,GLboolean,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribFormatNV");return (void)0;}
void m_glGetQueryBufferObjecti64v_trap(GLuint,GLuint,GLenum,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glGetQueryBufferObjecti64v");return (void)0;}
void m_glGetVertexAttribdv_trap(GLuint,GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribdv");return (void)0;}
void m_glGetUniformi64vARB_trap(GLuint,GLint,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformi64vARB");return (void)0;}
GLboolean m_glAreTexturesResidentEXT_trap(GLsizei,const GLuint*,GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glAreTexturesResidentEXT");return (GLboolean)0;}
GLhandleARB m_glGetHandleARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glGetHandleARB");return (GLhandleARB)0;}
void m_glVideoCaptureStreamParameterdvNV_trap(GLuint,GLuint,GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVideoCaptureStreamParameterdvNV");return (void)0;}
void m_glMapParameterivNV_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMapParameterivNV");return (void)0;}
GLboolean m_glIsVertexArray_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsVertexArray");return (GLboolean)0;}
void m_glSecondaryColor3sEXT_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3sEXT");return (void)0;}
void m_glGetTexParameterIivEXT_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterIivEXT");return (void)0;}
void m_glFrameTerminatorGREMEDY_trap()const{this->m_printMissingFunctionErrorAndExit("glFrameTerminatorGREMEDY");return (void)0;}
void m_glBlendBarrierKHR_trap()const{this->m_printMissingFunctionErrorAndExit("glBlendBarrierKHR");return (void)0;}
void m_glVertexAttrib4NubARB_trap(GLuint,GLubyte,GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NubARB");return (void)0;}
void m_glPrimitiveRestartNV_trap()const{this->m_printMissingFunctionErrorAndExit("glPrimitiveRestartNV");return (void)0;}
void m_glVertexAttribL1ui64vARB_trap(GLuint,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL1ui64vARB");return (void)0;}
void m_glVertexAttribI4ivEXT_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4ivEXT");return (void)0;}
void m_glVertexAttribs4svNV_trap(GLuint,GLsizei,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs4svNV");return (void)0;}
void m_glUniform1ui_trap(GLint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform1ui");return (void)0;}
void m_glVertexAttrib2fvARB_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2fvARB");return (void)0;}
void m_glVertexAttribI4svEXT_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4svEXT");return (void)0;}
void m_glTextureImage3DMultisampleCoverageNV_trap(GLuint,GLenum,GLsizei,GLsizei,GLint,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureImage3DMultisampleCoverageNV");return (void)0;}
void m_glMemoryBarrier_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMemoryBarrier");return (void)0;}
void m_glGetVariantArrayObjectfvATI_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetVariantArrayObjectfvATI");return (void)0;}
void m_glTexCoord4fColor4fNormal3fVertex4fvSUN_trap(const GLfloat*,const GLfloat*,const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4fColor4fNormal3fVertex4fvSUN");return (void)0;}
GLboolean m_glIsProgramARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsProgramARB");return (GLboolean)0;}
void m_glBindImageTextureEXT_trap(GLuint,GLuint,GLint,GLboolean,GLint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glBindImageTextureEXT");return (void)0;}
GLint m_glGetFragDataLocation_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetFragDataLocation");return (GLint)0;}
void m_glMultiTexCoord1svARB_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1svARB");return (void)0;}
void m_glGetMapxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetMapxvOES");return (void)0;}
void m_glTextureStorage2DMultisampleEXT_trap(GLuint,GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage2DMultisampleEXT");return (void)0;}
void m_glGetMaterialfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetMaterialfv");return (void)0;}
void m_glVertexAttrib4NbvARB_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4NbvARB");return (void)0;}
void m_glPixelMapuiv_trap(GLenum,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glPixelMapuiv");return (void)0;}
void m_glColorPointerEXT_trap(GLint,GLenum,GLsizei,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glColorPointerEXT");return (void)0;}
void m_glEnableClientStateiEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableClientStateiEXT");return (void)0;}
void m_glClearTexSubImage_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glClearTexSubImage");return (void)0;}
void m_glEvalCoord1xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1xvOES");return (void)0;}
void m_glDetachObjectARB_trap(GLhandleARB,GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glDetachObjectARB");return (void)0;}
void m_glGetTextureParameterIiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterIiv");return (void)0;}
void m_glVariantusvEXT_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVariantusvEXT");return (void)0;}
void m_glCompressedTextureImage3DEXT_trap(GLuint,GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureImage3DEXT");return (void)0;}
void m_glMultiTexCoord1dARB_trap(GLenum,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1dARB");return (void)0;}
void m_glGetVertexArrayIntegeri_vEXT_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayIntegeri_vEXT");return (void)0;}
void m_glVertexAttribI4ubv_trap(GLuint,const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4ubv");return (void)0;}
void m_glPixelTexGenParameterfSGIS_trap(GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPixelTexGenParameterfSGIS");return (void)0;}
void m_glProgramUniformMatrix4x2dv_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x2dv");return (void)0;}
void m_glUniform3fARB_trap(GLint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform3fARB");return (void)0;}
GLboolean m_glIsShader_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsShader");return (GLboolean)0;}
void m_glConvolutionParameteriv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameteriv");return (void)0;}
void m_glCopyMultiTexSubImage2DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyMultiTexSubImage2DEXT");return (void)0;}
void m_glEnableVertexAttribArrayARB_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexAttribArrayARB");return (void)0;}
void m_glMulticastCopyBufferSubDataNV_trap(GLuint,GLbitfield,GLuint,GLuint,GLintptr,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glMulticastCopyBufferSubDataNV");return (void)0;}
void m_glEnable_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glEnable");return (void)0;}
void m_glGetActiveUniformsiv_trap(GLuint,GLsizei,const GLuint*,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniformsiv");return (void)0;}
void m_glGetVertexAttribivARB_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribivARB");return (void)0;}
void m_glTexCoord4hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4hvNV");return (void)0;}
void m_glUseProgramObjectARB_trap(GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glUseProgramObjectARB");return (void)0;}
GLint m_glGetAttribLocation_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetAttribLocation");return (GLint)0;}
void m_glVertexAttrib4dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4dv");return (void)0;}
void m_glGetTextureParameteriv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameteriv");return (void)0;}
void m_glNamedBufferStorageMemEXT_trap(GLuint,GLsizeiptr,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferStorageMemEXT");return (void)0;}
void m_glPathSubCoordsNV_trap(GLuint,GLsizei,GLsizei,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glPathSubCoordsNV");return (void)0;}
void m_glMatrixIndexusvARB_trap(GLint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glMatrixIndexusvARB");return (void)0;}
void m_glGetVideouivNV_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetVideouivNV");return (void)0;}
void m_glGetVideoCaptureivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoCaptureivNV");return (void)0;}
void m_glProgramUniform3ui_trap(GLuint,GLint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3ui");return (void)0;}
void m_glVertexAttrib3svARB_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3svARB");return (void)0;}
void m_glGetNamedBufferParameterivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferParameterivEXT");return (void)0;}
void m_glMatrixScaledEXT_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMatrixScaledEXT");return (void)0;}
void m_glProgramUniformMatrix2x3fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x3fv");return (void)0;}
void m_glGetFragmentLightivSGIX_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetFragmentLightivSGIX");return (void)0;}
const GLubyte* m_glGetStringi_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glGetStringi");return (const GLubyte*)0;}
void m_glWindowPos2svARB_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2svARB");return (void)0;}
void m_glVertexAttrib2svNV_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2svNV");return (void)0;}
void m_glWindowPos2ivARB_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2ivARB");return (void)0;}
void m_glGetVertexAttribPointervNV_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribPointervNV");return (void)0;}
void m_glPushMatrix_trap()const{this->m_printMissingFunctionErrorAndExit("glPushMatrix");return (void)0;}
void m_glEdgeFlagPointerListIBM_trap(GLint,const GLboolean**,GLint)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlagPointerListIBM");return (void)0;}
void m_glGenerateMipmapEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glGenerateMipmapEXT");return (void)0;}
void m_glWindowPos3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3sv");return (void)0;}
void m_glPathCoordsNV_trap(GLuint,GLsizei,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glPathCoordsNV");return (void)0;}
void m_glProgramUniform1i_trap(GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1i");return (void)0;}
void m_glProgramUniform1d_trap(GLuint,GLint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1d");return (void)0;}
void m_glProgramUniform1f_trap(GLuint,GLint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1f");return (void)0;}
void m_glProgramParameteriEXT_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glProgramParameteriEXT");return (void)0;}
void m_glCompressedMultiTexImage2DEXT_trap(GLenum,GLenum,GLint,GLenum,GLsizei,GLsizei,GLint,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexImage2DEXT");return (void)0;}
void m_glProgramUniform3iv_trap(GLuint,GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3iv");return (void)0;}
void m_glIndexiv_trap(const GLint*)const{this->m_printMissingFunctionErrorAndExit("glIndexiv");return (void)0;}
void m_glMultiTexCoord4xvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4xvOES");return (void)0;}
void m_glEGLImageTargetTexture2DOES_trap(GLenum,GLeglImageOES)const{this->m_printMissingFunctionErrorAndExit("glEGLImageTargetTexture2DOES");return (void)0;}
void m_glPixelZoom_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPixelZoom");return (void)0;}
void m_glVertex3bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertex3bvOES");return (void)0;}
void m_glFramebufferReadBufferEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glFramebufferReadBufferEXT");return (void)0;}
void m_glExtractComponentEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glExtractComponentEXT");return (void)0;}
void m_glCombinerParameterivNV_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glCombinerParameterivNV");return (void)0;}
void m_glMinmax_trap(GLenum,GLenum,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glMinmax");return (void)0;}
void m_glColorP3ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glColorP3ui");return (void)0;}
void m_glPointParameterfvSGIS_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfvSGIS");return (void)0;}
void m_glBlendEquationi_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendEquationi");return (void)0;}
void m_glGetFogFuncSGIS_trap(GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFogFuncSGIS");return (void)0;}
void m_glVertexAttrib4fvNV_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4fvNV");return (void)0;}
void m_glGetnMinmax_trap(GLenum,GLboolean,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnMinmax");return (void)0;}
void m_glFragmentLightiSGIX_trap(GLenum,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightiSGIX");return (void)0;}
void m_glMultiTexCoord1bvOES_trap(GLenum,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord1bvOES");return (void)0;}
void m_glSecondaryColorPointerEXT_trap(GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColorPointerEXT");return (void)0;}
void m_glMultiTexCoordP4uiv_trap(GLenum,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoordP4uiv");return (void)0;}
void m_glGetBufferSubDataARB_trap(GLenum,GLintptrARB,GLsizeiptrARB,void*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferSubDataARB");return (void)0;}
void m_glSecondaryColor3hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3hNV");return (void)0;}
void m_glGetPathParameterivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetPathParameterivNV");return (void)0;}
void m_glFlushRasterSGIX_trap()const{this->m_printMissingFunctionErrorAndExit("glFlushRasterSGIX");return (void)0;}
void m_glElementPointerATI_trap(GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glElementPointerATI");return (void)0;}
void m_glGetAttachedObjectsARB_trap(GLhandleARB,GLsizei,GLsizei*,GLhandleARB*)const{this->m_printMissingFunctionErrorAndExit("glGetAttachedObjectsARB");return (void)0;}
void m_glUniform4iv_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform4iv");return (void)0;}
void m_glFogxOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glFogxOES");return (void)0;}
void m_glSharpenTexFuncSGIS_trap(GLenum,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSharpenTexFuncSGIS");return (void)0;}
void m_glClearDepthfOES_trap(GLclampf)const{this->m_printMissingFunctionErrorAndExit("glClearDepthfOES");return (void)0;}
void m_glDeleteCommandListsNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteCommandListsNV");return (void)0;}
void m_glSpecializeShader_trap(GLuint,const GLchar*,GLuint,const GLuint*,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSpecializeShader");return (void)0;}
void m_glVertex4hNV_trap(GLhalfNV,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertex4hNV");return (void)0;}
void m_glSecondaryColor3dvEXT_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3dvEXT");return (void)0;}
void m_glGenTextures_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenTextures");return (void)0;}
void m_glTextureStorage2DMultisample_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureStorage2DMultisample");return (void)0;}
void m_glUniform3ui64vNV_trap(GLint,GLsizei,const GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glUniform3ui64vNV");return (void)0;}
void m_glBlendFuncSeparateIndexedAMD_trap(GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFuncSeparateIndexedAMD");return (void)0;}
void m_glMakeBufferResidentNV_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMakeBufferResidentNV");return (void)0;}
void m_glShaderOp2EXT_trap(GLenum,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glShaderOp2EXT");return (void)0;}
void m_glGetVertexAttribivNV_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribivNV");return (void)0;}
void m_glTexParameterIivEXT_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterIivEXT");return (void)0;}
void m_glGetPerfQueryDataINTEL_trap(GLuint,GLuint,GLsizei,GLvoid*,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfQueryDataINTEL");return (void)0;}
void m_glVertexAttrib4dvARB_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4dvARB");return (void)0;}
void m_glTextureSubImage1DEXT_trap(GLuint,GLenum,GLint,GLint,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage1DEXT");return (void)0;}
void m_glGetActiveUniformBlockName_trap(GLuint,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveUniformBlockName");return (void)0;}
void m_glVertexAttrib2dvARB_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2dvARB");return (void)0;}
void m_glVertexAttribPointer_trap(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribPointer");return (void)0;}
void m_glDepthBoundsdNV_trap(GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glDepthBoundsdNV");return (void)0;}
void m_glDeleteTexturesEXT_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteTexturesEXT");return (void)0;}
void m_glDrawBuffersATI_trap(GLsizei,const GLenum*)const{this->m_printMissingFunctionErrorAndExit("glDrawBuffersATI");return (void)0;}
void m_glLightModelxvOES_trap(GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glLightModelxvOES");return (void)0;}
void m_glApplyTextureEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glApplyTextureEXT");return (void)0;}
GLuint64 m_glGetImageHandleNV_trap(GLuint,GLint,GLboolean,GLint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glGetImageHandleNV");return (GLuint64)0;}
void m_glGetMinmax_trap(GLenum,GLboolean,GLenum,GLenum,GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glGetMinmax");return (void)0;}
void m_glGetFixedvOES_trap(GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetFixedvOES");return (void)0;}
void m_glSamplePatternEXT_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glSamplePatternEXT");return (void)0;}
void m_glUniform1f_trap(GLint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform1f");return (void)0;}
void m_glColor4fNormal3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glColor4fNormal3fVertex3fSUN");return (void)0;}
void m_glFogCoorddvEXT_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glFogCoorddvEXT");return (void)0;}
void m_glCopyTextureImage1DEXT_trap(GLuint,GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureImage1DEXT");return (void)0;}
void m_glFlushMappedBufferRangeAPPLE_trap(GLenum,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glFlushMappedBufferRangeAPPLE");return (void)0;}
void m_glVertex3sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertex3sv");return (void)0;}
void m_glFlushStaticDataIBM_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glFlushStaticDataIBM");return (void)0;}
void m_glProgramUniform4ui64NV_trap(GLuint,GLint,GLuint64EXT,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ui64NV");return (void)0;}
void m_glRasterPos4xOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4xOES");return (void)0;}
void m_glVertexAttribP1ui_trap(GLuint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP1ui");return (void)0;}
void m_glProgramUniform4dvEXT_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4dvEXT");return (void)0;}
void m_glEndTransformFeedbackEXT_trap()const{this->m_printMissingFunctionErrorAndExit("glEndTransformFeedbackEXT");return (void)0;}
void m_glBinormal3dEXT_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glBinormal3dEXT");return (void)0;}
void m_glGetTextureSubImage_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureSubImage");return (void)0;}
void m_glGetNamedRenderbufferParameteriv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedRenderbufferParameteriv");return (void)0;}
void m_glBindBuffersRange_trap(GLenum,GLuint,GLsizei,const GLuint*,const GLintptr*,const GLsizeiptr*)const{this->m_printMissingFunctionErrorAndExit("glBindBuffersRange");return (void)0;}
GLint m_glFinishAsyncSGIX_trap(GLuint*)const{this->m_printMissingFunctionErrorAndExit("glFinishAsyncSGIX");return (GLint)0;}
void m_glBindFragDataLocationIndexed_trap(GLuint,GLuint,GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glBindFragDataLocationIndexed");return (void)0;}
void m_glMultiTexCoord2dv_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2dv");return (void)0;}
void m_glUniform2iv_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform2iv");return (void)0;}
void m_glProgramUniform2i64vNV_trap(GLuint,GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2i64vNV");return (void)0;}
void m_glFlushVertexArrayRangeAPPLE_trap(GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glFlushVertexArrayRangeAPPLE");return (void)0;}
void m_glTextureParameterf_trap(GLuint,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterf");return (void)0;}
void m_glMultiTexCoord3dvARB_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3dvARB");return (void)0;}
void m_glFeedbackBuffer_trap(GLsizei,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFeedbackBuffer");return (void)0;}
void m_glDebugMessageInsertARB_trap(GLenum,GLenum,GLuint,GLenum,GLsizei,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageInsertARB");return (void)0;}
void m_glMultiTexCoord2i_trap(GLenum,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2i");return (void)0;}
void m_glTextureSubImage3D_trap(GLuint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage3D");return (void)0;}
void m_glFramebufferTexture1D_trap(GLenum,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture1D");return (void)0;}
void m_glGetShaderiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetShaderiv");return (void)0;}
void m_glMultiTexCoord2d_trap(GLenum,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2d");return (void)0;}
void m_glArrayObjectATI_trap(GLenum,GLint,GLenum,GLsizei,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glArrayObjectATI");return (void)0;}
void m_glGetPointeri_vEXT_trap(GLenum,GLuint,void**)const{this->m_printMissingFunctionErrorAndExit("glGetPointeri_vEXT");return (void)0;}
void m_glGetPerfMonitorCountersAMD_trap(GLuint,GLint*,GLint*,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorCountersAMD");return (void)0;}
void m_glNamedBufferStorage_trap(GLuint,GLsizeiptr,const void*,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferStorage");return (void)0;}
void m_glTexEnvxvOES_trap(GLenum,GLenum,const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexEnvxvOES");return (void)0;}
void m_glProgramUniform2ui64NV_trap(GLuint,GLint,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ui64NV");return (void)0;}
void m_glMultiTexCoord3bOES_trap(GLenum,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3bOES");return (void)0;}
void m_glUniform1dv_trap(GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniform1dv");return (void)0;}
void m_glPixelTransferi_trap(GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glPixelTransferi");return (void)0;}
void m_glSecondaryColor3usvEXT_trap(const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3usvEXT");return (void)0;}
void m_glProgramEnvParameterI4uivNV_trap(GLenum,GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameterI4uivNV");return (void)0;}
void m_glVertex2sv_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertex2sv");return (void)0;}
void m_glWindowPos4dMESA_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4dMESA");return (void)0;}
void m_glDebugMessageControlARB_trap(GLenum,GLenum,GLenum,GLsizei,const GLuint*,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageControlARB");return (void)0;}
GLboolean m_glIsTextureEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsTextureEXT");return (GLboolean)0;}
void m_glFragmentMaterialivSGIX_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glFragmentMaterialivSGIX");return (void)0;}
void m_glLinkProgramARB_trap(GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glLinkProgramARB");return (void)0;}
void m_glFinishFenceAPPLE_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glFinishFenceAPPLE");return (void)0;}
void m_glVertexArrayVertexAttribBindingEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribBindingEXT");return (void)0;}
void m_glTexStorageMem3DMultisampleEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTexStorageMem3DMultisampleEXT");return (void)0;}
void m_glUniform1ui64vARB_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform1ui64vARB");return (void)0;}
void m_glMultiTexCoord4fv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4fv");return (void)0;}
void m_glMulticastFramebufferSampleLocationsfvNV_trap(GLuint,GLuint,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMulticastFramebufferSampleLocationsfvNV");return (void)0;}
void m_glRasterPos3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3d");return (void)0;}
GLint m_glPollAsyncSGIX_trap(GLuint*)const{this->m_printMissingFunctionErrorAndExit("glPollAsyncSGIX");return (GLint)0;}
void m_glRasterPos3f_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3f");return (void)0;}
void m_glCompressedTexImage3D_trap(GLenum,GLint,GLenum,GLsizei,GLsizei,GLsizei,GLint,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexImage3D");return (void)0;}
void m_glVariantivEXT_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVariantivEXT");return (void)0;}
void m_glUnmapTexture2DINTEL_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUnmapTexture2DINTEL");return (void)0;}
void m_glMulticastWaitSyncNV_trap(GLuint,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMulticastWaitSyncNV");return (void)0;}
void m_glGetVertexAttribiv_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribiv");return (void)0;}
void m_glGetPathCoordsNV_trap(GLuint,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathCoordsNV");return (void)0;}
void m_glColor4xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glColor4xvOES");return (void)0;}
void m_glVertexAttrib3fv_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3fv");return (void)0;}
void m_glRasterPos3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glRasterPos3s");return (void)0;}
void m_glVertex4bOES_trap(GLbyte,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glVertex4bOES");return (void)0;}
void m_glTransformFeedbackVaryingsEXT_trap(GLuint,GLsizei,const GLchar*const*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackVaryingsEXT");return (void)0;}
void m_glCombinerOutputNV_trap(GLenum,GLenum,GLenum,GLenum,GLenum,GLenum,GLenum,GLboolean,GLboolean,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glCombinerOutputNV");return (void)0;}
void m_glWindowPos4sMESA_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4sMESA");return (void)0;}
void m_glVertexAttrib4svARB_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4svARB");return (void)0;}
GLboolean m_glIsList_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsList");return (GLboolean)0;}
void m_glGetInfoLogARB_trap(GLhandleARB,GLsizei,GLsizei*,GLcharARB*)const{this->m_printMissingFunctionErrorAndExit("glGetInfoLogARB");return (void)0;}
void m_glUniformMatrix2fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix2fv");return (void)0;}
void m_glVertexAttribs3dvNV_trap(GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs3dvNV");return (void)0;}
void m_glGlobalAlphaFactorsSUN_trap(GLshort)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactorsSUN");return (void)0;}
void m_glGetTrackMatrixivNV_trap(GLenum,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTrackMatrixivNV");return (void)0;}
void m_glTextureParameterfvEXT_trap(GLuint,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterfvEXT");return (void)0;}
GLboolean m_glIsNamedBufferResidentNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsNamedBufferResidentNV");return (GLboolean)0;}
void m_glProgramUniform4ui64vARB_trap(GLuint,GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4ui64vARB");return (void)0;}
void m_glTbufferMask3DFX_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glTbufferMask3DFX");return (void)0;}
void m_glCoverFillPathNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCoverFillPathNV");return (void)0;}
void m_glVertexAttrib1fvARB_trap(GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1fvARB");return (void)0;}
void m_glGenerateTextureMipmap_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGenerateTextureMipmap");return (void)0;}
void m_glNamedProgramLocalParameterI4uivEXT_trap(GLuint,GLenum,GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameterI4uivEXT");return (void)0;}
void m_glMultiDrawElementsBaseVertex_trap(GLenum,const GLsizei*,GLenum,const void*const*,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsBaseVertex");return (void)0;}
void m_glProgramSubroutineParametersuivNV_trap(GLenum,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramSubroutineParametersuivNV");return (void)0;}
void m_glProgramUniformMatrix2x4dvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2x4dvEXT");return (void)0;}
void m_glRotatexOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glRotatexOES");return (void)0;}
void m_glMemoryBarrierEXT_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMemoryBarrierEXT");return (void)0;}
void m_glVertexAttrib3svNV_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3svNV");return (void)0;}
void m_glVertexStream3iATI_trap(GLenum,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3iATI");return (void)0;}
void m_glCompressedTexSubImage1D_trap(GLenum,GLint,GLint,GLsizei,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage1D");return (void)0;}
void m_glSetFenceNV_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glSetFenceNV");return (void)0;}
void m_glAttachObjectARB_trap(GLhandleARB,GLhandleARB)const{this->m_printMissingFunctionErrorAndExit("glAttachObjectARB");return (void)0;}
void m_glCopyConvolutionFilter1D_trap(GLenum,GLenum,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyConvolutionFilter1D");return (void)0;}
void m_glTexStorageMem2DMultisampleEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLboolean,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTexStorageMem2DMultisampleEXT");return (void)0;}
void m_glProgramParameters4fvNV_trap(GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramParameters4fvNV");return (void)0;}
void m_glNamedFramebufferParameteriEXT_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferParameteriEXT");return (void)0;}
void m_glVertexAttrib4Nsv_trap(GLuint,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4Nsv");return (void)0;}
void m_glVertexAttribI4usvEXT_trap(GLuint,const GLushort*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4usvEXT");return (void)0;}
void m_glTextureBufferRangeEXT_trap(GLuint,GLenum,GLenum,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glTextureBufferRangeEXT");return (void)0;}
void m_glVertexP3uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexP3uiv");return (void)0;}
GLboolean m_glIsPathNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsPathNV");return (GLboolean)0;}
void m_glGetnUniformi64vARB_trap(GLuint,GLint,GLsizei,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetnUniformi64vARB");return (void)0;}
void m_glFramebufferTextureMultiviewOVR_trap(GLenum,GLenum,GLuint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureMultiviewOVR");return (void)0;}
void m_glCompressedMultiTexSubImage2DEXT_trap(GLenum,GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedMultiTexSubImage2DEXT");return (void)0;}
void m_glGetnMapdv_trap(GLenum,GLenum,GLsizei,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetnMapdv");return (void)0;}
void m_glDebugMessageCallback_trap(GLDEBUGPROC,const void*)const{this->m_printMissingFunctionErrorAndExit("glDebugMessageCallback");return (void)0;}
void m_glTangent3svEXT_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glTangent3svEXT");return (void)0;}
void m_glVertexAttribParameteriAMD_trap(GLuint,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribParameteriAMD");return (void)0;}
void m_glBufferSubDataARB_trap(GLenum,GLintptrARB,GLsizeiptrARB,const void*)const{this->m_printMissingFunctionErrorAndExit("glBufferSubDataARB");return (void)0;}
void m_glGetVertexAttribLui64vARB_trap(GLuint,GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribLui64vARB");return (void)0;}
void m_glVertexAttribL4ui64NV_trap(GLuint,GLuint64EXT,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4ui64NV");return (void)0;}
void m_glReplacementCodeuiColor4ubVertex3fSUN_trap(GLuint,GLubyte,GLubyte,GLubyte,GLubyte,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiColor4ubVertex3fSUN");return (void)0;}
void m_glImageTransformParameterfHP_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glImageTransformParameterfHP");return (void)0;}
void m_glMap1f_trap(GLenum,GLfloat,GLfloat,GLint,GLint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMap1f");return (void)0;}
void m_glRasterPos4fv_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4fv");return (void)0;}
void m_glVertex2bvOES_trap(const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertex2bvOES");return (void)0;}
void m_glGetMapControlPointsNV_trap(GLenum,GLuint,GLenum,GLsizei,GLsizei,GLboolean,void*)const{this->m_printMissingFunctionErrorAndExit("glGetMapControlPointsNV");return (void)0;}
void m_glNamedProgramLocalParametersI4ivEXT_trap(GLuint,GLenum,GLuint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParametersI4ivEXT");return (void)0;}
void m_glBindBufferRangeNV_trap(GLenum,GLuint,GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glBindBufferRangeNV");return (void)0;}
void m_glVertexStream3dvATI_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3dvATI");return (void)0;}
void m_glNormalPointerListIBM_trap(GLenum,GLint,const void**,GLint)const{this->m_printMissingFunctionErrorAndExit("glNormalPointerListIBM");return (void)0;}
void m_glFogFuncSGIS_trap(GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFogFuncSGIS");return (void)0;}
void m_glMultiModeDrawArraysIBM_trap(const GLenum*,const GLint*,const GLsizei*,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glMultiModeDrawArraysIBM");return (void)0;}
void m_glGetNamedFramebufferAttachmentParameterivEXT_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedFramebufferAttachmentParameterivEXT");return (void)0;}
void m_glGetFloatv_trap(GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFloatv");return (void)0;}
void m_glVertexArrayVertexAttribIFormatEXT_trap(GLuint,GLuint,GLint,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayVertexAttribIFormatEXT");return (void)0;}
void m_glHint_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glHint");return (void)0;}
void m_glVertexStream2svATI_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2svATI");return (void)0;}
void m_glMultiDrawArraysIndirect_trap(GLenum,const void*,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawArraysIndirect");return (void)0;}
void m_glMultiTexEnvfvEXT_trap(GLenum,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexEnvfvEXT");return (void)0;}
void m_glVertexAttribP2uiv_trap(GLuint,GLenum,GLboolean,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribP2uiv");return (void)0;}
void m_glProgramUniform1i64vARB_trap(GLuint,GLint,GLsizei,const GLint64*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1i64vARB");return (void)0;}
void m_glFramebufferTextureARB_trap(GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTextureARB");return (void)0;}
void m_glPushClientAttribDefaultEXT_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glPushClientAttribDefaultEXT");return (void)0;}
void m_glScalef_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glScalef");return (void)0;}
void m_glScaled_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glScaled");return (void)0;}
void m_glGetConvolutionParameterxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetConvolutionParameterxvOES");return (void)0;}
void m_glGetProgramResourceName_trap(GLuint,GLenum,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourceName");return (void)0;}
void m_glCopyColorTable_trap(GLenum,GLenum,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyColorTable");return (void)0;}
void m_glDepthRangeArrayv_trap(GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glDepthRangeArrayv");return (void)0;}
void m_glCoverFillPathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glCoverFillPathInstancedNV");return (void)0;}
void m_glMultiTexParameterivEXT_trap(GLenum,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameterivEXT");return (void)0;}
void m_glGetActiveAtomicCounterBufferiv_trap(GLuint,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetActiveAtomicCounterBufferiv");return (void)0;}
void m_glStencilOpSeparate_trap(GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glStencilOpSeparate");return (void)0;}
void m_glVertexAttrib4fNV_trap(GLuint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4fNV");return (void)0;}
void m_glGetColorTableParameterivSGI_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameterivSGI");return (void)0;}
void m_glVertexArrayAttribBinding_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayAttribBinding");return (void)0;}
GLboolean m_glIsSemaphoreEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsSemaphoreEXT");return (GLboolean)0;}
void m_glProgramParameters4dvNV_trap(GLenum,GLuint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramParameters4dvNV");return (void)0;}
void m_glVertexAttribL4dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribL4dv");return (void)0;}
void m_glGetTexParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameteriv");return (void)0;}
GLintptr m_glGetUniformOffsetEXT_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glGetUniformOffsetEXT");return (GLintptr)0;}
void m_glGetVertexAttribPointerv_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribPointerv");return (void)0;}
void m_glResumeTransformFeedbackNV_trap()const{this->m_printMissingFunctionErrorAndExit("glResumeTransformFeedbackNV");return (void)0;}
void m_glProgramUniform3i64vNV_trap(GLuint,GLint,GLsizei,const GLint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3i64vNV");return (void)0;}
void m_glTangent3fEXT_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTangent3fEXT");return (void)0;}
void m_glGetPathMetricRangeNV_trap(GLbitfield,GLuint,GLsizei,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathMetricRangeNV");return (void)0;}
void m_glWindowPos2iMESA_trap(GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2iMESA");return (void)0;}
void m_glVertex2xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glVertex2xvOES");return (void)0;}
void m_glGetnCompressedTexImage_trap(GLenum,GLint,GLsizei,void*)const{this->m_printMissingFunctionErrorAndExit("glGetnCompressedTexImage");return (void)0;}
void m_glWindowPos2dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2dv");return (void)0;}
void m_glReplacementCodeuiVertex3fSUN_trap(GLuint,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glReplacementCodeuiVertex3fSUN");return (void)0;}
void m_glGetTransformFeedbackVaryingEXT_trap(GLuint,GLuint,GLsizei,GLsizei*,GLsizei*,GLenum*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetTransformFeedbackVaryingEXT");return (void)0;}
void m_glWindowPos3fARB_trap(GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3fARB");return (void)0;}
void* m_glMapNamedBufferEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glMapNamedBufferEXT");return (void*)0;}
void m_glDisable_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glDisable");return (void)0;}
GLboolean m_glIsPointInFillPathNV_trap(GLuint,GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glIsPointInFillPathNV");return (GLboolean)0;}
void m_glVertexAttribI2uiEXT_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2uiEXT");return (void)0;}
void m_glProgramUniform4uiv_trap(GLuint,GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4uiv");return (void)0;}
void m_glQueryCounter_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glQueryCounter");return (void)0;}
void m_glFramebufferRenderbufferEXT_trap(GLenum,GLenum,GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferRenderbufferEXT");return (void)0;}
void m_glBinormal3svEXT_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glBinormal3svEXT");return (void)0;}
void m_glBindBufferOffsetNV_trap(GLenum,GLuint,GLuint,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glBindBufferOffsetNV");return (void)0;}
void m_glCopyTextureSubImage2D_trap(GLuint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage2D");return (void)0;}
void m_glGetProgramResourcefvNV_trap(GLuint,GLenum,GLuint,GLsizei,const GLenum*,GLsizei,GLsizei*,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramResourcefvNV");return (void)0;}
void m_glBinormalPointerEXT_trap(GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glBinormalPointerEXT");return (void)0;}
void m_glGetLightfv_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetLightfv");return (void)0;}
void m_glMulticastCopyImageSubDataNV_trap(GLuint,GLbitfield,GLuint,GLenum,GLint,GLint,GLint,GLint,GLuint,GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMulticastCopyImageSubDataNV");return (void)0;}
void m_glVertex2bOES_trap(GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glVertex2bOES");return (void)0;}
void m_glUniform2ivARB_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform2ivARB");return (void)0;}
void m_glMultiTexCoord3s_trap(GLenum,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3s");return (void)0;}
void m_glGetHistogramParameterfvEXT_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetHistogramParameterfvEXT");return (void)0;}
void m_glGetProgramStringNV_trap(GLuint,GLenum,GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramStringNV");return (void)0;}
void m_glGetTexGenxvOES_trap(GLenum,GLenum,GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glGetTexGenxvOES");return (void)0;}
void m_glTextureSubImage2D_trap(GLuint,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureSubImage2D");return (void)0;}
GLenum m_glObjectPurgeableAPPLE_trap(GLenum,GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glObjectPurgeableAPPLE");return (GLenum)0;}
void m_glColorTableSGI_trap(GLenum,GLenum,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glColorTableSGI");return (void)0;}
void m_glCopyConvolutionFilter2DEXT_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyConvolutionFilter2DEXT");return (void)0;}
void m_glMultiTexCoord3f_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3f");return (void)0;}
void m_glMultiTexCoord3d_trap(GLenum,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3d");return (void)0;}
void m_glFogCoorddv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glFogCoorddv");return (void)0;}
void m_glGetBufferPointerv_trap(GLenum,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetBufferPointerv");return (void)0;}
void m_glProgramUniform1fEXT_trap(GLuint,GLint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform1fEXT");return (void)0;}
void m_glWindowPos2fvMESA_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2fvMESA");return (void)0;}
void m_glAlphaToCoverageDitherControlNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glAlphaToCoverageDitherControlNV");return (void)0;}
void m_glPolygonOffsetxOES_trap(GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glPolygonOffsetxOES");return (void)0;}
void m_glVertexAttrib4dARB_trap(GLuint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4dARB");return (void)0;}
void m_glUniformHandleui64vARB_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniformHandleui64vARB");return (void)0;}
void m_glFragmentLightModelfvSGIX_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glFragmentLightModelfvSGIX");return (void)0;}
void m_glSwizzleEXT_trap(GLuint,GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glSwizzleEXT");return (void)0;}
void m_glBindFragmentShaderATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindFragmentShaderATI");return (void)0;}
void m_glVertexAttribs3hvNV_trap(GLuint,GLsizei,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs3hvNV");return (void)0;}
void m_glGenBuffersARB_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenBuffersARB");return (void)0;}
void m_glTextureStorageMem2DMultisampleEXT_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei,GLboolean,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTextureStorageMem2DMultisampleEXT");return (void)0;}
void m_glListParameterfvSGIX_trap(GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glListParameterfvSGIX");return (void)0;}
void m_glNamedRenderbufferStorageMultisample_trap(GLuint,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNamedRenderbufferStorageMultisample");return (void)0;}
void m_glVertexAttribI1iEXT_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1iEXT");return (void)0;}
void m_glMultiTexCoord2ivARB_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2ivARB");return (void)0;}
void m_glLightModelxOES_trap(GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glLightModelxOES");return (void)0;}
void m_glColor3xOES_trap(GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glColor3xOES");return (void)0;}
void m_glReadBuffer_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glReadBuffer");return (void)0;}
void m_glStencilFillPathInstancedNV_trap(GLsizei,GLenum,const void*,GLuint,GLenum,GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glStencilFillPathInstancedNV");return (void)0;}
void m_glVDPAUUnmapSurfacesNV_trap(GLsizei,const GLvdpauSurfaceNV*)const{this->m_printMissingFunctionErrorAndExit("glVDPAUUnmapSurfacesNV");return (void)0;}
void m_glProgramUniform4i64NV_trap(GLuint,GLint,GLint64EXT,GLint64EXT,GLint64EXT,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform4i64NV");return (void)0;}
void m_glVertexStream4dvATI_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream4dvATI");return (void)0;}
GLboolean m_glIsQuery_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsQuery");return (GLboolean)0;}
void m_glProgramUniformMatrix4fvEXT_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4fvEXT");return (void)0;}
void m_glVertexAttrib3hNV_trap(GLuint,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3hNV");return (void)0;}
void m_glFlushMappedNamedBufferRange_trap(GLuint,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glFlushMappedNamedBufferRange");return (void)0;}
void m_glPushName_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glPushName");return (void)0;}
void m_glGetClipPlane_trap(GLenum,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetClipPlane");return (void)0;}
void m_glVertex4dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertex4dv");return (void)0;}
void m_glVertexAttrib3d_trap(GLuint,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3d");return (void)0;}
void m_glBlendColor_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glBlendColor");return (void)0;}
void m_glBindTransformFeedbackNV_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindTransformFeedbackNV");return (void)0;}
void m_glSamplerParameterIuiv_trap(GLuint,GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameterIuiv");return (void)0;}
void m_glIndexubv_trap(const GLubyte*)const{this->m_printMissingFunctionErrorAndExit("glIndexubv");return (void)0;}
void m_glNamedBufferPageCommitmentEXT_trap(GLuint,GLintptr,GLsizeiptr,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferPageCommitmentEXT");return (void)0;}
GLenum m_glCheckNamedFramebufferStatus_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glCheckNamedFramebufferStatus");return (GLenum)0;}
void m_glGetObjectBufferfvATI_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectBufferfvATI");return (void)0;}
void m_glRasterPos4d_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4d");return (void)0;}
void m_glRasterPos4f_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4f");return (void)0;}
void m_glGetPerfMonitorCounterStringAMD_trap(GLuint,GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorCounterStringAMD");return (void)0;}
void m_glVertexAttrib3s_trap(GLuint,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3s");return (void)0;}
void m_glDrawElementsInstancedEXT_trap(GLenum,GLsizei,GLenum,const void*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstancedEXT");return (void)0;}
void m_glNamedProgramLocalParameterI4iEXT_trap(GLuint,GLenum,GLuint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameterI4iEXT");return (void)0;}
void m_glRasterPos4s_trap(GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glRasterPos4s");return (void)0;}
void m_glGetProgramStageiv_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramStageiv");return (void)0;}
void m_glGetMaterialxOES_trap(GLenum,GLenum,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glGetMaterialxOES");return (void)0;}
void m_glPopMatrix_trap()const{this->m_printMissingFunctionErrorAndExit("glPopMatrix");return (void)0;}
void m_glGetVideoui64vNV_trap(GLuint,GLenum,GLuint64EXT*)const{this->m_printMissingFunctionErrorAndExit("glGetVideoui64vNV");return (void)0;}
void m_glTangent3bEXT_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glTangent3bEXT");return (void)0;}
GLenum m_glGetGraphicsResetStatusARB_trap()const{this->m_printMissingFunctionErrorAndExit("glGetGraphicsResetStatusARB");return (GLenum)0;}
void m_glUniform4i_trap(GLint,GLint,GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glUniform4i");return (void)0;}
void m_glActiveTexture_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glActiveTexture");return (void)0;}
void m_glEnableVertexAttribArray_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexAttribArray");return (void)0;}
void m_glTexCoord4fVertex4fvSUN_trap(const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4fVertex4fvSUN");return (void)0;}
void m_glUniform4d_trap(GLint,GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glUniform4d");return (void)0;}
void m_glUniform4f_trap(GLint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform4f");return (void)0;}
void m_glRenderbufferStorageMultisample_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glRenderbufferStorageMultisample");return (void)0;}
void m_glCreateProgramPipelines_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glCreateProgramPipelines");return (void)0;}
void m_glVertexAttribLPointer_trap(GLuint,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribLPointer");return (void)0;}
void m_glUniform2uiEXT_trap(GLint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform2uiEXT");return (void)0;}
void m_glMultiTexCoord3sv_trap(GLenum,const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3sv");return (void)0;}
void m_glDrawElementsInstancedBaseVertex_trap(GLenum,GLsizei,GLenum,const void*,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glDrawElementsInstancedBaseVertex");return (void)0;}
void m_glPixelTransformParameterfvEXT_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPixelTransformParameterfvEXT");return (void)0;}
void m_glDrawTransformFeedbackNV_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawTransformFeedbackNV");return (void)0;}
void m_glTextureImage2DMultisampleCoverageNV_trap(GLuint,GLenum,GLsizei,GLsizei,GLint,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTextureImage2DMultisampleCoverageNV");return (void)0;}
void m_glNamedRenderbufferStorageMultisampleCoverageEXT_trap(GLuint,GLsizei,GLsizei,GLenum,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glNamedRenderbufferStorageMultisampleCoverageEXT");return (void)0;}
GLboolean m_glIsTexture_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsTexture");return (GLboolean)0;}
void m_glMultiTexCoord4iv_trap(GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4iv");return (void)0;}
void m_glTexEnvfv_trap(GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glTexEnvfv");return (void)0;}
void m_glPopDebugGroup_trap()const{this->m_printMissingFunctionErrorAndExit("glPopDebugGroup");return (void)0;}
void m_glUniformBlockBinding_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniformBlockBinding");return (void)0;}
void m_glWindowPos2svMESA_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2svMESA");return (void)0;}
void m_glGenerateTextureMipmapEXT_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glGenerateTextureMipmapEXT");return (void)0;}
GLuint m_glBindLightParameterEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindLightParameterEXT");return (GLuint)0;}
void m_glTexCoord3bOES_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glTexCoord3bOES");return (void)0;}
void m_glTexCoordPointer_trap(GLint,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordPointer");return (void)0;}
void m_glProgramUniformMatrix3x2fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix3x2fv");return (void)0;}
void m_glUniform2fvARB_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform2fvARB");return (void)0;}
void m_glProgramLocalParameterI4uivNV_trap(GLenum,GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glProgramLocalParameterI4uivNV");return (void)0;}
void m_glFlushVertexArrayRangeNV_trap()const{this->m_printMissingFunctionErrorAndExit("glFlushVertexArrayRangeNV");return (void)0;}
void m_glSecondaryColor3svEXT_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3svEXT");return (void)0;}
void m_glGetBufferParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetBufferParameteriv");return (void)0;}
void m_glGetQueryIndexediv_trap(GLenum,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryIndexediv");return (void)0;}
void m_glFramebufferTexture3DEXT_trap(GLenum,GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture3DEXT");return (void)0;}
void m_glLoadTransposeMatrixxOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glLoadTransposeMatrixxOES");return (void)0;}
void m_glDeleteTransformFeedbacksNV_trap(GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteTransformFeedbacksNV");return (void)0;}
void m_glGetCompressedTextureImageEXT_trap(GLuint,GLenum,GLint,void*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedTextureImageEXT");return (void)0;}
void m_glIndexMaterialEXT_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glIndexMaterialEXT");return (void)0;}
void m_glFogCoorddEXT_trap(GLdouble)const{this->m_printMissingFunctionErrorAndExit("glFogCoorddEXT");return (void)0;}
void m_glTexCoord2hvNV_trap(const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2hvNV");return (void)0;}
void m_glGetFramebufferParameterfvAMD_trap(GLenum,GLenum,GLuint,GLuint,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFramebufferParameterfvAMD");return (void)0;}
void m_glTexEnviv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexEnviv");return (void)0;}
void m_glEndTransformFeedbackNV_trap()const{this->m_printMissingFunctionErrorAndExit("glEndTransformFeedbackNV");return (void)0;}
void m_glGlobalAlphaFactoruiSUN_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glGlobalAlphaFactoruiSUN");return (void)0;}
void m_glSelectBuffer_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glSelectBuffer");return (void)0;}
void m_glNamedBufferSubDataEXT_trap(GLuint,GLintptr,GLsizeiptr,const void*)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferSubDataEXT");return (void)0;}
void m_glDisableVertexArrayAttrib_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableVertexArrayAttrib");return (void)0;}
void m_glBlendFunc_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBlendFunc");return (void)0;}
GLuint m_glCreateProgram_trap()const{this->m_printMissingFunctionErrorAndExit("glCreateProgram");return (GLuint)0;}
void m_glVertexStream2dATI_trap(GLenum,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexStream2dATI");return (void)0;}
void m_glUniform4ui64vARB_trap(GLint,GLsizei,const GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glUniform4ui64vARB");return (void)0;}
void m_glGetSemaphoreParameterui64vEXT_trap(GLuint,GLenum,GLuint64*)const{this->m_printMissingFunctionErrorAndExit("glGetSemaphoreParameterui64vEXT");return (void)0;}
void m_glPrimitiveRestartIndex_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glPrimitiveRestartIndex");return (void)0;}
void m_glNormalStream3fATI_trap(GLenum,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3fATI");return (void)0;}
void m_glProgramUniformMatrix2fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix2fv");return (void)0;}
void m_glVertexAttribs1hvNV_trap(GLuint,GLsizei,const GLhalfNV*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribs1hvNV");return (void)0;}
void m_glWindowPos4svMESA_trap(const GLshort*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos4svMESA");return (void)0;}
void m_glDeleteFragmentShaderATI_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDeleteFragmentShaderATI");return (void)0;}
void m_glBindImageTextures_trap(GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glBindImageTextures");return (void)0;}
void m_glMap2xOES_trap(GLenum,GLfixed,GLfixed,GLint,GLint,GLfixed,GLfixed,GLint,GLint,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMap2xOES");return (void)0;}
void m_glEnd_trap()const{this->m_printMissingFunctionErrorAndExit("glEnd");return (void)0;}
void m_glMultiTexCoord2dARB_trap(GLenum,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2dARB");return (void)0;}
void m_glUniform1i64NV_trap(GLint,GLint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform1i64NV");return (void)0;}
void m_glPathStringNV_trap(GLuint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glPathStringNV");return (void)0;}
void m_glGetNamedFramebufferParameterivEXT_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedFramebufferParameterivEXT");return (void)0;}
void m_glGetProgramNamedParameterdvNV_trap(GLuint,GLsizei,const GLubyte*,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetProgramNamedParameterdvNV");return (void)0;}
void m_glPathDashArrayNV_trap(GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPathDashArrayNV");return (void)0;}
void m_glUniform3uiv_trap(GLint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glUniform3uiv");return (void)0;}
void m_glColor3fVertex3fvSUN_trap(const GLfloat*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glColor3fVertex3fvSUN");return (void)0;}
void m_glMultTransposeMatrixd_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultTransposeMatrixd");return (void)0;}
void m_glClearColor_trap(GLclampf,GLclampf,GLclampf,GLclampf)const{this->m_printMissingFunctionErrorAndExit("glClearColor");return (void)0;}
GLuint64 m_glGetImageHandleARB_trap(GLuint,GLint,GLboolean,GLint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glGetImageHandleARB");return (GLuint64)0;}
void m_glTangent3dEXT_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glTangent3dEXT");return (void)0;}
void m_glGetQueryObjectivARB_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetQueryObjectivARB");return (void)0;}
void m_glGetLocalConstantFloatvEXT_trap(GLuint,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetLocalConstantFloatvEXT");return (void)0;}
void m_glUseShaderProgramEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUseShaderProgramEXT");return (void)0;}
void m_glBindRenderbufferEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindRenderbufferEXT");return (void)0;}
void m_glInterleavedArrays_trap(GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glInterleavedArrays");return (void)0;}
void m_glGetPerfMonitorGroupStringAMD_trap(GLuint,GLsizei,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetPerfMonitorGroupStringAMD");return (void)0;}
void m_glUniform3ui_trap(GLint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glUniform3ui");return (void)0;}
void m_glGetNamedProgramLocalParameterdvEXT_trap(GLuint,GLenum,GLuint,GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedProgramLocalParameterdvEXT");return (void)0;}
void m_glDeleteQueryResourceTagNV_trap(GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glDeleteQueryResourceTagNV");return (void)0;}
void m_glVertexAttribI4uiv_trap(GLuint,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4uiv");return (void)0;}
void m_glVertexAttrib4bv_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4bv");return (void)0;}
void m_glMultiTexCoord3xOES_trap(GLenum,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3xOES");return (void)0;}
void m_glSecondaryColor3ub_trap(GLubyte,GLubyte,GLubyte)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ub");return (void)0;}
void m_glFragmentMaterialfSGIX_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glFragmentMaterialfSGIX");return (void)0;}
void m_glGetVariantArrayObjectivATI_trap(GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetVariantArrayObjectivATI");return (void)0;}
void m_glSecondaryColor3ui_trap(GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3ui");return (void)0;}
void m_glVertexAttrib1dARB_trap(GLuint,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1dARB");return (void)0;}
void m_glGetNamedBufferPointerv_trap(GLuint,GLenum,void**)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferPointerv");return (void)0;}
void m_glLockArraysEXT_trap(GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glLockArraysEXT");return (void)0;}
void m_glVertexAttribPointerNV_trap(GLuint,GLint,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribPointerNV");return (void)0;}
void m_glConvolutionParameterf_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glConvolutionParameterf");return (void)0;}
void m_glBindBufferBaseEXT_trap(GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindBufferBaseEXT");return (void)0;}
void m_glTexCoord2xvOES_trap(const GLfixed*)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2xvOES");return (void)0;}
void m_glGetQueryBufferObjectui64v_trap(GLuint,GLuint,GLenum,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glGetQueryBufferObjectui64v");return (void)0;}
void m_glSetMultisamplefvAMD_trap(GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSetMultisamplefvAMD");return (void)0;}
void m_glPathColorGenNV_trap(GLenum,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPathColorGenNV");return (void)0;}
void m_glVertexAttrib3sARB_trap(GLuint,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3sARB");return (void)0;}
void m_glVertexAttrib4ivARB_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib4ivARB");return (void)0;}
void m_glGenTransformFeedbacks_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenTransformFeedbacks");return (void)0;}
void m_glGetVertexAttribIuiv_trap(GLuint,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexAttribIuiv");return (void)0;}
void m_glPixelTransformParameterfEXT_trap(GLenum,GLenum,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glPixelTransformParameterfEXT");return (void)0;}
void m_glGetTexParameterIuivEXT_trap(GLenum,GLenum,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterIuivEXT");return (void)0;}
void m_glGetObjectParameterivARB_trap(GLhandleARB,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectParameterivARB");return (void)0;}
void m_glVertexArraySecondaryColorOffsetEXT_trap(GLuint,GLuint,GLint,GLenum,GLsizei,GLintptr)const{this->m_printMissingFunctionErrorAndExit("glVertexArraySecondaryColorOffsetEXT");return (void)0;}
void m_glWindowPos2fARB_trap(GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glWindowPos2fARB");return (void)0;}
void m_glCompressedTexSubImage2D_trap(GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const GLvoid*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage2D");return (void)0;}
void m_glCompressedTexSubImage3DARB_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTexSubImage3DARB");return (void)0;}
void m_glProgramBinary_trap(GLuint,GLenum,const void*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glProgramBinary");return (void)0;}
void m_glPresentFrameKeyedNV_trap(GLuint,GLuint64EXT,GLuint,GLuint,GLenum,GLenum,GLuint,GLuint,GLenum,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glPresentFrameKeyedNV");return (void)0;}
void m_glVertexAttribI4bv_trap(GLuint,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI4bv");return (void)0;}
void m_glPathCoverDepthFuncNV_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glPathCoverDepthFuncNV");return (void)0;}
void m_glTransformFeedbackStreamAttribsNV_trap(GLsizei,const GLint*,GLsizei,const GLint*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glTransformFeedbackStreamAttribsNV");return (void)0;}
void m_glSecondaryColor3usEXT_trap(GLushort,GLushort,GLushort)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3usEXT");return (void)0;}
void m_glCopyColorTableSGI_trap(GLenum,GLenum,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyColorTableSGI");return (void)0;}
void m_glProgramEnvParameter4fvARB_trap(GLenum,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramEnvParameter4fvARB");return (void)0;}
void m_glMultiTexCoord4sARB_trap(GLenum,GLshort,GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4sARB");return (void)0;}
void m_glGetVertexArrayIndexed64iv_trap(GLuint,GLuint,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetVertexArrayIndexed64iv");return (void)0;}
void m_glMatrixMultTranspose3x3fNV_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMatrixMultTranspose3x3fNV");return (void)0;}
void m_glTexParameterIiv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTexParameterIiv");return (void)0;}
void m_glVertexArrayAttribFormat_trap(GLuint,GLuint,GLint,GLenum,GLboolean,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexArrayAttribFormat");return (void)0;}
void m_glEndTransformFeedback_trap()const{this->m_printMissingFunctionErrorAndExit("glEndTransformFeedback");return (void)0;}
void m_glDrawCommandsStatesAddressNV_trap(const GLuint64*,const GLsizei*,const GLuint*,const GLuint*,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawCommandsStatesAddressNV");return (void)0;}
void m_glUniform4ui64NV_trap(GLint,GLuint64EXT,GLuint64EXT,GLuint64EXT,GLuint64EXT)const{this->m_printMissingFunctionErrorAndExit("glUniform4ui64NV");return (void)0;}
void m_glMaterialiv_trap(GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glMaterialiv");return (void)0;}
void m_glTexImage2DMultisample_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexImage2DMultisample");return (void)0;}
void m_glBindTextureEXT_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindTextureEXT");return (void)0;}
GLboolean m_glIsBuffer_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIsBuffer");return (GLboolean)0;}
void m_glVertexAttribI1iv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1iv");return (void)0;}
void m_glGetFinalCombinerInputParameterfvNV_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetFinalCombinerInputParameterfvNV");return (void)0;}
void m_glMultiTexCoord3bvOES_trap(GLenum,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3bvOES");return (void)0;}
void m_glVertexAttribDivisor_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribDivisor");return (void)0;}
void m_glCopyBufferSubData_trap(GLenum,GLenum,GLintptr,GLintptr,GLsizeiptr)const{this->m_printMissingFunctionErrorAndExit("glCopyBufferSubData");return (void)0;}
GLuint m_glBindTexGenParameterEXT_trap(GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBindTexGenParameterEXT");return (GLuint)0;}
void m_glNormalStream3bATI_trap(GLenum,GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3bATI");return (void)0;}
void m_glTexStorageMem2DEXT_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glTexStorageMem2DEXT");return (void)0;}
void m_glTextureImage2DEXT_trap(GLuint,GLenum,GLint,GLint,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureImage2DEXT");return (void)0;}
void m_glGetColorTableParameteriv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetColorTableParameteriv");return (void)0;}
void m_glActiveTextureARB_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glActiveTextureARB");return (void)0;}
void m_glTexCoord4xOES_trap(GLfixed,GLfixed,GLfixed,GLfixed)const{this->m_printMissingFunctionErrorAndExit("glTexCoord4xOES");return (void)0;}
void m_glNamedBufferStorageExternalEXT_trap(GLuint,GLintptr,GLsizeiptr,GLeglClientBufferEXT,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glNamedBufferStorageExternalEXT");return (void)0;}
void m_glSecondaryColor3fvEXT_trap(const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSecondaryColor3fvEXT");return (void)0;}
void m_glUniformMatrix4x2fv_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix4x2fv");return (void)0;}
void m_glStartInstrumentsSGIX_trap()const{this->m_printMissingFunctionErrorAndExit("glStartInstrumentsSGIX");return (void)0;}
void m_glProgramNamedParameter4fvNV_trap(GLuint,GLsizei,const GLubyte*,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramNamedParameter4fvNV");return (void)0;}
void m_glEndVideoCaptureNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glEndVideoCaptureNV");return (void)0;}
GLuint m_glGenLists_trap(GLsizei)const{this->m_printMissingFunctionErrorAndExit("glGenLists");return (GLuint)0;}
void m_glUniform1fARB_trap(GLint,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform1fARB");return (void)0;}
void m_glNamedFramebufferTexture1DEXT_trap(GLuint,GLenum,GLenum,GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferTexture1DEXT");return (void)0;}
void* m_glMapBufferRange_trap(GLenum,GLintptr,GLsizeiptr,GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glMapBufferRange");return (void*)0;}
void m_glMultiDrawElementsIndirectCountARB_trap(GLenum,GLenum,const void*,GLintptr,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsIndirectCountARB");return (void)0;}
void m_glProgramUniformMatrix4x2fv_trap(GLuint,GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniformMatrix4x2fv");return (void)0;}
void m_glGetTextureParameterIivEXT_trap(GLuint,GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTextureParameterIivEXT");return (void)0;}
void m_glMultiTexCoord3hNV_trap(GLenum,GLhalfNV,GLhalfNV,GLhalfNV)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord3hNV");return (void)0;}
void m_glNamedProgramLocalParametersI4uivEXT_trap(GLuint,GLenum,GLuint,GLsizei,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParametersI4uivEXT");return (void)0;}
void m_glEndList_trap()const{this->m_printMissingFunctionErrorAndExit("glEndList");return (void)0;}
void m_glTexCoord2fColor4fNormal3fVertex3fSUN_trap(GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glTexCoord2fColor4fNormal3fVertex3fSUN");return (void)0;}
void m_glGenTransformFeedbacksNV_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenTransformFeedbacksNV");return (void)0;}
void m_glEdgeFlagv_trap(const GLboolean*)const{this->m_printMissingFunctionErrorAndExit("glEdgeFlagv");return (void)0;}
void m_glVertexAttribI2iv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI2iv");return (void)0;}
void m_glCopyMultiTexImage2DEXT_trap(GLenum,GLenum,GLint,GLenum,GLint,GLint,GLsizei,GLsizei,GLint)const{this->m_printMissingFunctionErrorAndExit("glCopyMultiTexImage2DEXT");return (void)0;}
void m_glUniformMatrix3x2dv_trap(GLint,GLsizei,GLboolean,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3x2dv");return (void)0;}
void m_glTexImage3DMultisampleCoverageNV_trap(GLenum,GLsizei,GLsizei,GLint,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexImage3DMultisampleCoverageNV");return (void)0;}
void m_glGetShaderPrecisionFormat_trap(GLenum,GLenum,GLint*,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetShaderPrecisionFormat");return (void)0;}
void m_glTexSubImage4DSGIS_trap(GLenum,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei,GLsizei,GLsizei,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTexSubImage4DSGIS");return (void)0;}
void m_glRasterSamplesEXT_trap(GLuint,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glRasterSamplesEXT");return (void)0;}
void m_glTextureView_trap(GLuint,GLenum,GLuint,GLenum,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTextureView");return (void)0;}
void m_glEvalMapsNV_trap(GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glEvalMapsNV");return (void)0;}
GLint m_glGetFragDataLocationEXT_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetFragDataLocationEXT");return (GLint)0;}
void m_glGetCompressedMultiTexImageEXT_trap(GLenum,GLenum,GLint,void*)const{this->m_printMissingFunctionErrorAndExit("glGetCompressedMultiTexImageEXT");return (void)0;}
void m_glIndexMask_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glIndexMask");return (void)0;}
void m_glPushClientAttrib_trap(GLbitfield)const{this->m_printMissingFunctionErrorAndExit("glPushClientAttrib");return (void)0;}
void m_glShaderSource_trap(GLuint,GLsizei,const GLchar*const*,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glShaderSource");return (void)0;}
void m_glDispatchComputeGroupSizeARB_trap(GLuint,GLuint,GLuint,GLuint,GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDispatchComputeGroupSizeARB");return (void)0;}
void m_glLGPUNamedBufferSubDataNVX_trap(GLbitfield,GLuint,GLintptr,GLsizeiptr,const void*)const{this->m_printMissingFunctionErrorAndExit("glLGPUNamedBufferSubDataNVX");return (void)0;}
void m_glGetnPixelMapfv_trap(GLenum,GLsizei,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapfv");return (void)0;}
void m_glTexCoordP2uiv_trap(GLenum,const GLuint*)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP2uiv");return (void)0;}
void m_glUniform2f_trap(GLint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform2f");return (void)0;}
void m_glGetNamedBufferParameteri64v_trap(GLuint,GLenum,GLint64*)const{this->m_printMissingFunctionErrorAndExit("glGetNamedBufferParameteri64v");return (void)0;}
void m_glCommandListSegmentsNV_trap(GLuint,GLuint)const{this->m_printMissingFunctionErrorAndExit("glCommandListSegmentsNV");return (void)0;}
void m_glTextureParameterIivEXT_trap(GLuint,GLenum,GLenum,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glTextureParameterIivEXT");return (void)0;}
void m_glMultiTexParameterfvEXT_trap(GLenum,GLenum,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexParameterfvEXT");return (void)0;}
void m_glProgramUniform2ui64ARB_trap(GLuint,GLint,GLuint64,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2ui64ARB");return (void)0;}
void m_glVertex4d_trap(GLdouble,GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertex4d");return (void)0;}
GLuint m_glNewObjectBufferATI_trap(GLsizei,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glNewObjectBufferATI");return (GLuint)0;}
void m_glViewportSwizzleNV_trap(GLuint,GLenum,GLenum,GLenum,GLenum)const{this->m_printMissingFunctionErrorAndExit("glViewportSwizzleNV");return (void)0;}
void m_glBufferData_trap(GLenum,GLsizeiptr,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glBufferData");return (void)0;}
void m_glTextureImage1DEXT_trap(GLuint,GLenum,GLint,GLint,GLsizei,GLint,GLenum,GLenum,const void*)const{this->m_printMissingFunctionErrorAndExit("glTextureImage1DEXT");return (void)0;}
void m_glGetTexParameterIiv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetTexParameterIiv");return (void)0;}
void m_glCopyTexSubImage1DEXT_trap(GLenum,GLint,GLint,GLint,GLint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTexSubImage1DEXT");return (void)0;}
void m_glVertex4f_trap(GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertex4f");return (void)0;}
void m_glUniformMatrix3fvARB_trap(GLint,GLsizei,GLboolean,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniformMatrix3fvARB");return (void)0;}
void m_glTexCoordP1ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glTexCoordP1ui");return (void)0;}
void m_glPointParameterfvEXT_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glPointParameterfvEXT");return (void)0;}
void m_glUniform4fARB_trap(GLint,GLfloat,GLfloat,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glUniform4fARB");return (void)0;}
void m_glImportMemoryFdEXT_trap(GLuint,GLuint64,GLenum,GLint)const{this->m_printMissingFunctionErrorAndExit("glImportMemoryFdEXT");return (void)0;}
void m_glCopyTextureSubImage3D_trap(GLuint,GLint,GLint,GLint,GLint,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyTextureSubImage3D");return (void)0;}
void m_glMultiTexCoord2fv_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2fv");return (void)0;}
void m_glNamedFramebufferSamplePositionsfvAMD_trap(GLuint,GLuint,GLuint,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNamedFramebufferSamplePositionsfvAMD");return (void)0;}
void m_glNormalP3ui_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glNormalP3ui");return (void)0;}
void m_glDrawRangeElementArrayATI_trap(GLenum,GLuint,GLuint,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawRangeElementArrayATI");return (void)0;}
void m_glVertexAttribI1i_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glVertexAttribI1i");return (void)0;}
void m_glDrawArraysInstancedARB_trap(GLenum,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysInstancedARB");return (void)0;}
void m_glEnableVertexAttribAPPLE_trap(GLuint,GLenum)const{this->m_printMissingFunctionErrorAndExit("glEnableVertexAttribAPPLE");return (void)0;}
GLuint m_glGetDebugMessageLogARB_trap(GLuint,GLsizei,GLenum*,GLenum*,GLuint*,GLenum*,GLsizei*,GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetDebugMessageLogARB");return (GLuint)0;}
void m_glGetPathTexGenfvNV_trap(GLenum,GLenum,GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glGetPathTexGenfvNV");return (void)0;}
void m_glNamedProgramLocalParameters4fvEXT_trap(GLuint,GLenum,GLuint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glNamedProgramLocalParameters4fvEXT");return (void)0;}
void m_glQueryResourceTagNV_trap(GLint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glQueryResourceTagNV");return (void)0;}
void m_glVertexStream3fvATI_trap(GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glVertexStream3fvATI");return (void)0;}
void m_glFramebufferTexture3D_trap(GLenum,GLenum,GLenum,GLuint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glFramebufferTexture3D");return (void)0;}
void m_glCompressedTextureSubImage2DEXT_trap(GLuint,GLenum,GLint,GLint,GLint,GLsizei,GLsizei,GLenum,GLsizei,const void*)const{this->m_printMissingFunctionErrorAndExit("glCompressedTextureSubImage2DEXT");return (void)0;}
void m_glWindowPos3dv_trap(const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glWindowPos3dv");return (void)0;}
void m_glCopyConvolutionFilter2D_trap(GLenum,GLenum,GLint,GLint,GLsizei,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glCopyConvolutionFilter2D");return (void)0;}
void m_glReadInstrumentsSGIX_trap(GLint)const{this->m_printMissingFunctionErrorAndExit("glReadInstrumentsSGIX");return (void)0;}
void m_glProgramUniform2dvEXT_trap(GLuint,GLint,GLsizei,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform2dvEXT");return (void)0;}
void m_glSamplerParameterfv_trap(GLuint,GLenum,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glSamplerParameterfv");return (void)0;}
void m_glBindBufferARB_trap(GLenum,GLuint)const{this->m_printMissingFunctionErrorAndExit("glBindBufferARB");return (void)0;}
void m_glVertexAttrib1sNV_trap(GLuint,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib1sNV");return (void)0;}
void m_glGetMaterialiv_trap(GLenum,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetMaterialiv");return (void)0;}
void m_glUniform1fv_trap(GLint,GLsizei,const GLfloat*)const{this->m_printMissingFunctionErrorAndExit("glUniform1fv");return (void)0;}
void m_glBeginOcclusionQueryNV_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glBeginOcclusionQueryNV");return (void)0;}
void m_glGenFencesAPPLE_trap(GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGenFencesAPPLE");return (void)0;}
void m_glScissorIndexedv_trap(GLuint,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glScissorIndexedv");return (void)0;}
void m_glDisableVariantClientStateEXT_trap(GLuint)const{this->m_printMissingFunctionErrorAndExit("glDisableVariantClientStateEXT");return (void)0;}
void m_glMinmaxEXT_trap(GLenum,GLenum,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glMinmaxEXT");return (void)0;}
void m_glNormalPointervINTEL_trap(GLenum,const void**)const{this->m_printMissingFunctionErrorAndExit("glNormalPointervINTEL");return (void)0;}
void m_glNormal3s_trap(GLshort,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glNormal3s");return (void)0;}
void m_glGetnPixelMapuiv_trap(GLenum,GLsizei,GLuint*)const{this->m_printMissingFunctionErrorAndExit("glGetnPixelMapuiv");return (void)0;}
void m_glNormalStream3bvATI_trap(GLenum,const GLbyte*)const{this->m_printMissingFunctionErrorAndExit("glNormalStream3bvATI");return (void)0;}
void m_glGetObjectParameterivAPPLE_trap(GLenum,GLuint,GLenum,GLint*)const{this->m_printMissingFunctionErrorAndExit("glGetObjectParameterivAPPLE");return (void)0;}
void m_glNormal3i_trap(GLint,GLint,GLint)const{this->m_printMissingFunctionErrorAndExit("glNormal3i");return (void)0;}
void m_glUniform1ivARB_trap(GLint,GLsizei,const GLint*)const{this->m_printMissingFunctionErrorAndExit("glUniform1ivARB");return (void)0;}
void m_glNormal3d_trap(GLdouble,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glNormal3d");return (void)0;}
void m_glUpdateObjectBufferATI_trap(GLuint,GLuint,GLsizei,const void*,GLenum)const{this->m_printMissingFunctionErrorAndExit("glUpdateObjectBufferATI");return (void)0;}
void m_glNormal3b_trap(GLbyte,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glNormal3b");return (void)0;}
GLint m_glGetUniformBufferSizeEXT_trap(GLuint,GLint)const{this->m_printMissingFunctionErrorAndExit("glGetUniformBufferSizeEXT");return (GLint)0;}
void m_glMultiTexCoord4dv_trap(GLenum,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord4dv");return (void)0;}
void m_glProgramUniform3i64ARB_trap(GLuint,GLint,GLint64,GLint64,GLint64)const{this->m_printMissingFunctionErrorAndExit("glProgramUniform3i64ARB");return (void)0;}
void m_glVertexAttrib2d_trap(GLuint,GLdouble,GLdouble)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2d");return (void)0;}
void m_glVertexAttrib2f_trap(GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2f");return (void)0;}
void m_glMultiDrawElementsEXT_trap(GLenum,const GLsizei*,GLenum,const void*const*,GLsizei)const{this->m_printMissingFunctionErrorAndExit("glMultiDrawElementsEXT");return (void)0;}
void m_glVertexAttrib3dv_trap(GLuint,const GLdouble*)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib3dv");return (void)0;}
void m_glMultiTexCoord2bOES_trap(GLenum,GLbyte,GLbyte)const{this->m_printMissingFunctionErrorAndExit("glMultiTexCoord2bOES");return (void)0;}
void m_glVertexAttrib2s_trap(GLuint,GLshort,GLshort)const{this->m_printMissingFunctionErrorAndExit("glVertexAttrib2s");return (void)0;}
void m_glTexImage3DMultisample_trap(GLenum,GLsizei,GLenum,GLsizei,GLsizei,GLsizei,GLboolean)const{this->m_printMissingFunctionErrorAndExit("glTexImage3DMultisample");return (void)0;}
GLuint m_glGetUniformBlockIndex_trap(GLuint,const GLchar*)const{this->m_printMissingFunctionErrorAndExit("glGetUniformBlockIndex");return (GLuint)0;}
GLboolean m_glReleaseKeyedMutexWin32EXT_trap(GLuint,GLuint64)const{this->m_printMissingFunctionErrorAndExit("glReleaseKeyedMutexWin32EXT");return (GLboolean)0;}
void m_glFrontFace_trap(GLenum)const{this->m_printMissingFunctionErrorAndExit("glFrontFace");return (void)0;}
void m_glEvalCoord1xOES_trap(GLfixed)const{this->m_printMissingFunctionErrorAndExit("glEvalCoord1xOES");return (void)0;}
void m_glDrawArraysInstancedBaseInstance_trap(GLenum,GLint,GLsizei,GLsizei,GLuint)const{this->m_printMissingFunctionErrorAndExit("glDrawArraysInstancedBaseInstance");return (void)0;}
GLboolean m_glIsPointInStrokePathNV_trap(GLuint,GLfloat,GLfloat)const{this->m_printMissingFunctionErrorAndExit("glIsPointInStrokePathNV");return (GLboolean)0;}
