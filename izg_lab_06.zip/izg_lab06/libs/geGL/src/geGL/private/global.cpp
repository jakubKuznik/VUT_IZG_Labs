#include <geGL/private/global.h>

thread_local ge::gl::Global ge::gl::global;
